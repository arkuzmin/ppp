#ifndef _CHART_H_
#define _CHART_H_

#include "Common.h"
#include <qpainter.h>
#include <qmutex.h>

namespace Chart
{

class CAxis
{
	CAxis(const CAxis&);
	CAxis& operator = (const CAxis&);

public:
	enum EDirection
	{
		D_vertical,
		D_horizontal
	};

	enum ETextPos
	{
		TP_up,
		TP_down
	};

	CAxis(EDirection dir = D_horizontal, ETextPos tpos = TP_down);
	virtual ~CAxis();

	void	Draw(QPainter& pnt);

	void	Direction(EDirection d);
	void	TextPosition(ETextPos tp);

	void			Name(const QString& n);
	inline QString	Name() const
		{return ms_Name;}
	void			ClearName();

	void	SetRange(double s, double e);
	bool	InRange(double d);

	void	SetRect(const QRect& r);
	inline const QRect&	GetRect() const
		{return mr_Boundary;}
	int		GetPreferredHeight(QPainter& pnt);
	void	GetWidthBearings(QPainter& pnt, int& start, int& end);

	void	AddLabel(double start, double end, QString l);
	void	AddLabel(double point, int prec);
	void	SetLabel(double start, double end, QString l);
	void	ClearLabels();
	
	//coords transformation
	int		ToScreen(double d);
	double	ToData(int s);

	inline void	ForcePoints(bool fp)
		{mb_force_points = fp;}
	inline bool	ForcePoints() const
		{return mb_force_points;}

protected:
	struct SLabel
	{
		SLabel(double s = 0.0, double e = 0.0, QString l = QString())
		{
			text	= l;
			start	= s;
			end		= e;
		}

		QString	text;
		double	start;
		double	end;
	};

	typedef QValueVector<SLabel>	TLabelVec;
	typedef TLabelVec::iterator		TLabelIter;

	EDirection	m_Direction;
	ETextPos	m_TextPos;

	double	m_range_min;
	double	m_range_max;

	TLabelVec	mv_Labels;

	QString	ms_Name;

	QRect	mr_Boundary;

	bool	mb_force_points;

	int	m_scale_hgh;	//size of scale line
	int	m_label_frame;	//space after label
	int	m_cross_point_space;	//min space between points
	int	m_cross_label_space;	//min space between labels

	int	GetLogicalHeight() const;
	int	GetLogicalWidth() const;

	double	ToRange(double d);

	void	SortLabels();

	inline int	GetLabelStart() const
		{return m_scale_hgh * 2;}
	inline int	GetNameStart(int max_label) const
		{return GetLabelStart() + max_label + m_label_frame;}
	inline int	GetPreferredNameHeight(int nh) const
		{return nh /* * 2 */ ;}
	int	GetNameHeightSpaced(int max_label, int nh) const;

	bool	FitLabel(int l_width) const;
	bool	FitName(int max_label, int w, int h) const;

};	//class CAxis
//========================================================================

class CColorLegend
{
	CColorLegend(const CColorLegend&);
	CColorLegend& operator = (const CColorLegend&);

public:
	CColorLegend();
	virtual ~CColorLegend();

	void	AddItem(const QColor& color, const QString& name);
	void	ClearItems();

	QRect	GetPreferredSize(QPainter& pnt);
	void	Draw(QPainter& pnt, const QRect& r);

protected:
	struct SItem
	{
		SItem(const QColor& c = QColor(), const QString& n = QString())
		{
			color	= c;
			name	= n;
		}

		QColor	color;
		QString	name;
	};

	typedef QValueVector<SItem>	TItemVec;

	TItemVec	mv_Items;

	int	m_color_size;
	int	m_color_name_space;
	int	m_line_space;

};	//class CColorLegend
//========================================================================

class CColorGradient
{
	CColorGradient(const CColorGradient&);
	CColorGradient& operator = (const CColorGradient&);

public:
	CColorGradient();
	virtual ~CColorGradient();

	void	SetRange(double min, double max);
	void	SetColorRange(const QColor& cmin, const QColor& cmax);

	virtual QColor	GetColor(double v) const = 0;

	inline void	SetNAColor(const QColor& c)
		{m_color_NA = c;}

	void	Draw(QPainter& pnt, QRect r);

	int	GetPreferredWidth(QPainter& pnt, int color_width);

protected:
	double	m_range_min;
	double	m_range_max;

	QColor	m_color_min;
	QColor	m_color_max;
	QColor	m_color_NA;

	CAxis	m_value_axis;

	int	m_line_hgh;

};	//class CColorGradient

class CPlainGradient: public CColorGradient
{
public:
	virtual QColor	GetColor(double v) const;
};
//========================================================================

//thread safe
class CChartBase: public QWidget
{
	Q_OBJECT

private:
	CChartBase(const CChartBase&);
	CChartBase& operator = (const CChartBase&);

public:
	CChartBase(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	virtual ~CChartBase();

	enum EAxisPosition
	{
		AP_top,
		AP_down,
		AP_left,
		AP_right
	};
	void	SetAbscissPos(EAxisPosition ap, bool upd = true);
	void	SetOrdinatesPos(EAxisPosition ap, bool upd = true);

	void	AbscissName(const QString& n, bool upd = true);
	void	OrdinatesName(const QString& n, bool upd = true);

	inline bool	InChartWorkspace(int x, int y)
		{return InChartWorkspace(QPoint(x, y));}
	bool	InChartWorkspace(QPoint p);

	virtual void	Draw(QPainter& pnt);

protected:
	CAxis	m_absciss_axis;
	CAxis	m_ordinates_axis;
	EAxisPosition	m_absciss_pos;
	EAxisPosition	m_ordinates_pos;

	virtual void paintEvent(QPaintEvent*);
};
//========================================================================

class CMatrix: public CChartBase
{
	Q_OBJECT
public:
	CMatrix(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	virtual ~CMatrix();

	bool	SetSize(int y, int x, bool set_names = true);
	void	SetItem(int y, int x, int v);
	void	InitItems(int n = 0);
	void	SetColName(int n, const QString& name, bool upd = true);
	void	SetRowName(int n, const QString& name, bool upd = true);
	void	ClearColNames(bool upd = true);
	void	ClearRowNames(bool upd = true);

	virtual void	Draw(QPainter& pnt);

protected:
	CPlainGradient	m_legend;

	TInt2DVec m_data;
	int	m_size_y;
	int	m_size_x;

	bool	mb_minmax_defined;
	int		m_min_value;
	int		m_max_value;

	int	m_min_grid_draw;
	int	m_legend_space;
	int	m_legend_color_width;

	QColor	mc_grid;

	void	CalcMinMax();
	
	void	mousePressEvent(QMouseEvent* e);
};	//class CMatrix
//========================================================================

class CBarChart: public CChartBase
{
	Q_OBJECT
public:
	CBarChart(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	virtual ~CBarChart();

	void	SetItemCount(int n, bool upd = true);
	void	SetItemName(int n, const QString& name, bool upd = true);
	void	SetItemValue(int n, double v, bool upd = true);
	void	SetItemColor(int n, const QColor& c, bool upd = true);
	void	AddItemValue(int n, double v, bool upd = true);

	virtual void	Draw(QPainter& pnt);

protected:
	struct	SBar
	{
		SBar(double v = 0.0, QColor c = QColor())
		{
			val	= v;
			col = c;
		}

		double	val;
		QColor	col;
	};

	typedef QValueVector<SBar>	TBarVec;

	TBarVec	m_data;

	double	m_max_value;
	double	m_min_value;

	int	m_ordinate_labels_count;

	void	InitOrdinates();

	void	mousePressEvent(QMouseEvent* e);
};	//class CBarChart
//========================================================================

//thread safe
class CGanttChart: public CChartBase
{
	Q_OBJECT
public:
	CGanttChart(QWidget* parent = 0, const char* name = 0, WFlags f = 0);
	virtual ~CGanttChart();

	void	Lock();
	void	Unlock();

	void	SetProcCount(int n, bool clear_all = true);
	void	SetProcName(int p, const QString& name, bool upd = true);
	void	ShowProc(int p, bool upd = true);
	void	HideProc(int p, bool upd = true);

	void	AddTaskType(int type, const QColor& c, const QString& name);
	void	ClearTaskTypes();
	void	AddTask(int proc, double start, double end, int type);
	void	ClearTasks();
	void	AddLink(int from, int to, double start, double end);
	void	ClearLinks();
	void	ClearTime();

	void	SetMinAbscissRange(double s, double e);
	void	ClearMinAbscissRange();

	virtual void	Draw(QPainter& pnt);

signals:
	void	TimeFrameSelected(double start, double end);

protected:
	struct STaskType
	{
		STaskType(int t = 0, QColor c = QColor(), QString n = QString())
		{
			type	= t;
			color	= c;
			name	= n;
		}

		int		type;
		QColor	color;
		QString	name;
	};

	typedef QValueVector<STaskType*>	TTaskTypeVec;

	struct STask
	{
		STask(double s = 0.0, double e = 0.0, STaskType* t = NULL)
		{
			t_start	= s;
			t_end	= e;
			type	= t;
		}

		double		t_start;
		double		t_end;
		STaskType*	type;
	};

	typedef QValueVector<STask>		TTaskVec;
	typedef QValueVector<TTaskVec>	T2DTaskVec;

	struct SLink
	{
		SLink(int f = 0, int t = 0, double s = 0.0, double e = 0.0)
		{
			from	= f;
			to		= t;
			start	= s;
			end		= e;
		}

		int from;
		int	to;
		double	start;
		double	end;
	};

	typedef QValueVector<SLink>	TLinkVec;

	struct SProc
	{
		SProc(bool s = true, const QString& n = QString(), const TTaskVec& tv = TTaskVec())
		{
			show	= s;
			name	= n;
			tasks	= tv;
			chart_line = 0;
		}

		bool		show;
		QString		name;
		TTaskVec	tasks;
		int			chart_line;	//internal, for drawing only
	};

	typedef QValueVector<SProc>	TProcVec;

	QMutex	m_mutex;

	TTaskTypeVec	mv_TType;
	TProcVec	mv_Proc;
	TLinkVec	mv_Links;

	bool	mb_time_defined;
	double	m_time_start;
	double	m_time_end;

	void	CorrectTime(double t, bool redraw_labels = true, bool force_labels = false);

	CColorLegend	m_legend;

	int m_legend_space;
	int	m_time_labels_count;

	double m_task_hgh_fract;	

	QPen	m_pen_proc_line;
	QPen	m_pen_link;
	int		m_link_min_width;
	double	m_link_fract;

	inline int	GetLinkWidth(int task_hgh)
		{int l = (int)(task_hgh * m_link_fract); return max(l, m_link_min_width);}

	int	m_min_draw_border;

	STaskType*	GetTaskType(int type);

	int		mn_mouse_tolerance;	//values ( >= mn_mouse_tolerance ) aren't valid
	bool	mb_mouse_pressed;
	QPen	m_pen_time_line;

	double	m_mouse_press_time;
	double	m_mouse_release_time;
	int		m_mouse_press_pos;
	int		m_mouse_release_pos;

	int		FitMouseTolerance(int x);
	void	mousePressEvent(QMouseEvent* e);
	void	mouseMoveEvent(QMouseEvent* e);
	void	mouseReleaseEvent(QMouseEvent* e);
};	//class CGantChart
//========================================================================

};	//namespace Chart

#endif	//_CHART_H_
