/****************************************************************************
** Form interface generated from reading ui file 'fmdiwindow.ui'
**
** Created: Пн 19. июл 07:48:01 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FMDIWINDOW_H
#define FMDIWINDOW_H

#include <qvariant.h>
#include <qmainwindow.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;

class FMDIWindow : public QMainWindow
{
    Q_OBJECT

public:
    FMDIWindow( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~FMDIWindow();

    QMenuBar *MenuBar;
    QPopupMenu *file;
    QPopupMenu *view;
    QPopupMenu *unnamed;
    QToolBar *toolBar;
    QAction* fileOpenAction;
    QAction* fileExitAction;
    QAction* fileCloseAction;
    QAction* aDisplayCommunicationMatrix;
    QAction* aDisplayLoad;
    QAction* aFilter;
    QAction* aDisplayTasks;
    QAction* aDisplayGantt;
    QAction* aHelpAbout;

public slots:
    virtual void fileNew();
    virtual void fileOpen();
    virtual void fileSave();
    virtual void fileSaveAs();
    virtual void filePrint();
    virtual void fileExit();
    virtual void fileClose();
    virtual void OnFilter();
    virtual void DisplayLoad();
    virtual void DisplayComunications();
    virtual void DisplayGantt();
    virtual void DisplayTasks();
    virtual void helpAbout();

protected:

protected slots:
    virtual void languageChange();

};

#endif // FMDIWINDOW_H
