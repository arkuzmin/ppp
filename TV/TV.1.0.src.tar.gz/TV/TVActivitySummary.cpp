#include "TVActivitySummary.h"

CTVActivitySummary::CTVActivitySummary(CTraceManager* pTM, QWidget* parent)
	:CTraceVisualizer(pTM, parent, NULL, "CTVCommunicationMatrix")
{
	mp_TypeFilter =	new	CTraceFilter;
	pTM->MakeMPIRoutineFilter(*mp_TypeFilter);

	setName( "FActivitySummary" );
    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FActivitySummaryLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FActivitySummaryLayout"); 

    textLabel3 = new QLabel( centralWidget(), "textLabel3" );

    FActivitySummaryLayout->addWidget( textLabel3, 0, 1 );

    cb_Show = new QComboBox( FALSE, centralWidget(), "cb_Show" );
    cb_Show->setSizeLimit( 20 );

    FActivitySummaryLayout->addWidget( cb_Show, 1, 1 );

    mg_Time = new QButtonGroup( centralWidget(), "mg_Time" );
    mg_Time->setColumnLayout(0, Qt::Vertical );
    mg_Time->layout()->setSpacing( 6 );
    mg_Time->layout()->setMargin( 11 );
    mg_TimeLayout = new QVBoxLayout( mg_Time->layout() );
    mg_TimeLayout->setAlignment( Qt::AlignTop );

    mr_Total = new QRadioButton( mg_Time, "mr_Total" );
    mg_TimeLayout->addWidget( mr_Total );

    mr_MPI = new QRadioButton( mg_Time, "mr_MPI" );
    mg_TimeLayout->addWidget( mr_MPI );

    FActivitySummaryLayout->addWidget( mg_Time, 2, 1 );
    spacer1 = new QSpacerItem( 20, 110, QSizePolicy::Minimum, QSizePolicy::Expanding );
    FActivitySummaryLayout->addItem( spacer1, 4, 1 );

    m_chart = new Chart::CBarChart( centralWidget(), "m_chart" );
    m_chart->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, m_chart->sizePolicy().hasHeightForWidth() ) );

    FActivitySummaryLayout->addMultiCellWidget( m_chart, 0, 6, 0, 0 );

    mg_Show = new QButtonGroup( centralWidget(), "mg_Show" );
    mg_Show->setColumnLayout(0, Qt::Vertical );
    mg_Show->layout()->setSpacing( 6 );
    mg_Show->layout()->setMargin( 11 );
    mg_ShowLayout = new QVBoxLayout( mg_Show->layout() );
    mg_ShowLayout->setAlignment( Qt::AlignTop );

    mr_TotalTime = new QRadioButton( mg_Show, "mr_TotalTime" );
    mg_ShowLayout->addWidget( mr_TotalTime );

    mr_CallCount = new QRadioButton( mg_Show, "mr_CallCount" );
    mg_ShowLayout->addWidget( mr_CallCount );

    mr_MeanCall = new QRadioButton( mg_Show, "mr_MeanCall" );
    mg_ShowLayout->addWidget( mr_MeanCall );

    FActivitySummaryLayout->addWidget( mg_Show, 3, 1 );

    // toolbars

    languageChange();
    resize( QSize(400, 300).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

	ms_ord_time_percent = trUtf8("\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f\x2c\x20\x25");
	ms_ord_time_seconds = trUtf8("\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f\x2c\x20\xd1\x81");
	ms_ord_calls		= trUtf8("\xd0\x92\xd1\x8b\xd0\xb7\xd0\xbe\xd0\xb2\xd1\x8b");

	m_chart->OrdinatesName(ms_ord_time_seconds);

	cb_Show->setInsertionPolicy(QComboBox::AtBottom);

	mr_Total->setChecked(true);
	mr_TotalTime->setChecked(true);
	ToTotalTime();

	connect(cb_Show, SIGNAL(activated(int)), SLOT(OnProcChanged(int)));
	connect(mg_Time, SIGNAL(clicked(int)), SLOT(OnTotalMPITimeChanged(int)));
	connect(mg_Show, SIGNAL(clicked(int)), SLOT(OnTimeCountChanged(int)));
	connect(mr_Total, SIGNAL(clicked()), SLOT(ToTotalTime()));
	connect(mr_MPI, SIGNAL(clicked()), SLOT(ToMPITime()));
}

CTVActivitySummary::~CTVActivitySummary()
{
}
//========================================================================

void	CTVActivitySummary::OnInitDraw()
{
	cb_Show->clear();

	int proc = mp_TrManager->GetProcessorsCount();

	for (int i = 0; i < proc; i++)
		cb_Show->insertItem(mp_TrManager->GetProcessorName(i));

	//mean
	cb_Show->insertItem(trUtf8( "\xd0\xa1\xd1\x80\xd0\xb5\xd0\xb4\xd0\xbd\xd0\xb5\xd0\xb5" ));

	cb_Show->setCurrentItem(cb_Show->count() - 1);
}
//========================================================================

void	CTVActivitySummary::OnDrawRecord()
{
	ShowChart();
}
//========================================================================

void	CTVActivitySummary::OnFinalDraw()
{
	ShowChart();
}
//========================================================================

bool	CTVActivitySummary::OnNewTraceRead()
{
	int proc = mp_TrManager->GetProcessorsCount() + 1 /*overall*/;

	mtx_Data.lock();
		m_data.resize(proc);
		for (int i = 0; i < proc; i++)
			m_data[i].resize(0);
	mtx_Data.unlock();

	m_read = 0;
	m_filter = 0;
	m_task = 0;

	return true;
}
//========================================================================

bool	CTVActivitySummary::OnEventRead(const CTraceEvent* pTE)
{
	m_read++;
	if (!CTraceVisualizer::OnEventRead(pTE))
		return false;

	m_filter++;

	if (pTE->GetType() != CTraceEvent::E_task)
		return false;
	const CTaskEvent* pTS = static_cast<const CTaskEvent*>(pTE);

	m_task++;

	mtx_Data.lock();
		int proc = pTS->GetProcessor();

		size_t i;
		for (i = 0; i < m_data[proc].size(); i++)
			if (m_data[proc][i].id == pTS->GetEvent())
				break;
		if (i == m_data[proc].size())
			m_data[proc].push_back(STask(pTS->GetEvent(), 0.0));

		m_data[proc][i].val += pTS->GetTimeEnd() - pTS->GetTimeStart();
		m_data[proc][i].count++;

		//overall
		proc = m_data.size() - 1;
		for (i = 0; i < m_data[proc].size(); i++)
			if (m_data[proc][i].id == pTS->GetEvent())
				break;
		if (i == m_data[proc].size())
			m_data[proc].push_back(STask(pTS->GetEvent(), 0.0));

		m_data[proc][i].val += pTS->GetTimeEnd() - pTS->GetTimeStart();
		m_data[proc][i].count++;
	mtx_Data.unlock();

	return true;
}
//========================================================================

bool	CTVActivitySummary::OnEndTraceRead()
{
	return true;
}
//========================================================================

void CTVActivitySummary::languageChange()
{
    setCaption( trUtf8( "\xd0\x97\xd0\xb0\xd0\xb3\xd1\x80\xd1\x83\xd0\xb7\xd0\xba\xd0\xb0" ) );
    textLabel3->setText( trUtf8( "\xd0\x9f\xd1\x80\xd0\xbe\xd1\x86\xd0\xb5\xd1\x81\xd1\x81\xd0\xbe\xd1\x80\x3a" ) );
    cb_Show->setCurrentItem( 0 );
    mg_Time->setTitle( trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f" ) );
    mr_Total->setText( trUtf8( "\xd0\x9e\xd0\xb1\xd1\x89\xd0\xb5\xd0\xb5" ) );
    mr_MPI->setText( tr( "MPI" ) );
    mg_Show->setTitle( trUtf8( "\xd0\x9f\xd0\xbe\xd0\xba\xd0\xb0\xd0\xb7\xd0\xb0\xd1\x82\xd1\x8c" ) );
    mr_TotalTime->setText( trUtf8( "\xd0\x9e\xd0\xb1\xd1\x89\xd0\xb5\xd0\xb5\x20\xd0\xb2\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f" ) );
    mr_CallCount->setText( trUtf8( "\xd0\x9a\xd0\xbe\xd0\xbb\xd0\xb8\xd1\x87\xd0\xb5\xd1\x81\xd1\x82\xd0\xb2\xd0\xbe\x20\xd0\xb2\xd1\x8b\xd0\xb7\xd0\xbe\xd0\xb2\xd0\xbe\xd0\xb2" ) );
    mr_MeanCall->setText( trUtf8( "\xd0\xa1\xd1\x80\xd0\xb5\xd0\xb4\xd0\xbd\xd0\xb5\xd0\xb5\x20\xd0\xb2\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f\x20\xd0\xb2\xd1\x8b\xd0\xb7\xd0\xbe\xd0\xb2\xd0\xb0" ) );
}
//========================================================================

void	CTVActivitySummary::OnProcChanged(int)
{
	ShowChart();
}
//========================================================================

void	CTVActivitySummary::OnTotalMPITimeChanged(int)
{
	ShowChart();
}
//========================================================================

void	CTVActivitySummary::OnTimeCountChanged(int)
{
	ShowChart();
}
//========================================================================

void	CTVActivitySummary::ToTotalTime()
{
	mg_Show->setEnabled(false);
	m_chart->OrdinatesName(ms_ord_time_seconds);
}
//========================================================================

void	CTVActivitySummary::ToMPITime()
{
	mg_Show->setEnabled(true);
}
//========================================================================

void	CTVActivitySummary::ShowChart()
{
	int proc = cb_Show->currentItem();
	if (proc < 0)
		return;

	if (mr_Total->isChecked())
		ShowTotalChart(proc);

	if (mr_MPI->isChecked())
		ShowMPIChart(proc);

	m_chart->update();
}
//========================================================================

void	CTVActivitySummary::ShowTotalChart(int proc)
{
	double mpi_time = 0.0;

	mtx_Data.lock();

	for (size_t i = 0; i < m_data[proc].size(); i++)
		mpi_time += m_data[proc][i].val;

	mtx_Data.unlock();

	if (proc == (int)m_data.size() - 1)	//total
		mpi_time /= m_data.size() - 1;

	m_chart->SetItemCount(3, false);

	double start, end;
	mp_TrManager->GetDisplayTime(start, end);
	double total = end - start;

	m_chart->SetItemValue(0, total, false);
	m_chart->SetItemName(0, "Total", false);
	m_chart->SetItemColor(0, mp_TrManager->GetTotalTimeColor(), false);
	m_chart->SetItemValue(1, total - mpi_time, false);
	m_chart->SetItemName(1, "User", false);
	m_chart->SetItemColor(1, mp_TrManager->GetUserTimeColor(), false);
	m_chart->SetItemValue(2, mpi_time, false);
	m_chart->SetItemName(2, "MPI", false);
	m_chart->SetItemColor(2, mp_TrManager->GetMPITimeColor(), false);
}
//========================================================================

void	CTVActivitySummary::ShowMPIChart(int proc)
{
	m_chart->SetItemCount(m_data[proc].size());

	mtx_Data.lock();

	if (mr_TotalTime->isChecked())
	{
		m_chart->OrdinatesName(ms_ord_time_seconds);

		for (size_t i = 0; i < m_data[proc].size(); i++)
		{
			double v = m_data[proc][i].val;
			if (proc == (int)m_data.size() - 1)	//total
				v /= m_data.size() - 1;
			m_chart->SetItemValue(i, v, false);
			m_chart->SetItemName(i, mp_TrManager->GetMPIEventName(m_data[proc][i].id), false);
			m_chart->SetItemColor(i, mp_TrManager->GetMPIEventColor(m_data[proc][i].id), false);
		}
	}

	if (mr_CallCount->isChecked())
	{
		m_chart->OrdinatesName(ms_ord_calls);

		for (size_t i = 0; i < m_data[proc].size(); i++)
		{
			double c = m_data[proc][i].count;
			if (proc == (int)m_data.size() - 1)	//total
				c /= m_data.size() - 1;
			m_chart->SetItemValue(i, c, false);
			m_chart->SetItemName(i, mp_TrManager->GetMPIEventName(m_data[proc][i].id), false);
			m_chart->SetItemColor(i, mp_TrManager->GetMPIEventColor(m_data[proc][i].id), false);
		}
	}

	if (mr_MeanCall->isChecked())
	{
		m_chart->OrdinatesName(ms_ord_time_seconds);

		for (size_t i = 0; i < m_data[proc].size(); i++)
		{
			double c = m_data[proc][i].val / m_data[proc][i].count;
			if (proc == (int)m_data.size() - 1)	//total
				c /= m_data.size() - 1;
			m_chart->SetItemValue(i, c, false);
			m_chart->SetItemName(i, mp_TrManager->GetMPIEventName(m_data[proc][i].id), false);
			m_chart->SetItemColor(i, mp_TrManager->GetMPIEventColor(m_data[proc][i].id), false);
		}
	}

	mtx_Data.unlock();
}
//========================================================================
