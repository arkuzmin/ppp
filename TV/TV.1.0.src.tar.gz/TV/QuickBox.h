#ifndef _QUICKBOX_H_
#define _QUICKBOX_H_

#include <qmessagebox.h>

class CQuickBox: public QMessageBox
{
	Q_OBJECT
public:
	CQuickBox( QWidget* parent=0, const char* name=0 );
	CQuickBox( const QString& caption, const QString &text, Icon icon,
		int button0, int button1, int button2,
		QWidget* parent=0, const char* name=0, bool modal=TRUE,
		WFlags f=WStyle_DialogBorder  );
	virtual ~CQuickBox(void);

	static int	Msg(const QString & text,
		int button0 = QMessageBox::Ok, int button1 = 0, int button2 = 0,
		const QString & caption = QString("MB"),
		QWidget * parent = NULL);
};

#endif	//_QUICKBOX_H_
