#ifndef _FILTERWINDOW_H_
#define _FILTERWINDOW_H_

#include "TraceManager.h"
#include "ffilter.h"

class CFilterWindow: public FFilter, public IFilterWindow
{
	Q_OBJECT
public:
	CFilterWindow(CTraceManager* pTM, IFilterable* pF, QWidget* parent = 0, WFlags fl = WDestructiveClose);
	~CFilterWindow(void);

	virtual void	FilterChanged();

public slots:
    virtual void ApplyFilter();
    virtual void OnShowProc();
    virtual void OnHideProc();

	void OnBtnTimeLeft();
	void OnBtnTimeRight();
	void OnBtnZoomIn();
	void OnBtnZoomOut();

protected:
	CTraceManager*	mp_TrManager;
	IFilterable*	mp_FilterOwner;

	TIntList	ml_TotalProc;
	TIntList	ml_FilterProc;

	void	AddProc(int proc, QListBox* lb, TIntList& list);
	void	DelProc(int proc, QListBox* lb, TIntList& list);

	bool	ValidateTime(double& s, double& e);
};

#endif	//_FILTERWINDOW_H_
