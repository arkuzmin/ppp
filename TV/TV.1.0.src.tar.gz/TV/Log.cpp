#include "Log.h"

#include <qfile.h>
#include <qtextstream.h>

CLog::TLogMap	CLog::mm_Logs;

bool	CLog::Create(int lid, const QString& name)
{
	QFile* pF = new QFile(name);
	pF->open(IO_WriteOnly);
	mm_Logs.insert(lid, pF);

	return true;
}
//========================================================================

bool	CLog::Write(int lid, const QString& str)
{
	TLogIter it = mm_Logs.find(lid);
	if (it != mm_Logs.end())
	{
		(*it)->open(IO_WriteOnly | IO_Append);
		
		QTextStream ts(*it);

		ts << str;

		(*it)->flush();

		return true;
	}
	else
	{
		return false;
	}
}
//========================================================================
