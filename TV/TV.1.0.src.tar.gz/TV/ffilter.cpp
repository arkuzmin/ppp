/****************************************************************************
** Form implementation generated from reading ui file 'ffilter.ui'
**
** Created: Пн 28. июн 15:33:56 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "ffilter.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a FFilter as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
FFilter::FFilter( QWidget* parent, const char* name, WFlags fl )
    : QMainWindow( parent, name, fl )
{
    (void)statusBar();
    if ( !name )
	setName( "FFilter" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)4, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 544, 193 ) );
    setMaximumSize( QSize( 32767, 32000 ) );
    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FFilterLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FFilterLayout"); 

    groupBox2 = new QGroupBox( centralWidget(), "groupBox2" );
    groupBox2->setColumnLayout(0, Qt::Vertical );
    groupBox2->layout()->setSpacing( 6 );
    groupBox2->layout()->setMargin( 11 );
    groupBox2Layout = new QGridLayout( groupBox2->layout() );
    groupBox2Layout->setAlignment( Qt::AlignTop );

    textLabel1 = new QLabel( groupBox2, "textLabel1" );

    groupBox2Layout->addWidget( textLabel1, 0, 0 );

    mlb_ProcTotal = new QListBox( groupBox2, "mlb_ProcTotal" );
    mlb_ProcTotal->setSelectionMode( QListBox::Multi );

    groupBox2Layout->addWidget( mlb_ProcTotal, 1, 0 );

    layout4 = new QVBoxLayout( 0, 0, 6, "layout4"); 
    spacer4 = new QSpacerItem( 20, 105, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout4->addItem( spacer4 );

    mbtn_ShowProc = new QPushButton( groupBox2, "mbtn_ShowProc" );
    mbtn_ShowProc->setMaximumSize( QSize( 40, 32767 ) );
    layout4->addWidget( mbtn_ShowProc );

    mbtn_HideProc = new QPushButton( groupBox2, "mbtn_HideProc" );
    mbtn_HideProc->setMaximumSize( QSize( 40, 32767 ) );
    layout4->addWidget( mbtn_HideProc );
    spacer5 = new QSpacerItem( 20, 104, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout4->addItem( spacer5 );

    groupBox2Layout->addMultiCellLayout( layout4, 0, 1, 1, 1 );

    mlb_ProcShow = new QListBox( groupBox2, "mlb_ProcShow" );
    mlb_ProcShow->setSelectionMode( QListBox::Multi );

    groupBox2Layout->addWidget( mlb_ProcShow, 1, 2 );

    textLabel2 = new QLabel( groupBox2, "textLabel2" );

    groupBox2Layout->addWidget( textLabel2, 0, 2 );

    FFilterLayout->addWidget( groupBox2, 0, 0 );

    groupBox1 = new QGroupBox( centralWidget(), "groupBox1" );
    groupBox1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, groupBox1->sizePolicy().hasHeightForWidth() ) );
    groupBox1->setColumnLayout(0, Qt::Vertical );
    groupBox1->layout()->setSpacing( 6 );
    groupBox1->layout()->setMargin( 11 );
    groupBox1Layout = new QGridLayout( groupBox1->layout() );
    groupBox1Layout->setAlignment( Qt::AlignTop );

    textLabel5 = new QLabel( groupBox1, "textLabel5" );

    groupBox1Layout->addWidget( textLabel5, 0, 0 );

    textLabel6 = new QLabel( groupBox1, "textLabel6" );

    groupBox1Layout->addWidget( textLabel6, 1, 0 );

    m_TimeTotFrom = new QLineEdit( groupBox1, "m_TimeTotFrom" );
    m_TimeTotFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_TimeTotFrom->sizePolicy().hasHeightForWidth() ) );
    m_TimeTotFrom->setReadOnly( TRUE );

    groupBox1Layout->addWidget( m_TimeTotFrom, 1, 1 );

    m_TimeCurFrom = new QLineEdit( groupBox1, "m_TimeCurFrom" );
    m_TimeCurFrom->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_TimeCurFrom->sizePolicy().hasHeightForWidth() ) );
    m_TimeCurFrom->setReadOnly( FALSE );

    groupBox1Layout->addWidget( m_TimeCurFrom, 0, 1 );
    spacer5_2 = new QSpacerItem( 230, 100, QSizePolicy::Minimum, QSizePolicy::Expanding );
    groupBox1Layout->addMultiCell( spacer5_2, 3, 3, 0, 3 );
    spacer14 = new QSpacerItem( 16, 49, QSizePolicy::Expanding, QSizePolicy::Minimum );
    groupBox1Layout->addMultiCell( spacer14, 0, 1, 2, 2 );

    m_TimeTotTo = new QLineEdit( groupBox1, "m_TimeTotTo" );
    m_TimeTotTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_TimeTotTo->sizePolicy().hasHeightForWidth() ) );
    m_TimeTotTo->setReadOnly( TRUE );

    groupBox1Layout->addWidget( m_TimeTotTo, 1, 3 );

    m_TimeCurTo = new QLineEdit( groupBox1, "m_TimeCurTo" );
    m_TimeCurTo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_TimeCurTo->sizePolicy().hasHeightForWidth() ) );
    m_TimeCurTo->setFrameShape( QLineEdit::LineEditPanel );
    m_TimeCurTo->setFrameShadow( QLineEdit::Sunken );
    m_TimeCurTo->setReadOnly( FALSE );

    groupBox1Layout->addWidget( m_TimeCurTo, 0, 3 );

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 

    mbtn_TimeLeft = new QPushButton( groupBox1, "mbtn_TimeLeft" );
    mbtn_TimeLeft->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, mbtn_TimeLeft->sizePolicy().hasHeightForWidth() ) );
    mbtn_TimeLeft->setMaximumSize( QSize( 50, 32767 ) );
    layout7->addWidget( mbtn_TimeLeft );

    mbtn_ZoomOut = new QPushButton( groupBox1, "mbtn_ZoomOut" );
    mbtn_ZoomOut->setMaximumSize( QSize( 50, 32767 ) );
    layout7->addWidget( mbtn_ZoomOut );

    mbtn_ZoomIn = new QPushButton( groupBox1, "mbtn_ZoomIn" );
    mbtn_ZoomIn->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, mbtn_ZoomIn->sizePolicy().hasHeightForWidth() ) );
    mbtn_ZoomIn->setMaximumSize( QSize( 50, 32767 ) );
    layout7->addWidget( mbtn_ZoomIn );

    mbtn_TimeRight = new QPushButton( groupBox1, "mbtn_TimeRight" );
    mbtn_TimeRight->setMaximumSize( QSize( 50, 32767 ) );
    layout7->addWidget( mbtn_TimeRight );

    groupBox1Layout->addMultiCellLayout( layout7, 2, 2, 0, 3 );

    FFilterLayout->addWidget( groupBox1, 0, 1 );

    mbtn_Apply = new QPushButton( centralWidget(), "mbtn_Apply" );
    mbtn_Apply->setToggleButton( FALSE );
    mbtn_Apply->setOn( FALSE );
    mbtn_Apply->setAutoDefault( FALSE );
    mbtn_Apply->setDefault( TRUE );

    FFilterLayout->addMultiCellWidget( mbtn_Apply, 1, 1, 0, 1 );

    // toolbars

    languageChange();
    resize( QSize(544, 384).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( mbtn_Apply, SIGNAL( clicked() ), this, SLOT( ApplyFilter() ) );
    connect( mbtn_ShowProc, SIGNAL( clicked() ), this, SLOT( OnShowProc() ) );
    connect( mbtn_HideProc, SIGNAL( clicked() ), this, SLOT( OnHideProc() ) );

    // tab order
    setTabOrder( m_TimeCurFrom, m_TimeCurTo );
    setTabOrder( m_TimeCurTo, m_TimeTotFrom );
    setTabOrder( m_TimeTotFrom, m_TimeTotTo );
    setTabOrder( m_TimeTotTo, mbtn_TimeLeft );
    setTabOrder( mbtn_TimeLeft, mbtn_ZoomOut );
    setTabOrder( mbtn_ZoomOut, mbtn_ZoomIn );
    setTabOrder( mbtn_ZoomIn, mbtn_TimeRight );
    setTabOrder( mbtn_TimeRight, mlb_ProcTotal );
    setTabOrder( mlb_ProcTotal, mlb_ProcShow );
    setTabOrder( mlb_ProcShow, mbtn_ShowProc );
    setTabOrder( mbtn_ShowProc, mbtn_HideProc );
    setTabOrder( mbtn_HideProc, mbtn_Apply );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FFilter::~FFilter()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FFilter::languageChange()
{
    setCaption( trUtf8( "\xd0\xa4\xd0\xb8\xd0\xbb\xd1\x8c\xd1\x82\xd1\x80" ) );
    groupBox2->setTitle( trUtf8( "\xd0\x9f\xd1\x80\xd0\xbe\xd1\x86\xd0\xb5\xd1\x81\xd1\x81\xd0\xbe\xd1\x80" ) );
    textLabel1->setText( trUtf8( "\xd0\x92\xd1\x81\xd0\xb5\xd0\xb3\xd0\xbe" ) );
    mbtn_ShowProc->setText( tr( ">>" ) );
    mbtn_HideProc->setText( tr( "<<" ) );
    textLabel2->setText( trUtf8( "\xd0\x9f\xd0\xbe\xd0\xba\xd0\xb0\xd0\xb7\xd0\xb0\xd1\x82\xd1\x8c" ) );
    groupBox1->setTitle( trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f" ) );
    textLabel5->setText( trUtf8( "\xd0\xa2\xd0\xb5\xd0\xba\xd1\x83\xd1\x89\xd0\xb5\xd0\xb5" ) );
    textLabel6->setText( trUtf8( "\xd0\x92\xd1\x81\xd0\xb5\xd0\xb3\xd0\xbe" ) );
    mbtn_TimeLeft->setText( tr( "<<<" ) );
    mbtn_ZoomOut->setText( tr( "<->" ) );
    mbtn_ZoomIn->setText( tr( "<+>" ) );
    mbtn_TimeRight->setText( tr( ">>>" ) );
    mbtn_Apply->setText( trUtf8( "\xd0\x9f\xd1\x80\xd0\xb8\xd0\xbc\xd0\xb5\xd0\xbd\xd0\xb8\xd1\x82\xd1\x8c" ) );
}

void FFilter::ApplyFilter()
{
    qWarning( "FFilter::ApplyFilter(): Not implemented yet" );
}

void FFilter::OnShowProc()
{
    qWarning( "FFilter::OnShowProc(): Not implemented yet" );
}

void FFilter::OnHideProc()
{
    qWarning( "FFilter::OnHideProc(): Not implemented yet" );
}

