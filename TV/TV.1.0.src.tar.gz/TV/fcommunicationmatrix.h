/****************************************************************************
** Form interface generated from reading ui file 'fcommunicationmatrix.ui'
**
** Created: Пн 19. июл 14:36:59 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FCOMMUNICATIONMATRIX_H
#define FCOMMUNICATIONMATRIX_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qmainwindow.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
namespace Chart {
class CMatrix;
}
class QButtonGroup;
class QRadioButton;
class QLabel;

class FCommunicationMatrix : public QMainWindow
{
    Q_OBJECT

public:
    FCommunicationMatrix( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~FCommunicationMatrix();

    QButtonGroup* mg_state;
    QRadioButton* mr_volume;
    QRadioButton* mr_count;
    QRadioButton* mr_mean;
    QLabel* textLabel2;
    QLabel* textLabel1;
    Chart::CMatrix* m_martix;

public slots:
    virtual void StateChanged(bool);

protected:
    QGridLayout* FCommunicationMatrixLayout;
    QVBoxLayout* mg_stateLayout;

protected slots:
    virtual void languageChange();

private:
    QPixmap image0;

};

#endif // FCOMMUNICATIONMATRIX_H
