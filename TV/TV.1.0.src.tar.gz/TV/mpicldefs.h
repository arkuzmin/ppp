/***********************************************************************
* MPICL Version 1.0/PICL Version 3.2 (3/1/99)                          *
*  An instrumented message-passing compatibility library and           *
*  PICL instrumentation for MPI                                        *
* written by:                                                          *
*  Patrick Worley of Oak Ridge National Laboratory                     *
*                                                                      *
* Questions and comments should be directed to worleyph@ornl.gov       *
*  Please notify and acknowledge the author in any research or         *
*  publications utilizing PICL, MPICL, or any part of the code.        *
*                                                                      *
* NOTICE: Neither the institution nor the author make any              *
*  representations about the suitability of this software for any      *
*  purpose. This software is provided "as is", without express or      *
*  implied warranty.                                                   *
************************************************************************/

/* tracedefs.h for nodelib */

/************************ trace definitions and variables ******************/

         /**************** external constant definitions ************/

                 /********* record type definitions *************/

                      /* key for event mark */
#define EVENTMARK       -2
                      /* key for event entry */
#define EVENTENTRY      -3
                      /* key for event exit */
#define EVENTEXIT       -4
                      /* key for event label */
#define EVENTLABEL      -5
                      /* key for event data descriptor */
#define EVENTDD         -6
                      /* key for event message */
#define EVENTMESSAGE    -7
                      /* key for time statistics */
#define TIMESTAT      -101
                      /* key for count statistics */
#define COUNTSTAT     -102
                      /* key for send volume statistics */
#define SENDVOLSTAT   -103
                      /* key for receive volume statistics */
#define RECVVOLSTAT   -104
                      /* key for generic size volume statistics */
#define SIZEVOLSTAT   -105
                      /* key for processor subset definition */
#define MACHINESUBSET -201
                      /* key for process subset definition */
#define PROCESSSUBSET -202
                      /* key for event type subset definition */
#define EVENTSUBSET   -203

                 /********* event type definitions *************/

                      /* wildcard for all or any processes */
#define WILDCARD        -1

                      /* -11 - -20: enabling, disabling, and querying */
                      /* status of interprocessor communications */
                      /** key of an open event **/
#define OPENKEY         -11
                      /** key of a close event **/
#define CLOSEKEY        -12
                      /** key of a who event **/
#define WHOKEY          -13
                      /** key of a receive info request event **/
#define RECVINFOKEY     -14
                      /** key of a set message buffering event **/
#define BUFFERKEY       -15
                      /** key of a generic communication **/
                      /** status request event **/
#define COMMCHECKKEY    -16

                      /* -21 - -50: send events */
                      /** key of a generic send event **/
#define SENDKEY          -21
                      /** key of a buffered send event **/
#define BSENDKEY         -22
                      /** key of a synchronous send event **/
#define SSENDKEY         -23
                      /** key of a ready send event **/
#define RSENDKEY         -24
                      /** key of a generic send begin event **/
#define SENDBEGKEY       -27
                      /** key of a "done" generic send status request event **/
#define SENDDONEKEY      -28
                      /** key of a "not done" generic send status request **/
                      /** event **/
#define SENDNOTDONEKEY   -29
                      /** key of a "not blocked" generic send end event **/
#define SENDENDKEY       -30
                      /** key of a "blocked" generic send end event **/
#define SENDENDBLOCKKEY  -31
                      /** key of a "canceled" generic send begin event **/
#define SENDCANCELKEY    -32
                      /** key of a buffered send begin event **/
#define BSENDBEGKEY      -33
                      /** key of a "done" buffered send status request **/
                      /** event **/
#define BSENDDONEKEY     -34
                      /** key of a "not done" buffered send status request **/
                      /** event **/
#define BSENDNOTDONEKEY  -35
                      /** key of a "not blocked" buffered send end event **/
#define BSENDENDKEY      -36
                      /** key of a "blocked" buffered send end event **/
#define BSENDENDBLOCKKEY -37
                      /** key of a "canceled" buffered send begin event **/
#define BSENDCANCELKEY   -38
                      /** key of a synchronous send begin event **/
#define SSENDBEGKEY      -39
                      /** key of a "done" synchronous send status request **/
                      /** event **/
#define SSENDDONEKEY     -40
                      /** key of a "not done" synchronous send status **/
                      /** request event **/
#define SSENDNOTDONEKEY  -41
                      /** key of a "not blocked" synchronous send end event **/
#define SSENDENDKEY      -42
                      /** key of a "blocked" synchronous send end event **/
#define SSENDENDBLOCKKEY -43
                      /** key of a "canceled" synchronous send begin event **/
#define SSENDCANCELKEY   -44
                      /** key of a ready send begin event **/
#define RSENDBEGKEY      -45
                      /** key of a "done" ready send status request **/
                      /** event **/
#define RSENDDONEKEY     -46
                      /** key of a "not done" ready send status request **/
                      /** event **/
#define RSENDNOTDONEKEY  -47
                      /** key of a "not blocked" ready send end event **/
#define RSENDENDKEY      -48
                      /** key of a "blocked" ready send end event **/
#define RSENDENDBLOCKKEY -49
                      /** key of a "canceled" ready send begin event **/
#define RSENDCANCELKEY   -50

                      /* -51 - -80: receive events */
                      /** key of a "not blocked" receive event **/
#define RECVKEY          -51
                      /** key of a "blocked" receive event **/
#define RECVBLOCKKEY     -52
                      /** key of a "found" nonblocking probe event **/
#define FOUNDKEY         -53
                      /** key of a "not found" nonblocking probe event **/
#define NOTFOUNDKEY      -54
                      /** key of a "not blocked" blocking probe event **/
#define WAITKEY          -55
                      /** key of a "blocked" blocking probe event **/
#define WAITBLOCKKEY     -56
                      /** key of a receive begin event **/
#define RECVBEGKEY       -57
                      /** key of a "done" receive status request event **/
#define RECVDONEKEY      -58
                      /** key of a "not done" receive status request event **/
#define RECVNOTDONEKEY   -59
                      /** key of a "not blocked" receive end event **/
#define RECVENDKEY       -60
                      /** key of a "blocked" receive end event **/
#define RECVENDBLOCKKEY  -61
                      /** key of a "canceled" receive begin event **/
#define RECVCANCELKEY    -62

                      /* -201 - -400: disk i/o events */
                      /** key of a "channel/file open" event **/
#define FILEOPENKEY     -201
                      /** key of a "channel/file close" event **/
#define FILECLOSEKEY    -202
                      /** key of a "channel/file write" event **/
#define WRITEKEY        -221
                      /** key of a "channel/file read" event **/
#define READKEY         -251

                      /* -401 - -500: synchronization events */
                      /** key of a "clock sync" event **/
#define CLOCKSYNCKEY    -401
                      /** key of a "barrier" event **/
#define BARRIERKEY      -402

                      /* -501 - -600: resource allocation events */
                      /** key of an "allocate processors" event **/
#define GETPROCSKEY     -501
                      /** key of a "release processors" event **/
#define RELPROCSKEY     -502
                      /** key of a "spawn process" event **/
#define LOADKEY         -503

                      /* -601 - -700: generic labelling events */
                      /** key of a "generic idle block" event **/
#define IDLEKEY         -601
                      /** key of a "generic system overhead" event **/
#define SYSTEMOHKEY     -602
                      /** key of a "generic user overhead" event **/
#define USEROHKEY       -603

                      /* -701 - -800: MPI-specific point-to-point */
                      /* and collective communication events */
                      /* (numbering courtesy of Loretta Ellwood) */
                      /** key of a MPI_Pack event **/
#define PACKKEY        -756
                      /** key of a MPI_Unpack event **/
#define UNPACKKEY      -773
                      /** key of a MPI_Allgather event **/
#define ALLGATHERKEY   -780
                      /** key of a MPI_Allreduce event **/
#define ALLREDUCEKEY   -782
                      /** key of a MPI_Alltoall event **/
#define ALLTOALLKEY    -783
                      /** key of a MPI_Bcast event **/
#define BCASTKEY       -785
                      /** key of a MPI_Gather event **/
#define GATHERKEY      -786
                      /** key of a MPI_Reduce event **/
#define REDUCEKEY      -790
                      /** key of a MPI_Reduce_scatter event **/
#define REDUCESCATTERKEY -791
                      /** key of a MPI_Scan event **/
#define SCANKEY        -792
                      /** key of a MPI_Scatter event **/
#define SCATTERKEY     -793

                      /* -801 - -900: MPI-specific context events */
                      /* (numbering courtesy of Loretta Ellwood) */
                      /* key for MPI_Comm_create event */
#define COMMCREATEKEY      -804
                      /* key for MPI_Comm_dup event */
#define COMMDUPKEY         -805
                      /* key for MPI_Comm_free event */
#define COMMFREEKEY        -806
                      /* key for MPI_Comm_split event */
#define COMMSPLITKEY       -812
                      /* key for MPI_Intercomm_create event */
#define INTERCOMMCREATEKEY -826
                      /* key for MPI_Intercomm_merge event */
#define INTERCOMMMERGEKEY  -827
                      /* key for MPI_Cart_create event */
#define CARTCREATEKEY      -841
                      /* key for MPI_Cart_sub event */
#define CARTSUBKEY         -846
                      /* key for MPI_Graph_create event */
#define GRAPHCREATEKEY     -849

                      /* 901 - -910: tracing set-up and clean-up routines */
                      /** key of "tracenode/host//exit" events **/
#define TRACEKEY       -901
                      /** key of a "trace events" event **/
#define TSTATSKEY      -902
                      /** key of a "trace files" event **/
#define TFILESKEY       -903
                      /** key of a "trace level" event **/
#define TLEVELKEY       -904
                      /** key of a "trace info" event **/
#define TINFOKEY        -905

                      /* -911 - -920: trace save/flushing events */
                      /** key of a "trace message" event **/
#define TMSGKEY         -911
                      /** key of a "trace flush" event **/
#define TFLUSHKEY       -912
                      /** key of a "trace full" event **/
#define TFULLKEY        -913
                      /** key of a "trace overwrite" event **/
#define TWRAPKEY        -914

                      /* -1001 - -2000: predefined subset aliases */
                      /** key for user event subset **/
#define USERSUBSETKEY   -1001
                      /** key for system event subset **/
#define PICLSUBSETKEY   -1002
                      /** key for communication event subset **/
#define COMMSUBSETKEY   -1011
                      /** key for send event subset **/
#define SENDSUBSETKEY   -1012
                      /** key for receive event subset **/
#define RECVSUBSETKEY   -1013
                      /** key for blocked communication event subset **/
#define BLOCKSUBSETKEY  -1014
                      /** key for i/o event subset **/
#define IOSUBSETKEY     -1201
                      /** key for synchronization event subset **/
#define SYNCSUBSETKEY   -1401
                      /** key for resource allocation event subset **/
#define ALLOCSUBSETKEY  -1501
                      /** key for generic event subset **/
#define GENSUBSETKEY    -1601
                      /** key for tracing event subset **/
#define TRACESUBSETKEY  -1901
                      /** key for trace flushing event subset **/
#define FLUSHSUBSETKEY  -1902

                 /********* integer alias definitions *************/

                      /** integer alias for char data descriptor **/
#define CHARTYPE      0
                      /** integer alias for string data descriptor **/
                      /** and short data type (in setdata0) **/
#define STRINGTYPE    1
#define SHORTTYPE     1
                      /** integer alias for int data descriptor **/
#define INTTYPE       2
                      /** integer alias for long data descriptor **/
#define LONGTYPE      3
                      /** integer alias for float data descriptor **/
#define FLOATTYPE     4
                      /** integer alias for double data descriptor **/
#define DOUBLETYPE    5

         /**************** internal constant definitions ****************/

                      /** stat offset of DONE communication event **/
#define DONEOFFSET     1
                      /** stat offset of NOTDONE communication event **/
#define NOTDONEOFFSET  2
                      /** stat offset of END communication event **/
#define ENDOFFSET      3
                      /** stat offset of ENDBLOCK communication event **/
#define ENDBLOCKOFFSET 4
                      /** stat offset of CANCEL communication event **/
#define CANCELOFFSET   5
                      /** pseudo-stat offset for mark events **/
#define MARKOFFSET        5000
                      /** pseudo-stat for send1 mark record **/
#define SENDMARKSTAT      5005
                      /** pseudo-stat for bsend1 mark record **/
#define BSENDMARKSTAT     5006
                      /** pseudo-stat for ssend1 mark record **/
#define SSENDMARKSTAT     5007
                      /** pseudo-stat for rsend1 mark record **/
#define RSENDMARKSTAT     5008
                      /** pseudo-stat for recv1 mark record **/
#define RECVMARKSTAT      5033
                      /** pseudo-stat for fopen mark record **/
#define FILEOPENMARKSTAT  5045
                      /** pseudo-stat for fclose mark record **/
#define FILECLOSEMARKSTAT 5046
                      /** pseudo-stat for write mark record **/
#define WRITEMARKSTAT     5047
                      /** pseudo-stat for read mark record **/
#define READMARKSTAT      5048
                      /** pseudo-stat for idle mark record **/
#define IDLEMARKSTAT      5054
                      /** pseudo-stat for system overhead mark record **/
#define SYSTEMOHMARKSTAT  5055
                      /** pseudo-stat for user overhead mark record **/
#define USEROHMARKSTAT    5056
                      /** pseudo-stat for user event mark record **/
#define USERMARKSTAT      6002
                      /** pseudo-stat for user event entry/exit record **/
#define USEREVENTSTAT     6003
                      /** pseudo-stat for user event label record **/
#define LABELSTAT         6004
                      /** pseudo-stat for user int data record **/
#define INTSTAT           6005
                      /** pseudo-stat for user long data record **/
#define LONGSTAT          6006
                      /** pseudo-stat for user float data record **/
#define FLOATSTAT         6007
                      /** pseudo-stat for user double data record **/
#define DOUBLESTAT        6008
                      /** pseudo-stat for user char data record **/
#define CHARSTAT          6009
                      /** pseudo-stat for sendinit record **/
#define SENDINITSTAT      6027
                      /** pseudo-stat for recvinit record **/
#define RECVINITSTAT      6051
                      /** pseudo-stat for request free record **/
#define REQUESTFREESTAT   6081

