#include "QuickBox.h"

CQuickBox::CQuickBox( QWidget* parent, const char* name )
	:QMessageBox(parent, name)
{
}

CQuickBox::CQuickBox( const QString& caption, const QString &text, Icon icon,
		int button0, int button1, int button2,
		QWidget* parent, const char* name, bool modal, WFlags f)
:QMessageBox(caption, text, icon, button0, button1, button2, parent, name, modal, f)
{
}

CQuickBox::~CQuickBox(void)
{
}

int	CQuickBox::Msg(const QString & text,
		int button0 /* = QMessageBox::Ok */, int button1 /* = 0 */, int button2 /* = 0 */,
		const QString & caption /* = QString("MB") */,
		QWidget * parent /* = NULL */)
{
	return QMessageBox::information(parent, caption, text, button0, button1, button2);
}
