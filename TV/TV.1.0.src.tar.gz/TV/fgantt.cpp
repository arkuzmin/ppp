/****************************************************************************
** Form implementation generated from reading ui file 'fgantt.ui'
**
** Created: Пн 19. июл 14:37:04 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "fgantt.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>

#include "Chart.h"
/*
 *  Constructs a FGantt as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
FGantt::FGantt( QWidget* parent, const char* name, WFlags fl )
    : QMainWindow( parent, name, fl )
{
    (void)statusBar();
    if ( !name )
	setName( "FGantt" );
    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FGanttLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FGanttLayout"); 

    mb_Filter = new QPushButton( centralWidget(), "mb_Filter" );

    FGanttLayout->addWidget( mb_Filter, 2, 1 );
    spacer3 = new QSpacerItem( 31, 240, QSizePolicy::Minimum, QSizePolicy::Expanding );
    FGanttLayout->addItem( spacer3, 3, 1 );

    m_gantt = new Chart::CGanttChart( centralWidget(), "m_gantt" );
    m_gantt->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, m_gantt->sizePolicy().hasHeightForWidth() ) );

    FGanttLayout->addMultiCellWidget( m_gantt, 0, 3, 0, 0 );

    mg_Time = new QButtonGroup( centralWidget(), "mg_Time" );
    mg_Time->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)5, 0, 0, mg_Time->sizePolicy().hasHeightForWidth() ) );
    mg_Time->setColumnLayout(0, Qt::Vertical );
    mg_Time->layout()->setSpacing( 6 );
    mg_Time->layout()->setMargin( 11 );
    mg_TimeLayout = new QGridLayout( mg_Time->layout() );
    mg_TimeLayout->setAlignment( Qt::AlignTop );

    mr_Global = new QRadioButton( mg_Time, "mr_Global" );

    mg_TimeLayout->addMultiCellWidget( mr_Global, 0, 0, 0, 1 );

    mr_Local = new QRadioButton( mg_Time, "mr_Local" );

    mg_TimeLayout->addMultiCellWidget( mr_Local, 1, 1, 0, 1 );

    mb_MakeGlobal = new QPushButton( mg_Time, "mb_MakeGlobal" );

    mg_TimeLayout->addWidget( mb_MakeGlobal, 2, 1 );
    spacer2 = new QSpacerItem( 16, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    mg_TimeLayout->addItem( spacer2, 2, 0 );

    FGanttLayout->addWidget( mg_Time, 0, 1 );

    // toolbars

    languageChange();
    resize( QSize(603, 454).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FGantt::~FGantt()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FGantt::languageChange()
{
    setCaption( trUtf8( "\xd0\x93\xd0\xb0\xd0\xbd\xd1\x82\xd1\x82" ) );
    mb_Filter->setText( trUtf8( "\xd0\xa4\xd0\xb8\xd0\xbb\xd1\x8c\xd1\x82\xd1\x80" ) );
    mg_Time->setTitle( trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f" ) );
    mr_Global->setText( trUtf8( "\xd0\xb3\xd0\xbb\xd0\xbe\xd0\xb1\xd0\xb0\xd0\xbb\xd1\x8c\xd0\xbd\xd0\xbe\xd0\xb5" ) );
    mr_Local->setText( trUtf8( "\xd0\xbb\xd0\xbe\xd0\xba\xd0\xb0\xd0\xbb\xd1\x8c\xd0\xbd\xd0\xbe\xd0\xb5" ) );
    mb_MakeGlobal->setText( trUtf8( "\xd1\x81\xd0\xb4\xd0\xb5\xd0\xbb\xd0\xb0\xd1\x82\xd1\x8c\xd\xa\xd0\xb3\xd0\xbb\xd0\xbe\xd0\xb1\xd0\xb0\xd0\xbb\xd1\x8c\xd0\xbd\xd1\x8b\xd0\xbc" ) );
}

