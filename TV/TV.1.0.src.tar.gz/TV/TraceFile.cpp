#include "TraceFile.h"

#include <qtextstream.h>

#include "Log.h"

const int	c_index_freq	= 1000;

const char	c_field_sep	= ' ';

const char*	c_white_space = " \t";

//class CTraceFilter

CTraceFilter::CTraceFilter()
{
	mpc_record	= NULL;
	mpc_event	= NULL;
	mpc_prss	= NULL;

	mb_time		= false;
	m_time_min	= 0.0;
	m_time_max	= 0.0;
}

CTraceFilter::CTraceFilter(const CTraceFilter& tf)
{
	CopyFrom(tf, false);
}

CTraceFilter& CTraceFilter::operator = (const CTraceFilter& tf)
{
	CopyFrom(tf);

	return *this;
}

CTraceFilter::~CTraceFilter()
{
	ClearConditions();
}
//========================================================================

void	CTraceFilter::CopyFrom(const CTraceFilter& tf, bool clear /* = true */)
{
	if (clear)
		ClearConditions();

	if (tf.mpc_record)
		mpc_record	= tf.mpc_record->GetCopy();
	else
		mpc_record	= NULL;
	if (tf.mpc_event)
		mpc_event	= tf.mpc_event->GetCopy();
	else
		mpc_event	= NULL;
	mb_time		= tf.mb_time;
	m_time_min	= tf.m_time_min;
	m_time_max	= tf.m_time_max;
	mv_proc		= tf.mv_proc;
	if (tf.mpc_prss)
		mpc_prss	= tf.mpc_prss->GetCopy();
	else
		mpc_prss	= NULL;
}
//========================================================================

void	CTraceFilter::ClearConditions()
{
	delete mpc_record;
	mpc_record	= NULL;
	delete mpc_event;
	mpc_event	= NULL;
	delete mpc_prss;
	mpc_prss	= NULL;

	ClearProc();
	ClearTime();
}
//========================================================================

bool	CTraceFilter::SetTime(double start, double end)
{
	if (start > end)
		return false;

	m_time_min = start;
	m_time_max = end;
	mb_time = true;

	return true;
}
//========================================================================

void	CTraceFilter::AddProc(int p)
{
	if (p >= 0)
	{
		if (p >= (int)mv_proc.size())
			mv_proc.resize(p + 1);

		mv_proc[p] = 1;
	}
}
//========================================================================

void	CTraceFilter::RemoveProc(int p)
{
	if (p >= 0)
	{
		if (p < (int)mv_proc.size())
			mv_proc[p] = 0;
	}
}
//========================================================================

int		CTraceFilter::CountProc() const
{
	int c = 0;
	for (size_t i = 0; i < mv_proc.size(); i++)
		if (mv_proc[i] != 0)
			c++;

	return c;
}
//========================================================================

void	CTraceFilter::ClearProc()
{
	mv_proc.clear();
}
//========================================================================

bool	CTraceFilter::Satisfy(const CTraceRecord& r) const
{
	if (!MeetTime(r.GetTime()))
		return false;

	if (!MeetEvent(r.GetEventType()))
		return false;

	if (!MeetProc(r.GetProcessor()))
		return false;

	if (!MeetRecord(r.GetRecType()))
		return false;

	if (!MeetPrss(r.GetProcess()))
		return false;

	return true;
}
//========================================================================

bool	CTraceFilter::MeetRecord(int r) const
{
	if (mpc_record)
		if (!mpc_record->Satisfy(r))
			return false;

	return true;
}
//========================================================================

bool	CTraceFilter::MeetEvent(int e) const
{
	if (mpc_event)
		if (!mpc_event->Satisfy(e))
			return false;

	return true;
}
//========================================================================

bool	CTraceFilter::MeetTime(double t) const
{
	if (!mb_time)
		return true;

	if (t < m_time_min || t > m_time_max)
		return false;

	return true;
}
//========================================================================

bool	CTraceFilter::MeetProc(int proc) const
{
	if (mv_proc.size() == 0)
		return true;

	if (proc >= 0 && proc < (int)mv_proc.size())
		if (mv_proc[proc] != 0)
			return true;

	return false;
}
//========================================================================

bool	CTraceFilter::MeetPrss(int prss) const
{
	if (mpc_prss)
		if (!mpc_prss->Satisfy(prss))
			return false;

	return true;
}
//========================================================================

//class CTraceFilter
//************************************************************************
//************************************************************************



//class CTraceState

CTraceState::CTraceState()
{
}

CTraceState::CTraceState(const CTraceState& ts)
{
	CopyFrom(ts, false);
}

CTraceState& CTraceState::operator = (const CTraceState& ts)
{
	CopyFrom(ts);

	return *this;
}

CTraceState::~CTraceState()
{
	ClearEvents();
}
//========================================================================

void	CTraceState::CopyFrom(const CTraceState& ts, bool clear /* = true */)
{
	if (clear)
		ClearEvents();

	for (TEventCIter it = ts.m_Events.begin(); it != ts.m_Events.end(); ++it)
	{
		m_Events.push_back((*it)->GetCopy());
	}
}
//========================================================================

void	CTraceState::AddActiveEvent(CTraceEvent* pTE)
{
	QString s;
	if (pTE->GetType() == CTraceEvent::E_message)
	{
		CMessageEvent* pME = static_cast<CMessageEvent*>(pTE);

		CLog::Write(L_Reader,
			s.sprintf("CTraceState::AddActiveEvent(): adding message event [%f - ...]\n",
			pME->GetTimeSend()));
	}

	m_Events.push_back(pTE);
}
//========================================================================

void	CTraceState::ClearEvents()
{
	for (TEventIter it = m_Events.begin(); it != m_Events.end(); ++it)
	{
		delete *it;
	}

	m_Events.clear();
}
//========================================================================

CTaskEvent*	CTraceState::FetchActiveTaskEvent(int event, int prc, double cur_time /* = 0.0 */)
{
	if (m_Events.isEmpty())
		return NULL;

	TEventIter it_cur = m_Events.end();
	TEventIter it = m_Events.end();
	while (it != m_Events.begin())
	{
		--it;

		if ((*it)->GetType() == CTraceEvent::E_task)
		{
			CTaskEvent* pTE = static_cast<CTaskEvent*>(*it);

			if (pTE->GetEvent()		== event &&
				pTE->GetProcessor()	== prc)
			{
				if (cur_time != 0.0)	//try to skip events that started at cur_time
					if (pTE->GetTimeStart() == cur_time)
					{
						it_cur = it;
						continue;	//do on seeking
					}

				//target event
				m_Events.remove(it);
				return pTE;
			}
		}
	}

	//may be we have flash tasks...
	if (it_cur != m_Events.end())
	{
		CTaskEvent* pTE = static_cast<CTaskEvent*>(*it_cur);
		m_Events.remove(it_cur);
		return pTE;
	}

	return NULL;
}
//========================================================================

CMessageEvent*	CTraceState::FetchActiveMessageEvent(int sender, int receiver, int type)
{
	if (m_Events.isEmpty())
		return NULL;

	TEventIter it = m_Events.begin();
	while (it != m_Events.end())
	{
		if ((*it)->GetType() == CTraceEvent::E_message)
		{
			CMessageEvent* pME = static_cast<CMessageEvent*>(*it);

			if (pME->GetPrcSend()	== sender &&
				pME->GetPrcRecv()	== receiver &&
				pME->GetMsgType()	== type)
			{
				QString s;
				CLog::Write(L_Reader,
					s.sprintf("CTraceState::FetchActiveMessageEvent(): fetched event [%f - ...]\n",
					pME->GetTimeSend()));

				//target event
				m_Events.remove(it);
				return pME;
			}
		}

		++it;
	}

	return NULL;
}
//========================================================================

int	CTraceState::CountActiveEvents()
{
	return (int)m_Events.count();
}
//========================================================================

void	CTraceState::GetReceivers(const CTraceRecord& r, TIntVec& recv)
{
	recv.clear();

	recv.push_back(CCommunicationRecord::GetCommPrc(r));
}
//========================================================================

void	CTraceState::GetSenders(const CTraceRecord& r, TIntVec& send)
{
	send.clear();

	send.push_back(CCommunicationRecord::GetCommPrc(r));
}
//========================================================================

//class CTraceState
//************************************************************************
//************************************************************************



//class CEventPull

CEventPull::CEventPull()
{
}

CEventPull::~CEventPull()
{
	ClearEvents();
}
//========================================================================

void	CEventPull::AddEvent(CTraceEvent* pTE)
{
	m_Events.push_back(pTE);
}
//========================================================================

CTraceEvent*	CEventPull::FetchEvent()
{
	if (IsEmpty())
		return NULL;

	CTraceEvent* pTE = m_Events.front();
	m_Events.pop_front();

	return pTE;
}
//========================================================================

void	CEventPull::ClearEvents()
{
	for (TEventIter it = m_Events.begin(); it != m_Events.end(); ++it)
	{
		delete *it;
	}

	m_Events.clear();
}
//========================================================================

//class CEventPull
//************************************************************************
//************************************************************************



//class CTraceFile

CTraceFile::CTraceFile(void)
{
	mpc_Communication = NULL;
	InitConditions();

	m_start_time	= 0.0;
	m_end_time		= 0.0;
	m_max_user_task	= 0;
}

CTraceFile::~CTraceFile(void)
{
	ClearConditions();

	Close();
}
//========================================================================

bool	CTraceFile::Open(QString name)
{
	if (IsOpen())
		return false;

	m_trace.setName(name);
	m_trace.open(IO_ReadOnly);

	InitDataFormats();

	return InitTrace();
}
//========================================================================

bool	CTraceFile::Close()
{
	m_dformat.clear();
	m_trace.close();
	return true;
}
//========================================================================

void	CTraceFile::InitDataFormats()
{
	m_dformat.insert(0, "%c");
	m_dformat.insert(1, "%s");
	m_dformat.insert(2, "%d");
	m_dformat.insert(3, "%ld");
	m_dformat.insert(4, "%f");
	m_dformat.insert(5, "%lf");
}
//========================================================================

bool	CTraceFile::InitTrace()
{
	//set times and processors
	//create index

	m_Index.resize(0);
	mv_processors.clear();
	m_max_user_task = -1;
	m_start_time	= 0.0;
	m_end_time		= 0.0;

	CTraceIter it;
	CTraceRecord rec;

	ToTraceStart(it);
	if (!ReadRecord(&rec, it))
		return false;	//no records

	m_start_time = rec.GetTime();
	mv_processors.push_back(rec.GetProcessor());
	if (rec.GetEventType() > m_max_user_task)
		m_max_user_task = rec.GetEventType();

	double t = m_start_time;
	//count proc
	do
	{
		if (!ReadRecord(&rec, it))
			break;

		if (rec.GetEventType() > m_max_user_task)
			m_max_user_task = rec.GetEventType();

		if (rec.GetTime() < t)
			return false;
		t = rec.GetTime();

		int proc = rec.GetProcessor();
		if (qFind(mv_processors.begin(), mv_processors.end(), proc) == mv_processors.end())
		{
			//new processor
			TIntVIter it;
			for (it = mv_processors.begin(); it != mv_processors.end(); it++)
				if (*it > proc)
					break;
			mv_processors.insert(it, proc);
		}
	}
	while (true);

	m_end_time = t;

	m_Index.push_back(SIndex(m_start_time));

	ToTraceStart(it);

	//build index
	int	ev_count = 0;
	CTraceEvent* pTE;
	while (GetTraceEvent(&pTE, it))
	{
		ev_count++;

		if (ev_count % c_index_freq == 0)	//save index
			m_Index.push_back(SIndex(it.GetTime(), it.GetPos(), it.GetTraceState()));
	}

	return true;
}
//========================================================================

bool	CTraceFile::IsOpen()
{
	return m_trace.isOpen();
}
//========================================================================

bool	CTraceFile::ReadRecord(CTraceRecord* pTR, CTraceIter& ti)
{
	return ReadRecordFields(pTR, ti);
}
//========================================================================

bool	CTraceFile::GetTraceEvent(CTraceEvent** ppTE, CTraceIter& ti)
{
	//weather have unprocessed events
	if (!ti.GetEventPull().IsEmpty())
	{
		*ppTE = ti.GetEventPull().FetchEvent();
		return true;
	}

	CTraceFilter* pFlt = ti.GetFilter();
	ti.SetFilter(NULL);

	*ppTE = NULL;

	CEventPull missed;

	bool have_new_event = false;
	do
	{
		CTaskEvent* pTE = NULL;

		if (!ReadRecord(&m_Record, ti))
			break;

		//mark event
		if (m_Record.GetRecType() == EVENTMARK)
		{
			pTE = new CTaskEvent;
			pTE->SetStartRec(m_Record);
			pTE->SetEndRec(m_Record);
			
			//filter it
			if (FilterTaskEvent(pTE, pFlt))
			{
				ti.GetEventPull().AddEvent(pTE);
				have_new_event = true;
			}
			else
			{
				missed.AddEvent(pTE);
			}
		}

		//start
		if (m_Record.GetRecType() == EVENTENTRY)
		{
			bool new_task = true;
			if (pFlt)
			{
				if (pFlt->TimeFiltered())
					if (m_Record.GetTime() > pFlt->GetTimeMax())
						new_task = false;
			}

			if (new_task)
			{
				pTE = new CTaskEvent;
				pTE->SetStartRec(m_Record);

				ti.GetTraceState().AddActiveEvent(pTE);
			}
		}

		//end
		if (m_Record.GetRecType() == EVENTEXIT)
		{
			pTE = ti.GetTraceState().FetchActiveTaskEvent(
				m_Record.GetEventType(), m_Record.GetProcessor(), m_Record.GetTime());
			if (pTE)
			{
				pTE->SetEndRec(m_Record);

				//filter it
				if (FilterTaskEvent(pTE, pFlt))
				{
					ti.GetEventPull().AddEvent(pTE);
					have_new_event = true;
				}
				else
				{
					missed.AddEvent(pTE);
				}
			}
			else
			{
				//debug
				//CQuickBox::Msg(QString("No start event for \n") + m_Record.ToString());
			}
		}

		//task record
		if (pTE)
		{
			//message send
			if (MessageSend(m_Record))
			{
				if (CCommunicationRecord::HaveSendData(m_Record))
				{
					TIntVec recv;
					ti.GetTraceState().GetReceivers(m_Record, recv);

					for (size_t i = 0; i < recv.size(); i++)
					{
						CMessageEvent* pM = new CMessageEvent;

						pM->SetSender(m_Record);
						pM->SetReciever(recv[i]);
						pM->SetTimeSend(pTE->GetTimeStart());

						ti.GetTraceState().AddActiveEvent(pM);
					}
				}
			}

			//message recv
			if (MessageRecv(m_Record))
			{
				if (CCommunicationRecord::HaveRecvData(m_Record))
				{
					TIntVec send;
					ti.GetTraceState().GetSenders(m_Record, send);

					int msg_type = CCommunicationRecord::GetType(m_Record);
					for (size_t i = 0; i < send.size(); i++)
					{
						CMessageEvent* pM = ti.GetTraceState().FetchActiveMessageEvent(
							send[i], m_Record.GetProcessor(), msg_type);
						if (pM)
						{
							pM->SetTimeRecv(pTE->GetTimeEnd());

							if (FilterMessageEvent(pM, pFlt))
							{
								ti.GetEventPull().AddEvent(pM);
								have_new_event = true;
							}
							else
							{
								missed.AddEvent(pM);
							}
						}
					}
				}
			}//message recv
		}
	}
	while (!have_new_event);

	ti.SetFilter(pFlt);

	if (have_new_event)
	{
		*ppTE = ti.GetEventPull().FetchEvent();
		return true;
	}
	else	//read error
	{
		*ppTE = NULL;
		return false;
	}
}
//========================================================================

bool	CTraceFile::ToTraceStart(CTraceIter& ti)
{
	if (!IsOpen())
		return false;

	ti.SetPos(0);
	ti.SetTime(m_start_time);

	ti.GetEventPull().ClearEvents();
	ti.GetTraceState().ClearEvents();

	return true;
}
//========================================================================

bool	CTraceFile::ToIterStart(CTraceIter& ti)
{
	if (!ti.GetFilter()->TimeFiltered())
		return ToTraceStart(ti);

	if (m_Index.isEmpty())	//no index :(
		return ToTraceStart(ti);

	if (!IsOpen())
		return false;

	double start_time = ti.GetFilter()->GetTimeMin();

	size_t i = 0;
	for (i = 0; i < m_Index.size(); i++)
		if (m_Index[i].time > start_time)
			break;
	if (i > 0)
		i--;

	ti.SetPos(m_Index[i].file_pos);
	ti.SetTime(m_Index[i].time);
	ti.SetTraceState(m_Index[i].state);

	ti.GetEventPull().ClearEvents();

	return true;
}
//========================================================================

bool	CTraceFile::IsCommunicationRecord(int r)
{
	if (!mpc_Communication)
		return false;
	return mpc_Communication->Satisfy(r);
}
//========================================================================

bool	CTraceFile::MessageSend(const CTraceRecord& m_Record)
{
	if (MessageSend(m_Record.GetEventType()) &&
		m_Record.GetRecType() == EVENTENTRY)
	{
		return true;
	}

	return false;
}
//========================================================================

bool	CTraceFile::MessageRecv(const CTraceRecord& m_Record)
{
	if (MessageRecv(m_Record.GetEventType()) &&
		m_Record.GetRecType() == EVENTEXIT)
	{
		return true;
	}

	return false;
}
//========================================================================

bool	CTraceFile::MessageSend(int event)
{
	if (event == SENDKEY ||
		event == BSENDKEY ||
		event == SSENDKEY ||
		event == RSENDKEY ||
		event == SENDBEGKEY ||
		event == BSENDBEGKEY ||
		event == SSENDBEGKEY ||
		event == RSENDBEGKEY)
	{
		return true;
	}

	return false;
}
//========================================================================

bool	CTraceFile::MessageRecv(int event)
{
	if (event == RECVKEY ||
		event == RECVBLOCKKEY ||
		event == RECVDONEKEY ||
		event == RECVENDKEY ||
		event == RECVENDBLOCKKEY)
	{
		return true;
	}

	return false;
}
//========================================================================

QString	CTraceFile::GetMPIEventName(int e)
{
	switch (e)
	{
	case -21:	return "MPI_Send";
	case -22:	return "MPI_Bsend";
	case -23:	return "MPI_Ssend";
	case -24:	return "MPI_Rsend";
	case -27:	return "MPI_Isend";
	case -28:	return "MPI_Test OK";
	case -30:	return "MPI_Wait (nb)";
	case -31:	return "MPI_Wait (b)";
	case -33:	return "MPI_Ibsend";
	case -34:	return "MPI_Test OK";
	case -36:	return "MPI_Wait (nb)";
	case -37:	return "MPI_Wait (b)";
	case -39:	return "MPI_Issend";
	case -40:	return "MPI_Test OK";
	case -42:	return "MPI_Wait (nb)";
	case -43:	return "MPI_Wait (b)";
	case -45:	return "MPI_Irsend";
	case -46:	return "MPI_Test OK";
	case -48:	return "MPI_Wait (nb)";
	case -49:	return "MPI_Wait (b)";
	case -51:	return "MPI_Recv (nb)";
	case -52:	return "MPI_Recv (b)";
	case -57:	return "MPI_Irecv";
	case -58:	return "MPI_Test OK";
	case -60:	return "MPI_Wait (nb)";
	case -61:	return "MPI_Wait (b)";
	case -402:	return "MPI_Barrier";
	case -756:	return "MPI_Pack";
	case -773:	return "MPI_Unpack";
	case -780:	return "MPI_Allgather";
	case -782:	return "MPI_Allreduce";
	case -783:	return "MPI_Alltoall";
	case -785:	return "MPI_Bcast";
	case -786:	return "MPI_Gather";
	case -790:	return "MPI_Reduce";
	case -791:	return "MPI_Reducescatter";
	case -792:	return "MPI_Scan";
	case -793:	return "MPI_Scatter";
//	case -21:	return "MPI_Send";
	}
	
	QString s = "MPI_";
	s += QString::number(e);
	return s;
}
//========================================================================

QString	CTraceFile::GetTaskEventName(int e)
{
	QString s = "Task ";
	s += QString::number(e);
	return s;
}
//========================================================================

void	CTraceFile::MakeCommunicationFilter(CTraceFilter& tf)
{
	if (mpc_Communication)
		tf.SetEventCond(*mpc_Communication);
}
//========================================================================

void	CTraceFile::MakeMPIRoutineFilter(CTraceFilter& tf)
{
	CCondBetween<int> c_ptp(RECVCANCELKEY, SENDKEY);
	CCondBetween<int> c_sync(BARRIERKEY, CLOCKSYNCKEY);
	CCondBetween<int> c_coll(GRAPHCREATEKEY, PACKKEY);

	CCondOr<int>	c_mpi;
	c_mpi.AddCondition(&c_ptp);
	c_mpi.AddCondition(&c_sync);
	c_mpi.AddCondition(&c_coll);

	tf.SetEventCond(c_mpi);
}
//========================================================================

void	CTraceFile::MakeTasksFilter(CTraceFilter& tf)
{
	CCondBetween<int> c_task(0, m_max_user_task);

	tf.SetEventCond(c_task);
}
//========================================================================

QString	CTraceFile::DataFormat(const QString& s)
{
	bool res;
	int id = s.toInt(&res);

	if (res)	//format id
	{
		return m_dformat[id];
	}
	else	//raw format
	{
		return s;
	}
}
//========================================================================

void	CTraceFile::InitConditions()
{
	ClearConditions();

	mpc_Communication = new CCondBetween<int>(RECVCANCELKEY, SENDKEY);
}
//========================================================================

void	CTraceFile::ClearConditions()
{
	delete mpc_Communication;
	mpc_Communication = NULL;
}
//========================================================================

QIODevice::Offset	CTraceFile::LocatePosition(double time)
{
	for (size_t i = 0; i < m_Index.size(); i++)
		if (m_Index[i].time >= time)
			return m_Index[i].file_pos;

	return (QIODevice::Offset)-1;
}
//========================================================================

bool	CTraceFile::ReadRecordFields(CTraceRecord* pTR, CTraceIter& ti)
{
	if (!m_trace.isOpen())
		return false;

	QTextStream ts(&m_trace);
//	QTextStream ts(m_data, IO_ReadOnly);

	QString s;
	const char* p_rec = NULL;
	int line = 0;
	do
	{
		line++;

		m_trace.at(ti.GetPos());
		s = ts.readLine();
		ti.SetPos(m_trace.at());

		p_rec = NULL;

		if (s.isEmpty())
		{
			if (ts.atEnd())
				return false;
			else
				continue;
		}

		p_rec = s.data();
		p_rec += strspn(p_rec, c_white_space);
		pTR->SetRecType(	atoi(p_rec));
		p_rec += strspn(p_rec, c_white_space); p_rec += strcspn(p_rec, c_white_space);
		pTR->SetEventType(	atoi(p_rec));
		p_rec += strspn(p_rec, c_white_space); p_rec += strcspn(p_rec, c_white_space);
		pTR->SetTime(		atof(p_rec));
		p_rec += strspn(p_rec, c_white_space); p_rec += strcspn(p_rec, c_white_space);
		int proc = atoi(p_rec);
		int pr_id = GetProcessorID(proc);
		pTR->SetProcessor(	pr_id != -1 ? pr_id : proc);
		p_rec += strspn(p_rec, c_white_space); p_rec += strcspn(p_rec, c_white_space);
		pTR->SetProcess(	atoi(p_rec));
		p_rec += strspn(p_rec, c_white_space); p_rec += strcspn(p_rec, c_white_space);

		//pTR->SetRecType		(s.section(c_field_sep, f_record,		f_record).toInt());
		//pTR->SetEventType	(s.section(c_field_sep, f_event,		f_event).toInt());
		//pTR->SetTime		(s.section(c_field_sep, f_time,			f_time).toDouble());
		//pTR->SetProcessor	(s.section(c_field_sep, f_processor,	f_processor).toInt());
		//pTR->SetProcess		(s.section(c_field_sep, f_process,		f_process).toInt());

		ti.SetTime(pTR->GetTime());

		if (ti.GetFilter())
		{
			//if (ti.GetFilter()->Satisfy(*pTR))	//found event
			if (ti.GetFilter()->MeetTime(pTR->GetTime()))	//found event
				break;
		}
		else
		{
			break;	//read one and all
		}
	}
	while (true);

	if (p_rec)
	{
		int count = atoi(p_rec);
		//int count = s.section(c_field_sep, f_data_count,		f_data_count).toInt();
		if (count > 0)
		{
			pTR->DataFromString(count,
				DataFormat(s.section(c_field_sep, f_data_type, f_data_type)),
				s.section(c_field_sep, f_data));
		}
		else
		{
			pTR->ClearData();
		}
	}

	return true;
}
//========================================================================

bool	CTraceFile::FilterTaskEvent(CTaskEvent* ev, const CTraceFilter* flt)
{
	if (flt)
	{
		if (flt->TimeFiltered())
		{
			if (ev->GetTimeEnd() < flt->GetTimeMin() ||
				ev->GetTimeStart() > flt->GetTimeMax())
			{
				return false;
			}

			if (ev->GetTimeStart() < flt->GetTimeMin())
				ev->SetTimeStart(flt->GetTimeMin());

			if (ev->GetTimeEnd() > flt->GetTimeMax())
				ev->SetTimeEnd(flt->GetTimeMax());
		}
	}

	return true;
}
//========================================================================

bool	CTraceFile::FilterMessageEvent(CMessageEvent* ev, const CTraceFilter* flt)
{
	if (flt)
	{
		if (flt->TimeFiltered())
		{
			if (flt->MeetTime(ev->GetTimeRecv()))	//ended here
			{
				if (ev->GetTimeSend() < flt->GetTimeMin())
					ev->SetTimeSend(flt->GetTimeMin());
			}
			else	//ended before
			{
				return false;
			}
		}
	}

	return true;
}
//========================================================================

int	CTraceFile::GetProcessorID(int name) const
{
	for (size_t i = 0; i < mv_processors.size(); i++)
		if (mv_processors[i] == name)
			return i;

	return -1;
}
//========================================================================

//class CTraceFile
//************************************************************************
//************************************************************************
