/****************************************************************************
** Form implementation generated from reading ui file 'dlgabout.ui'
**
** Created: Пн 19. июл 07:56:02 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "dlgabout.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a DlgAbout as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
DlgAbout::DlgAbout( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "DlgAbout" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, sizePolicy().hasHeightForWidth() ) );
    DlgAboutLayout = new QGridLayout( this, 1, 1, 11, 6, "DlgAboutLayout"); 

    textLabel1 = new QLabel( this, "textLabel1" );

    DlgAboutLayout->addWidget( textLabel1, 0, 0 );

    btnOK = new QPushButton( this, "btnOK" );

    DlgAboutLayout->addWidget( btnOK, 0, 1 );
    languageChange();
    resize( QSize(227, 58).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( btnOK, SIGNAL( clicked() ), this, SLOT( close() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
DlgAbout::~DlgAbout()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void DlgAbout::languageChange()
{
    setCaption( trUtf8( "\xd0\x9e\x20\xd0\xbf\xd1\x80\xd0\xbe\xd0\xb3\xd1\x80\xd0\xb0\xd0\xbc\xd0\xbc\xd0\xb5" ) );
    textLabel1->setText( trUtf8( "\x54\x56\x20\x31\x2e\x30\xd\xa\x28\x63\x29\x20\xd0\x9a\xd0\xb0\xd1\x81\xd1\x82\xd0\xb5\xd0\xbb\xd0\xb8\xd0\xbd\x20\xd0\x90\x2e\xd0\x9d\x2e\x2c\x20\x32\x30\x30\x34" ) );
    btnOK->setText( tr( "OK" ) );
}

