#include "FilterWindow.h"

#include "TraceFile.h"
#include <qlineedit.h>
#include <qlistbox.h>
#include <qpushbutton.h>

#include "Log.h"

const int	c_full_time		= 0xfffff;
const int	c_line_fraction	= 10;

const double	c_move_fraction	= 0.5;
const double	c_zoom_fraction	= 3.0;

CFilterWindow::CFilterWindow(CTraceManager* pTM, IFilterable* pF, QWidget* parent, WFlags fl)
	:FFilter(parent, "TimeFrame", fl)
{
	mp_TrManager	= pTM;

	mp_FilterOwner = pF;
	mp_FilterOwner->SetFilterWindow(this);

	connect(mbtn_TimeLeft, SIGNAL(clicked()), SLOT(OnBtnTimeLeft()));
	connect(mbtn_TimeRight, SIGNAL(clicked()), SLOT(OnBtnTimeRight()));
	connect(mbtn_ZoomIn, SIGNAL(clicked()), SLOT(OnBtnZoomIn()));
	connect(mbtn_ZoomOut, SIGNAL(clicked()), SLOT(OnBtnZoomOut()));

	FilterChanged();
}

CFilterWindow::~CFilterWindow(void)
{
	mp_FilterOwner->SetFilterWindow(NULL);
}
//========================================================================

void	CFilterWindow::FilterChanged()
{
	CLog::Write(L_GUI, "CFilterWindow::FilterChanged(): start\n");

	double tr_s = mp_TrManager->GetStartTime();
	double tr_e = mp_TrManager->GetEndTime();

	m_TimeTotFrom->setText(QString::number(tr_s));
	m_TimeTotTo->setText(QString::number(tr_e));

	double cur_s, cur_e;
	if (!mp_FilterOwner->GetFilterTime(cur_s, cur_e))
	{
		cur_s = tr_s;
		cur_e = tr_e;
	}

	m_TimeCurFrom->setText(QString::number(cur_s));
	m_TimeCurTo->setText(QString::number(cur_e));

	int n_proc = mp_TrManager->GetProcessorsCount();

	ml_TotalProc.clear();
	mlb_ProcTotal->clear();
	ml_FilterProc.clear();
	mlb_ProcShow->clear();
	for (int i = 0; i < n_proc; i++)
	{
		if (mp_FilterOwner->IsProcLegal(i))
			AddProc(i, mlb_ProcShow, ml_FilterProc);
		else
			AddProc(i, mlb_ProcTotal, ml_TotalProc);
	}

	CLog::Write(L_GUI, "CFilterWindow::FilterChanged(): return\n");
}
//========================================================================

void	CFilterWindow::ApplyFilter()
{
	CLog::Write(L_GUI, "CFilterWindow::ApplyFilter(): start\n");

	double cur_s = m_TimeCurFrom->text().toDouble();
	double cur_e = m_TimeCurTo->text().toDouble();

	if (!ValidateTime(cur_s, cur_e))
		return;

	TIntVec proc;
	proc.resize(ml_FilterProc.size());
	size_t i = 0;
	TIntLIter it;
	for (it = ml_FilterProc.begin(), i = 0;
		it != ml_FilterProc.end(); ++it, i++)
	{
		proc[i] = *it;
	}

	mp_FilterOwner->ChangeFilter(cur_s, cur_e, proc, this);

	CLog::Write(L_GUI, "CFilterWindow::ApplyFilter(): return\n");
}
//========================================================================

void	CFilterWindow::OnShowProc()
{
	TIntLIter it = ml_TotalProc.begin();
	uint i = 0;
	while (i < mlb_ProcTotal->count())
	{
		if (mlb_ProcTotal->isSelected(i))
		{
			int p = *it;

			it = ml_TotalProc.remove(it);
			mlb_ProcTotal->removeItem(i);

			AddProc(p, mlb_ProcShow, ml_FilterProc);
		}
		else
		{
			i++;
			it++;
		}
	}
}
//========================================================================

void	CFilterWindow::OnHideProc()
{
	TIntLIter it = ml_FilterProc.begin();
	uint i = 0;
	while (i < mlb_ProcShow->count())
	{
		if (mlb_ProcShow->isSelected(i) && mlb_ProcShow->count() > 1)
		{
			int p = *it;

			it = ml_FilterProc.remove(it);
			mlb_ProcShow->removeItem(i);

			AddProc(p, mlb_ProcTotal, ml_TotalProc);
		}
		else
		{
			i++;
			it++;
		}
	}
}
//========================================================================

void CFilterWindow::OnBtnTimeLeft()
{
	double cur_s = m_TimeCurFrom->text().toDouble();
	double cur_e = m_TimeCurTo->text().toDouble();

	if (!ValidateTime(cur_s, cur_e))
		return;

	double move = (cur_e - cur_s) * c_move_fraction;
	cur_s -= move;
	cur_e -= move;

	if (!ValidateTime(cur_s, cur_e))
		return;

	m_TimeCurFrom->setText(QString::number(cur_s));
	m_TimeCurTo->setText(QString::number(cur_e));
}
//========================================================================

void CFilterWindow::OnBtnTimeRight()
{
	double cur_s = m_TimeCurFrom->text().toDouble();
	double cur_e = m_TimeCurTo->text().toDouble();

	if (!ValidateTime(cur_s, cur_e))
		return;

	double move = (cur_e - cur_s) * c_move_fraction;
	cur_s += move;
	cur_e += move;

	if (!ValidateTime(cur_s, cur_e))
		return;

	m_TimeCurFrom->setText(QString::number(cur_s));
	m_TimeCurTo->setText(QString::number(cur_e));
}
//========================================================================

void CFilterWindow::OnBtnZoomIn()
{
	double cur_s = m_TimeCurFrom->text().toDouble();
	double cur_e = m_TimeCurTo->text().toDouble();

	if (!ValidateTime(cur_s, cur_e))
		return;

	double c = (cur_e + cur_s) * 0.5;
	double zoom = (cur_e - cur_s) / c_zoom_fraction * 0.5;
	cur_s = c - zoom;
	cur_e = c + zoom;

	if (!ValidateTime(cur_s, cur_e))
		return;

	m_TimeCurFrom->setText(QString::number(cur_s));
	m_TimeCurTo->setText(QString::number(cur_e));
}
//========================================================================

void CFilterWindow::OnBtnZoomOut()
{
	double cur_s = m_TimeCurFrom->text().toDouble();
	double cur_e = m_TimeCurTo->text().toDouble();

	if (!ValidateTime(cur_s, cur_e))
		return;

	double c = (cur_e + cur_s) * 0.5;
	double zoom = (cur_e - cur_s) * c_zoom_fraction * 0.5;
	cur_s = c - zoom;
	cur_e = c + zoom;

	if (!ValidateTime(cur_s, cur_e))
		return;

	m_TimeCurFrom->setText(QString::number(cur_s));
	m_TimeCurTo->setText(QString::number(cur_e));
}
//========================================================================

void	CFilterWindow::AddProc(int proc, QListBox* lb, TIntList& list)
{
	TIntLIter it;
	uint i;
	for (it = list.begin(), i = 0; it != list.end(); ++it, i++)
	{
		if (*it == proc)
			return;	//already here

		if (*it > proc)
			break;
	}

	list.insert(it, proc);
	lb->insertItem(mp_TrManager->GetProcessorName(proc), i);
}
//========================================================================

void	CFilterWindow::DelProc(int proc, QListBox* lb, TIntList& list)
{
	TIntLIter it;
	uint i;
	for (it = list.begin(), i = 0; it != list.end(); ++it, i++)
	{
		if (*it == proc)
		{
			list.remove(it);
			lb->removeItem(i);

			return;
		}
	}
}
//========================================================================

bool	CFilterWindow::ValidateTime(double& s, double& e)
{
	if (s >= e)
		return false;

	double tr_s = mp_TrManager->GetStartTime();
	double tr_e = mp_TrManager->GetEndTime();

	if (s > tr_e || e < tr_s)
		return false;

	if (s < tr_s)
		s = tr_s;
	if (e > tr_e)
		e = tr_e;

	return true;
}
//========================================================================
