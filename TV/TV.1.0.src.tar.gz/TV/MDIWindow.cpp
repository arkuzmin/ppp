#include "MDIWindow.h"
#include <qhbox.h>
#include <qfiledialog.h>
#include <qdesktopwidget.h>

#include "dlgabout.h"
#include "TraceEvent.h"
#include "FilterWindow.h"
#include "TVCommunicationMatrix.h"
#include "TVActivitySummary.h"
#include "TVGantt.h"
#include "TVTask.h"

CMDIWindow::CMDIWindow(QWidget* parent /* = 0 */,
					   const char* name /* = 0 */,
					   WFlags f /* = WType_TopLevel */)
	:FMDIWindow(parent, name, f)
{
	m_Trace.SetFWOwner(this);

	mp_TimeFrame	= NULL;

	QHBox* phb = new QHBox(this);
	phb->setFrameStyle(QFrame::StyledPanel | QFrame::Sunken);
	mp_Workspace = new QWorkspace(phb);
	setCentralWidget(phb);

	ms_Title = "TV";
}

CMDIWindow::~CMDIWindow(void)
{
	delete mp_Workspace;
}
//========================================================================

void	CMDIWindow::CreateChild()
{
	QMainWindow* pw = new QMainWindow(mp_Workspace, NULL, 0);
	pw->show();
}
//========================================================================

void CMDIWindow::fileOpen()
{
	QString f_name = QFileDialog::getOpenFileName();
	if (f_name.isEmpty())
		return;

	CloseTrace();

	OpenTrace(f_name);
}
//========================================================================

void CMDIWindow::fileClose()
{
	CloseTrace();
}
//========================================================================

void CMDIWindow::fileExit()
{
	if (!CloseTrace())
		return;

	FMDIWindow::fileClose();

	close();
}
//========================================================================

void CMDIWindow::helpAbout()
{
	DlgAbout* pD = new DlgAbout(this, "about", true);
	pD->exec();
}
//========================================================================

void CMDIWindow::DisplayComunications()
{
	CTVCommunicationMatrix* pC = new CTVCommunicationMatrix(&m_Trace, mp_Workspace); 
	InitChild(pC);
	
	m_Trace.StartReadTrace(pC);
}
//========================================================================

void	CMDIWindow::DisplayLoad()
{
	CTVActivitySummary* pA = new CTVActivitySummary(&m_Trace, mp_Workspace);
	InitChild(pA);
	
	m_Trace.StartReadTrace(pA);
}
//========================================================================

void	CMDIWindow::DisplayGantt()
{
	CTVGantt* pG = new CTVGantt(&m_Trace, mp_Workspace, this);
	InitChild(pG);
	
	m_Trace.StartReadTrace(pG);
}
//========================================================================

void	CMDIWindow::DisplayTasks()
{
	CTVTask* pT = new CTVTask(&m_Trace, mp_Workspace);
	InitChild(pT);
	
	m_Trace.StartReadTrace(pT);
}
//========================================================================

void	CMDIWindow::OnFilter()
{
	ShowFilter(&m_Trace);
}
//========================================================================

bool	CMDIWindow::OpenTrace(QString name)
{
	bool res = m_Trace.OpenTrace(name);
	RefreshCaption();

	return res;
}
//========================================================================

bool	CMDIWindow::CloseTrace()
{
	mp_Workspace->closeAllWindows();

	bool res = m_Trace.CloseTrace();
	RefreshCaption();

	return res;
}
//========================================================================

void	CMDIWindow::InitChild(QMainWindow* pW)
{
	QDesktopWidget dt;
	int ww = pW->maximumWidth();
	int sw = dt.availableGeometry(pW).width();
	pW->setMaximumWidth(min(ww, sw));

	pW->show();
}
//========================================================================

void	CMDIWindow::ShowFilter(IFilterable* f)
{
	if (f->GetFilterWindow())
	{
		static_cast<CFilterWindow*>(f->GetFilterWindow())->showNormal();
	}
	else
	{
		CFilterWindow* pFW = new CFilterWindow(&m_Trace, f, mp_Workspace);
		InitChild(pFW);
	}
}
//========================================================================

void	CMDIWindow::HideFilter(IFilterable* f)
{
	if (f->GetFilterWindow())
	{
		delete f->GetFilterWindow();
	}
}
//========================================================================

void	CMDIWindow::setCaption(const QString&)
{
	RefreshCaption();
}
//========================================================================

void	CMDIWindow::RefreshCaption()
{
	QMainWindow::setCaption(FormatCaption());
}
//========================================================================

QString	CMDIWindow::FormatCaption()
{
	QString c = ms_Title;
	if (m_Trace.IsTraceOpened())
		c += QString(" - ") + m_Trace.GetTraceName();

	return c;
}
//========================================================================
