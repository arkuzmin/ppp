#include "TraceEvent.h"

#include "TraceFile.h"

const int	c_max_str_len	= 1000;
const int	c_data_grow		= 10;

//class CTraceRecord

CTraceRecord::CTraceRecord(/*CTraceFile* pT, */int r, int e, double t, int pr, int pss)
{
//	mp_Trace = pT;

	m_record	= r;
	m_event		= e;
	m_time		= t;
	m_processor	= pr;
	m_process	= pss;
}

CTraceRecord::CTraceRecord(const CTraceRecord& tr)
{
	CopySelf(tr);
}

CTraceRecord&	CTraceRecord::operator = (const CTraceRecord& tr)
{
	CopySelf(tr);

	return *this;
}

CTraceRecord::~CTraceRecord(void)
{
	ClearData();
}
//========================================================================

void	CTraceRecord::CopySelf(const CTraceRecord& tr)
{
	ClearData();

	m_record	= tr.m_record;
	m_event		= tr.m_event;
	m_time		= tr.m_time;
	m_processor	= tr.m_processor;
	m_process	= tr.m_process;

	m_data.resize(tr.m_data.size());
	for (size_t i = 0; i < m_data.size(); i++)
	{
		if (tr.m_data[i].type == STRINGTYPE)	//string
		{
			m_data[i].type	= tr.m_data[i].type;
			m_data[i].data.d_string	= new QString(*tr.m_data[i].data.d_string);
		}
		else	//plain data
		{
			m_data[i] = tr.m_data[i];
		}
	}
}
//========================================================================

void	CTraceRecord::ClearData()
{
	for (size_t i = 0; i < m_data.size(); i++)
	{
		if (m_data[i].type == STRINGTYPE)
			delete m_data[i].data.d_string;
	}

	m_data.resize(0);
}
//========================================================================


bool	CTraceRecord::DataFromString(int count, const QString& format,
									const QString& data)
{
	if (count == 0 ||
		format.isEmpty() ||
		data.isEmpty())
	{
		return false;
	}

	int data_pos = 0;

	m_data.resize(0);
	m_data.reserve(c_data_grow);

	for (int i = 0; i < count; i++)	//format
	{
		int fpos = 0;

		while ((fpos = format.find('%', fpos)) != -1)
		{
			char true_format[10];
			int type = -1;

			fpos++;	//points to next to '%' char
			if ((int)format.length() < fpos)
				return false;
			char ch = format.at(fpos);
			switch (ch)
			{
			case 'c':
				strcpy(true_format, "%c");
				type = CHARTYPE;
				break;
			case 'd':
				strcpy(true_format, "%d");
				type = INTTYPE;
				break;
			case 'f':
				strcpy(true_format, "%f");
				type = FLOATTYPE;
				break;
			case 's':
				strcpy(true_format, "%s");
				type = STRINGTYPE;
				break;
			case 'l':
				fpos++;	//points to 2-nd char from '%'
				if ((int)format.length() < fpos)
					return false;
				ch = format.at(fpos);
				switch (ch)
				{
				case 'd':
					strcpy(true_format, "%ld");
					type = LONGTYPE;
					break;
				case 'f':
					strcpy(true_format, "%lf");
					type = DOUBLETYPE;
					break;
				}
				break;
			}

			strcpy(true_format + strlen(true_format), "%n");

			if (m_data.size() == m_data.capacity())
				m_data.reserve(m_data.size() + c_data_grow);

			int read;
			//read data
			switch (type)
			{
			case CHARTYPE:
			{
				char ch;
				sscanf((const char*)data + data_pos, true_format, &ch, &read);
				m_data.push_back(SData(ch));
				break;
			}
			case STRINGTYPE:
			{
				char* str = new char[c_max_str_len + 1];
				sscanf((const char*)data + data_pos, true_format, str, &read);
				m_data.push_back(SData(new QString(str)));
				delete str;
				break;
			}
			case INTTYPE:
			{
				int i;
				sscanf((const char*)data + data_pos, true_format, &i, &read);
				m_data.push_back(SData(i));
				break;
			}
			case LONGTYPE:
			{
				long l;
				sscanf((const char*)data + data_pos, true_format, &l, &read);
				m_data.push_back(SData((int)l));
				break;
			}
			case FLOATTYPE:
			{
				float f;
				sscanf((const char*)data + data_pos, true_format, &f, &read);
				m_data.push_back(SData(f));
				break;
			}
			case DOUBLETYPE:
			{
				double d;
				sscanf((const char*)data + data_pos, true_format, &d, &read);
				m_data.push_back(SData(d));
				break;
			}
			}

			data_pos += read;
		}
	}

	return true;
}
//========================================================================

QString	CTraceRecord::ToString() const
{
	QString s;
	s.sprintf("record = %d\nevent = %d\ntime = %f\nprc = %d\nprss = %d",
		m_record, m_event, m_time, m_processor, m_process);

	return s;
}
//========================================================================

//class CTraceRecord
//************************************************************************
//************************************************************************



//class CCommunicationRecord

CCommunicationRecord::CCommunicationRecord(/*CTraceFile* pT, int r, int e, double t, int pr, int pss*/)
	:CTraceRecord(/*pT, r, e, t, pr, pss*/)
{
}

CCommunicationRecord::~CCommunicationRecord()
{
}
//========================================================================

bool	CCommunicationRecord::HaveSendData() const
{
	if (CTraceFile::MessageSend(*this))
		if (m_data.size() >= 3)
			return true;

	return false;
}
//========================================================================

bool	CCommunicationRecord::HaveRecvData() const
{
	if (CTraceFile::MessageRecv(*this))
		if (m_data.size() >= 3)
			return true;

	return false;
}
//========================================================================

bool	CCommunicationRecord::HaveSendData(const CTraceRecord& tr)
{
	if (CTraceFile::MessageSend(tr))
		if (tr.CountData() >= 3)
			return true;

	return false;
}
//========================================================================

bool	CCommunicationRecord::HaveRecvData(const CTraceRecord& tr)
{
	if (CTraceFile::MessageRecv(tr))
		if (tr.CountData() >= 3)
			return true;

	return false;
}
//========================================================================

int	CCommunicationRecord::GetLength(const CTraceRecord& tr)
{
	if (tr.CountData() >= 1)
		return tr.GetData(0).data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetType(const CTraceRecord& tr)
{
	if (tr.CountData() >= 2)
		return tr.GetData(1).data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetCommPrc(const CTraceRecord& tr)
{
	if (tr.CountData() >= 3)
		return tr.GetData(2).data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetCommPrss(const CTraceRecord& tr)
{
	if (tr.CountData() >= 4)
		return tr.GetData(3).data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetLength() const
{
	if (HaveSendData() || HaveRecvData())
		if (m_data.size() >= 1)
			return m_data[0].data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetType() const
{
	if (HaveSendData() || HaveRecvData())
		if (m_data.size() >= 2)
			return m_data[1].data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetCommPrc() const
{
	if (HaveSendData() || HaveRecvData())
		if (m_data.size() >= 3)
			return m_data[2].data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetCommPrss() const
{
	if (HaveSendData() || HaveRecvData())
		if (m_data.size() >= 4)
			return m_data[3].data.d_int;

	return 0;
}
//========================================================================

int	CCommunicationRecord::GetRequest() const
{
	return 0;
}
//========================================================================

//class CCommunicationRecord
//************************************************************************
//************************************************************************



//class CTraceEvent

CTraceEvent::CTraceEvent()
{
}

CTraceEvent::~CTraceEvent()
{
}
//========================================================================

//class CTaskEvent
//************************************************************************
//************************************************************************



//class CTaskEvent

CTaskEvent::CTaskEvent()
{
	m_event			= 0;
	m_time_start	= 0.0;
	m_time_end		= 0.0;
	m_prc			= 0;
	m_prss			= 0;
}

CTaskEvent::~CTaskEvent()
{
}
//========================================================================

CTraceEvent*	CTaskEvent::GetCopy() const
{
	return new CTaskEvent(*this);
}
//========================================================================

CTraceEvent::EType	CTaskEvent::GetType() const
{
	return E_task;
}
//========================================================================

void	CTaskEvent::GetTimeBounds(double& start, double& end) const
{
	start	= m_time_start;
	end		= m_time_end;
}
//========================================================================

bool	CTaskEvent::Fit(const CTraceFilter& tf) const
{
	if (!tf.MeetTime(m_time_start))
		return false;
	if (!tf.MeetTime(m_time_end))
		return false;

	if (!tf.MeetEvent(m_event))
		return false;

	if (!tf.MeetProc(m_prc))
		return false;

	if (!tf.MeetPrss(m_prss))
		return false;

	return true;
}
//========================================================================

bool	CTaskEvent::SetStartRec(const CTraceRecord& r)
{
	m_start_rec = r;

	m_event			= r.GetEventType();
	m_time_start	= r.GetTime();
	m_prc			= r.GetProcessor();
	m_prss			= r.GetProcess();

	return true;
}
//========================================================================

bool	CTaskEvent::SetEndRec(const CTraceRecord& r)
{
	m_end_rec = r;

	m_event		= r.GetEventType();
	m_time_end	= r.GetTime();
	m_prc		= r.GetProcessor();
	m_prss		= r.GetProcess();

	return true;
}
//========================================================================

//class CTaskEvent
//************************************************************************
//************************************************************************



//class CMessageEvent
CMessageEvent::CMessageEvent()
{
	m_length	= 0;
	m_time_send	= 0.0;
	m_time_recv	= 0.0;
	m_prc_send	= 0;
	m_prss_send	= 0;
	m_prc_recv	= 0;
	m_prss_recv	= 0;
}

CMessageEvent::~CMessageEvent()
{
}
//========================================================================

CTraceEvent*	CMessageEvent::GetCopy() const
{
	return new CMessageEvent(*this);
}

CTraceEvent::EType	CMessageEvent::GetType() const
{
	return CTraceEvent::E_message;
}
//========================================================================

void	CMessageEvent::GetTimeBounds(double& start, double& end) const
{
	start	= m_time_send;
	end		= m_time_recv;
}
//========================================================================

bool	CMessageEvent::Fit(const CTraceFilter& tf) const
{
	if (!tf.MeetTime(m_time_send))
		return false;
	if (!tf.MeetTime(m_time_recv))
		return false;

	if (!tf.MeetProc(m_prc_send))
		return false;
	if (!tf.MeetProc(m_prc_recv))
		return false;

	if (!tf.MeetPrss(m_prss_send))
		return false;
	if (!tf.MeetPrss(m_prss_recv))
		return false;

	return true;
}
//========================================================================

void	CMessageEvent::SetSender(const CTraceRecord& tr)
{
	m_length	= CCommunicationRecord::GetLength(tr);
	m_msg_type	= CCommunicationRecord::GetType(tr);
	m_time_send	= tr.GetTime();
	m_prc_send	= tr.GetProcessor();
	m_prss_send	= tr.GetProcess();
	m_prc_recv	= CCommunicationRecord::GetCommPrc(tr);
	m_prss_recv	= 0;
}
//========================================================================

void	CMessageEvent::SetReciever(int r)
{
	m_prc_recv	= r;
}
//========================================================================

//class CMessageEvent
//************************************************************************
//************************************************************************
