#ifndef _TV_ACTIVITY_SUMMARY_H_
#define _TV_ACTIVITY_SUMMARY_H_

#include "TraceManager.h"
#include "Chart.h"
#include <qlabel.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qcombobox.h>
#include <qlayout.h>

class CTVActivitySummary: public CTraceVisualizer
{
	Q_OBJECT
public:
	CTVActivitySummary(CTraceManager* pTM, QWidget* parent);
	virtual ~CTVActivitySummary();

	//GUI thread
		virtual	void	OnInitDraw();
		virtual	void	OnDrawRecord();
		virtual	void	OnFinalDraw();
	//end GUI thread
	
	//reader thread
		virtual	bool	OnNewTraceRead();
		virtual	bool	OnEventRead(const CTraceEvent* pTE);
		virtual	bool	OnEndTraceRead();
	//end reader thread

    QLabel* textLabel3;
//    QLabel* textLabel2;
    QComboBox* cb_Show;
//    QLabel* textLabel1;
    Chart::CBarChart* m_chart;
    QButtonGroup* mg_Time;
    QRadioButton* mr_Total;
    QRadioButton* mr_MPI;
    QButtonGroup* mg_Show;
    QRadioButton* mr_TotalTime;
    QRadioButton* mr_CallCount;
    QRadioButton* mr_MeanCall;

protected slots:
    virtual void languageChange();
	void	OnProcChanged(int);
	void	OnTotalMPITimeChanged(int);
	void	OnTimeCountChanged(int);

	void	ToTotalTime();
	void	ToMPITime();

protected:
	struct STask
	{
		STask(int i = 0, double v = 0.0, int c = 0)
		{
			id		= i;
			val		= v;
			count	= c;
		}

		int		id;
		double	val;
		int		count;
	};

	typedef QValueVector<STask>		TTaskVec;
	typedef QValueVector<TTaskVec>	T2DTaskVec;

    QGridLayout* FActivitySummaryLayout;
    QSpacerItem* spacer1;
    QVBoxLayout* mg_TimeLayout;
    QVBoxLayout* mg_ShowLayout;

	T2DTaskVec	m_data;	//[proc][STask]

	QString	ms_ord_time_percent;
	QString	ms_ord_time_seconds;
	QString	ms_ord_calls;

	int m_read;
	int m_filter;
	int m_task;

	void	ShowChart();
	void	ShowTotalChart(int proc);
	void	ShowMPIChart(int proc);
};

#endif	//_TV_ACTIVITY_SUMMARY_H_
