#ifndef _MDIWINDOW_H_
#define _MDIWINDOW_H_

#include "fmdiwindow.h"
#include <qworkspace.h>

#include "TraceManager.h"

class CChildTimeFrame;

class CMDIWindow: public FMDIWindow, public IFilterWindowOwner
{
	Q_OBJECT

public:
	CMDIWindow(QWidget* parent = 0, const char* name = 0, WFlags f = WType_TopLevel);
	virtual ~CMDIWindow(void);

	void	CreateChild();

    virtual void fileOpen();
    virtual void fileClose();
    virtual void fileExit();
    virtual void helpAbout();
    virtual void DisplayComunications();
    virtual void DisplayLoad();
    virtual void DisplayGantt();
    virtual void DisplayTasks();
    virtual void OnFilter();

	bool	OpenTrace(QString name);
	bool	CloseTrace();

	void	InitChild(QMainWindow* pW);

	//IFilterWindowOwner
	virtual void	ShowFilter(IFilterable*);
	virtual void	HideFilter(IFilterable*);

	virtual void	setCaption(const QString&);

protected:
	QWorkspace*	mp_Workspace;

	CChildTimeFrame*	mp_TimeFrame;

	CTraceManager	m_Trace;

	QString	ms_Title;

	void	RefreshCaption();
	QString	FormatCaption();
};

#endif	//_MDIWINDOW_H_
