#ifndef _TRACEEVENT_H_
#define _TRACEEVENT_H_

#include "Common.h"

//mpicl definitions
#include "mpicldefs.h"

class CTraceFilter;
class CTraceFile;

class CTraceRecord
{
public:
	struct SData
	{
		SData()
			{type = -1;}
		SData(char d)
			{type = CHARTYPE; data.d_char = d;}
		SData(int d)
			{type = INTTYPE; data.d_int = d;}
		SData(double d)
			{type = DOUBLETYPE; data.d_double = d;}
		SData(QString* pS)
			{type = STRINGTYPE; data.d_string = pS;}

		int type;	//from mpicl; CHARTYPE, INTTYPE, DOUBLETYPE and STRINGTYPE are supported

		union UData
		{
			char		d_char;
			int			d_int;
			double		d_double;
			QString*	d_string;
		}	data;
	};

	typedef QValueVector<SData>	TDataVec;

	CTraceRecord(/*CTraceFile* pT, */int r = 0, int e = 0, double t = 0.0, int pr = 0, int pss = 0);
	CTraceRecord(const CTraceRecord& tr);
	CTraceRecord&	operator = (const CTraceRecord& tr);
	virtual ~CTraceRecord(void);

	void	CopySelf(const CTraceRecord& tr);

	void	ClearData();

	bool	DataFromString(int count, const QString& format, const QString& data);

	//inline CTraceFile*	GetTraceFile()
	//	{return mp_Trace;}

	inline void		SetRecType(int rt)
		{m_record = rt;}
	inline int		GetRecType() const
		{return m_record;}
	inline void		SetEventType(int et)
		{m_event = et;}
	inline int		GetEventType() const
		{return m_event;}
	inline void		SetTime(double t)
		{m_time = t;}
	inline double	GetTime() const
		{return m_time;}
	inline void		SetProcessor(int p)
		{m_processor = p;}
	inline int		GetProcessor() const
		{return m_processor;}
	inline void		SetProcess(int p)
		{m_process = p;}
	inline int		GetProcess() const
		{return m_process;}

	inline bool		HaveData() const
		{return m_data.size() != 0;}
	inline int		CountData() const
		{return m_data.size();}
	inline const SData&	GetData(int i) const
		{return m_data[i];}

	QString	ToString() const;

protected:
//	CTraceFile* mp_Trace;

	int		m_record;
	int		m_event;
	double	m_time;
	int		m_processor;
	int		m_process;
	TDataVec	m_data;

};	//class CTraceRecord

typedef QValueVector<CTraceRecord>	TRecordVec;
//========================================================================

class CCommunicationRecord: public CTraceRecord
{
public:
	CCommunicationRecord(/*CTraceFile* pT*/);
	virtual ~CCommunicationRecord();

	bool	HaveSendData() const;
	bool	HaveRecvData() const;

	static bool	HaveSendData(const CTraceRecord& tr);
	static bool	HaveRecvData(const CTraceRecord& tr);

	static int	GetLength(const CTraceRecord& tr);
	static int	GetType(const CTraceRecord& tr);
	static int	GetCommPrc(const CTraceRecord& tr);
	static int	GetCommPrss(const CTraceRecord& tr);
//	static int	GetRequest(const CTraceRecord& tr);

	int	GetLength() const;
	int	GetType() const;
	int	GetCommPrc() const;
	int	GetCommPrss() const;
	int	GetRequest() const;

};	//class CCommunicationRecord
//========================================================================

class CTraceEvent
{
public:
	CTraceEvent();
	virtual ~CTraceEvent();

	virtual CTraceEvent*	GetCopy() const = 0;

	enum EType
	{
		E_task,
		E_message
	};

	virtual EType	GetType() const = 0;

	virtual void	GetTimeBounds(double& start, double& end) const = 0;

	virtual	bool	Fit(const CTraceFilter& tf) const = 0;

protected:

};	//class CTraceEvent

typedef QValueList<CTraceEvent*>	TEventList;
typedef TEventList::iterator		TEventIter;
typedef TEventList::const_iterator	TEventCIter;
//========================================================================

class CTaskEvent: public CTraceEvent
{
public:
	CTaskEvent();
	virtual ~CTaskEvent();

	virtual CTraceEvent*	GetCopy() const;

	virtual EType	GetType() const;

	virtual void	GetTimeBounds(double& start, double& end) const;

	virtual	bool	Fit(const CTraceFilter& tf) const;

	bool	SetStartRec(const CTraceRecord& r);
	bool	SetEndRec(const CTraceRecord& r);

	inline int		GetEvent() const
		{return m_event;}
	inline void		SetTimeStart(double t)
		{m_time_start = t;}
	inline double	GetTimeStart() const
		{return m_time_start;}
	inline void		SetTimeEnd(double t)
		{m_time_end = t;}
	inline double	GetTimeEnd() const
		{return m_time_end;}
	inline int		GetProcessor() const
		{return m_prc;}
	inline int		GetProcess() const
		{return m_prss;}

protected:
	CTraceRecord	m_start_rec;
	CTraceRecord	m_end_rec;

	int		m_event;
	double	m_time_start;
	double	m_time_end;
	int		m_prc;
	int		m_prss;

};	//class CCallEvent
//========================================================================

class CMessageEvent: public CTraceEvent
{
public:
	CMessageEvent();
	virtual ~CMessageEvent();

	virtual CTraceEvent*	GetCopy() const;

	virtual EType	GetType() const;

	virtual void	GetTimeBounds(double& start, double& end) const;

	virtual	bool	Fit(const CTraceFilter& tf) const;

	void	SetSender(const CTraceRecord& tr);
	void	SetReciever(int r);

	inline int		GetLength() const
		{return m_length;}
	inline int		GetMsgType() const
		{return m_msg_type;}
	inline void		SetTimeSend(double t)
		{m_time_send = t;}
	inline double	GetTimeSend() const
		{return m_time_send;}
	inline void		SetTimeRecv(double t)
		{m_time_recv = t;}
	inline double	GetTimeRecv() const
		{return m_time_recv;}
	inline int		GetPrcSend() const
		{return m_prc_send;}
	inline int		GetPrssSend() const
		{return m_prss_send;}
	inline int		GetPrcRecv() const
		{return m_prc_recv;}
	inline int		GetPrssRecvc() const
		{return m_prss_recv;}

protected:
	int		m_length;
	int		m_msg_type;
	double	m_time_send;
	double	m_time_recv;
	int		m_prc_send;
	int		m_prss_send;
	int		m_prc_recv;
	int		m_prss_recv;

};	//class CCallEvent
//========================================================================

#endif	//_TRACEEVENT_H_
