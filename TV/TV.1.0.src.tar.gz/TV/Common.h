#ifndef _COMMON_H_
#define _COMMON_H_

#include <stdlib.h>

#include <qstring.h>
#include <qvaluevector.h>
#include <qvaluelist.h>
#include "QuickBox.h"

typedef QValueVector<int>			TIntVec;
typedef QValueVector<TIntVec>		TInt2DVec;
typedef TIntVec::iterator			TIntVIter;
typedef QValueVector<double>		TDoubleVec;
typedef QValueVector<TDoubleVec>	TDouble2DVec;

typedef QValueList<int>		TIntList;
typedef TIntList::iterator	TIntLIter;

typedef unsigned int	UINT;

#define	min(a, b)	((a) < (b) ? (a) : (b))
#define	max(a, b)	((a) > (b) ? (a) : (b))

//#define LOG

#endif	//_COMMON_H_
