#ifndef _TV_TASK_H_
#define _TV_TASK_H_

#include "TraceManager.h"
#include "Chart.h"

class CTVTask: public CTraceVisualizer
{
	Q_OBJECT
public:
	CTVTask(CTraceManager* pTM, QWidget* parent);
	virtual ~CTVTask();

	//GUI thread
		virtual	void	OnInitDraw();
		virtual	void	OnDrawRecord();
		virtual	void	OnFinalDraw();

		void	DrawGantt();
	//end GUI thread
	
	//reader thread
		virtual	bool	OnNewTraceRead();
		virtual	bool	OnEventRead(const CTraceEvent* pTE);
		virtual	bool	OnEndTraceRead();
	//end reader thread

protected:
	Chart::CGanttChart*	m_tasks;

};	//class CTVGantt

#endif	//_TV_TASK_H_
