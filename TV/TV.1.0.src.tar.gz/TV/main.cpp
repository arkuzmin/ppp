#include <qapplication.h>

#include <qdatetime.h>
#include <qvaluelist.h>

#include "MDIWindow.h"
#include "Chart.h"
#include "Log.h"

int main( int argc, char ** argv )
{
//	CLog::Create(L_GUI, "LogGUI");

    QApplication a( argc, argv );

	CMDIWindow w_mdi(0, "MDI");

	a.setMainWidget(&w_mdi);

	w_mdi.show();

//	a.setStyle("motif");

	//CChart test
//	{
//		Chart::CMatrix* m = new Chart::CMatrix;
//		m->SetSize(32, 16);
//
//		m->SetItem(1, 2, 8);
//		m->SetItem(7, 4, 17);
//		m->SetItem(13, 13, -2);
//
//		m->AbscissName(m->trUtf8( "\xd0\x9e\xd1\x82\xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2\xd0\xb8\xd1\x82\xd0\xb5\xd0\xbb\xd1\x8c" ));
//
//		m->resize(200, 200);
//		m->show();
//
//		a.setMainWidget(m);
//	}

	//ReadEvent test
	//{
	//	CQuickBox::Msg("ReadEvent test start");

	//	QString s;

	//	CTraceFile trace;
	//	if (!trace.Open("test"))
	//		CQuickBox::Msg("Open() failed");

	//	CTraceRecord	rec;
	//	CTraceEvent*	pTE;
	//	CTraceFilter	filter;
	//	CTraceIter		ti;
	//	ti.SetFilter(&filter);
	//	trace.ToStart(ti);

	//	//trace.ReadRecord(&rec, ti);
	//	//s.sprintf("record = %d\nevent = %d\ntime = %f\nprc = %d\nprss = %d",
	//	//	rec.GetRecType(), rec.GetEventType(), rec.GetTime(),
	//	//	rec.GetProcessor(), rec.GetProcess());
	//	//CQuickBox::Msg(s);

	//	while (trace.GetTraceEvent(&pTE, ti))
	//	{
	//		switch (pTE->GetType())
	//		{
	//		case CTraceEvent::E_task:
	//		{
	//			CTaskEvent* pT = static_cast<CTaskEvent*>(pTE);
	//			s.sprintf("event = %d\ntime = [%f - %f]\nprc = %d\nprss = %d",
	//				pT->GetEvent(), pT->GetTimeStart(), pT->GetTimeEnd(),
	//				pT->GetProcessor(), pT->GetProcess());
	//			break;
	//		}
	//		case CTraceEvent::E_message:
	//		{
	//			CMessageEvent* pM = static_cast<CMessageEvent*>(pTE);
	//			s.sprintf("message\nfrom %d at %f\nto %d at %f\nlength = %d\ntype = %d",
	//				pM->GetPrcSend(), pM->GetTimeSend(), pM->GetPrcRecv(), pM->GetTimeRecv(),
	//				pM->GetLength(), pM->GetMsgType());
	//			break;
	//		}
	//		}

	//		CQuickBox::Msg(s);
	//	}

	//	return 0;
	//}

	//QFile test
//	{
//		CQuickBox::Msg("start");
//
//		QString s;
//
//		QFile f;
//		f.setName("fans128.trf");
////		f.open(IO_Raw | IO_ReadOnly);
//		f.open(IO_ReadOnly);
//
//		QIODevice::Offset len = f.size();
//		int buf_size = 1;
//		char* buf = new char[buf_size];
//
//		QTime t_start = QTime::currentTime();
//
//		QIODevice::Offset read = 0;
//		do
//		{
//			QIODevice::Offset r = f.readBlock(buf, buf_size);
//			read += r;
//		}
//		while (read < len);
//
//		QTime t_end = QTime::currentTime();
//		s.sprintf("Read - %d ms", t_start.msecsTo(t_end));
//		CQuickBox::Msg(s);
//
//		s.sprintf("Read %d of %d bytes", (int)read, (int)len);
//		CQuickBox::Msg(s);
//
//		delete buf;
//	}
//	return 0;

	//CTraceFile test
//	{
//		CQuickBox::Msg("start");
//
//		QString s;
//
//		QTime t_start = QTime::currentTime();
//
//		CTraceFile tf;
//		tf.Open("fft9.trf");
////		tf.Open("flops.trf");
////		tf.Open("fans128.trf");
//
//		QTime t_end = QTime::currentTime();
//		s.sprintf("Open - %d ms", t_start.msecsTo(t_end));
//		CQuickBox::Msg(s);
//
//		CTraceRecord tr;
//		CTraceIter it;
//
//		tf.ToStart(it);
//
//		t_start	= QTime::currentTime();
//
//		int n = 0;
//
//		//while (tf.ReadRecord(&tr, it))
//		//{
//		//	n++;
//		//}
//
//		CTraceEvent* pE;
//		while (tf.GetTraceEvent(&pE, it))
//		{
//			delete pE;
//			n++;
//
//			//if (it.m_line > 2094)// && it.m_line % 10 == 0)
//			//{
//			//	s.sprintf("it.m_line = %d", it.m_line);
//			//	CQuickBox::Msg(s);
//			//}
//		}
//
//		t_end	= QTime::currentTime();
//		s.sprintf("Read - %d ms (%d)", t_start.msecsTo(t_end), n);
//		CQuickBox::Msg(s);
//
//		s.sprintf("%d active events", it.GetTraceState().CountActiveEvents());
//		CQuickBox::Msg(s);
//
//		return 0;
//	}

    a.connect( &a, SIGNAL( lastWindowClosed() ), &a, SLOT( quit() ) );
    return a.exec();
//    return 0;
}
