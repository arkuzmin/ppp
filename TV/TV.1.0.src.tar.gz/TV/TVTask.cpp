#include "TVTask.h"

CTVTask::CTVTask(CTraceManager* pTM, QWidget* parent)
	:CTraceVisualizer(pTM, parent, NULL, "CTVTask")
{
	mp_TypeFilter =	new	CTraceFilter;
	pTM->MakeTasksFilter(*mp_TypeFilter);

	setCaption(trUtf8( "\xd0\x97\xd0\xb0\xd0\xb4\xd0\xb0\xd1\x87\xd0\xb8" ));

	m_tasks = new Chart::CGanttChart(this);

	m_tasks->AbscissName(trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f\x2c\x20\xd1\x81" ));
	m_tasks->OrdinatesName(trUtf8( "\xd0\x9f\xd1\x80\xd0\xbe\xd1\x86\xd0\xb5\xd1\x81\xd1\x81\xd0\xbe\xd1\x80" ));

	setCentralWidget(m_tasks);

	resize(400, 300);
}

CTVTask::~CTVTask()
{
}
//========================================================================

void	CTVTask::OnInitDraw()
{
}
//========================================================================

void	CTVTask::OnDrawRecord()
{
	DrawGantt();
}
//========================================================================

void	CTVTask::OnFinalDraw()
{
	DrawGantt();
}
//========================================================================

void	CTVTask::DrawGantt()
{
	int proc = mp_TrManager->GetProcessorsCount();

	for (int i = 0; i < proc; i++)
		if (mp_TrManager->IsProcLegal(i))
			m_tasks->ShowProc(i, false);
		else
			m_tasks->HideProc(i, false);

	m_tasks->update();
}
//========================================================================

bool	CTVTask::OnNewTraceRead()
{
	int proc = mp_TrManager->GetProcessorsCount();

	m_tasks->SetProcCount(proc);

	for (int i = 0; i < proc; i++)
		m_tasks->SetProcName(i, mp_TrManager->GetProcessorName(i), false);

	double s, e;
	mp_TrManager->GetDisplayTime(s, e);
	m_tasks->SetMinAbscissRange(s, e);

	return true;
}
//========================================================================

bool	CTVTask::OnEventRead(const CTraceEvent* pTE)
{
	if (!CTraceVisualizer::OnEventRead(pTE))
		return false;

	if (pTE->GetType() == CTraceEvent::E_task)
	{
		const CTaskEvent* pTS = static_cast<const CTaskEvent*>(pTE);

		int e = pTS->GetEvent();
		m_tasks->AddTaskType(e, mp_TrManager->GetTaskEventColor(e), mp_TrManager->GetTaskEventName(e));
		m_tasks->AddTask(pTS->GetProcessor(), pTS->GetTimeStart(), pTS->GetTimeEnd(), pTS->GetEvent());
	}

	return true;
}
//========================================================================

bool	CTVTask::OnEndTraceRead()
{
	return true;
}
//========================================================================
