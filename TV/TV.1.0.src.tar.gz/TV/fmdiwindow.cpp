/****************************************************************************
** Form implementation generated from reading ui file 'fmdiwindow.ui'
**
** Created: Пн 19. июл 07:48:01 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "fmdiwindow.h"

#include <qvariant.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>

#include "fmdiwindow.ui.h"
/*
 *  Constructs a FMDIWindow as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
FMDIWindow::FMDIWindow( QWidget* parent, const char* name, WFlags fl )
    : QMainWindow( parent, name, fl )
{
    (void)statusBar();
    if ( !name )
	setName( "FMDIWindow" );

    // actions
    fileOpenAction = new QAction( this, "fileOpenAction" );
    fileOpenAction->setIconSet( QIconSet( QPixmap::fromMimeSource( "fileopen" ) ) );
    fileExitAction = new QAction( this, "fileExitAction" );
    fileCloseAction = new QAction( this, "fileCloseAction" );
    fileCloseAction->setOn( FALSE );
    fileCloseAction->setEnabled( TRUE );
    aDisplayCommunicationMatrix = new QAction( this, "aDisplayCommunicationMatrix" );
    aDisplayLoad = new QAction( this, "aDisplayLoad" );
    aFilter = new QAction( this, "aFilter" );
    aDisplayTasks = new QAction( this, "aDisplayTasks" );
    aDisplayGantt = new QAction( this, "aDisplayGantt" );
    aHelpAbout = new QAction( this, "aHelpAbout" );


    // toolbars
    toolBar = new QToolBar( QString(""), this, DockTop ); 

    fileOpenAction->addTo( toolBar );


    // menubar
    MenuBar = new QMenuBar( this, "MenuBar" );


    file = new QPopupMenu( this );
    fileOpenAction->addTo( file );
    fileCloseAction->addTo( file );
    file->insertSeparator();
    fileExitAction->addTo( file );
    MenuBar->insertItem( QString(""), file, 1 );

    view = new QPopupMenu( this );
    aDisplayCommunicationMatrix->addTo( view );
    aDisplayLoad->addTo( view );
    aDisplayGantt->addTo( view );
    aDisplayTasks->addTo( view );
    view->insertSeparator();
    aFilter->addTo( view );
    MenuBar->insertItem( QString(""), view, 2 );

    unnamed = new QPopupMenu( this );
    aHelpAbout->addTo( unnamed );
    MenuBar->insertItem( QString(""), unnamed, 3 );

    languageChange();
    resize( QSize(578, 481).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( fileOpenAction, SIGNAL( activated() ), this, SLOT( fileOpen() ) );
    connect( fileExitAction, SIGNAL( activated() ), this, SLOT( fileExit() ) );
    connect( fileCloseAction, SIGNAL( activated() ), this, SLOT( fileClose() ) );
    connect( aDisplayCommunicationMatrix, SIGNAL( activated() ), this, SLOT( DisplayComunications() ) );
    connect( aDisplayLoad, SIGNAL( activated() ), this, SLOT( DisplayLoad() ) );
    connect( aFilter, SIGNAL( activated() ), this, SLOT( OnFilter() ) );
    connect( aDisplayGantt, SIGNAL( activated() ), this, SLOT( DisplayGantt() ) );
    connect( aDisplayTasks, SIGNAL( activated() ), this, SLOT( DisplayTasks() ) );
    connect( aHelpAbout, SIGNAL( activated() ), this, SLOT( helpAbout() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FMDIWindow::~FMDIWindow()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FMDIWindow::languageChange()
{
    setCaption( tr( "TV" ) );
    fileOpenAction->setText( trUtf8( "\xd0\x9e\xd1\x82\xd0\xba\xd1\x80\xd1\x8b\xd1\x82\xd1\x8c" ) );
    fileOpenAction->setMenuText( trUtf8( "\xd0\x9e\xd1\x82\xd0\xba\xd1\x80\xd1\x8b\xd1\x82\xd1\x8c" ) );
    fileOpenAction->setAccel( tr( "Ctrl+O" ) );
    fileExitAction->setText( trUtf8( "\xd0\x92\xd1\x8b\xd1\x85\xd0\xbe\xd0\xb4" ) );
    fileExitAction->setMenuText( trUtf8( "\xd0\x92\xd1\x8b\xd1\x85\xd0\xbe\xd0\xb4" ) );
    fileExitAction->setAccel( QString::null );
    fileCloseAction->setText( trUtf8( "\xd0\x97\xd0\xb0\xd0\xba\xd1\x80\xd1\x8b\xd1\x82\xd1\x8c" ) );
    fileCloseAction->setMenuText( trUtf8( "\xd0\x97\xd0\xb0\xd0\xba\xd1\x80\xd1\x8b\xd1\x82\xd1\x8c" ) );
    aDisplayCommunicationMatrix->setText( trUtf8( "\xd0\x92\xd0\xb7\xd0\xb0\xd0\xb8\xd0\xbc\xd0\xbe\xd0\xb4\xd0\xb5\xd0\xb9\xd1\x81\xd1\x82\xd0\xb2\xd0\xb8\xd1\x8f" ) );
    aDisplayCommunicationMatrix->setMenuText( trUtf8( "\xd0\x92\xd0\xb7\xd0\xb0\xd0\xb8\xd0\xbc\xd0\xbe\xd0\xb4\xd0\xb5\xd0\xb9\xd1\x81\xd1\x82\xd0\xb2\xd0\xb8\xd1\x8f" ) );
    aDisplayLoad->setText( trUtf8( "\xd0\x97\xd0\xb0\xd0\xb3\xd1\x80\xd1\x83\xd0\xb7\xd0\xba\xd0\xb0" ) );
    aDisplayLoad->setMenuText( trUtf8( "\xd0\x97\xd0\xb0\xd0\xb3\xd1\x80\xd1\x83\xd0\xb7\xd0\xba\xd0\xb0" ) );
    aFilter->setText( trUtf8( "\xd0\xa4\xd0\xb8\xd0\xbb\xd1\x8c\xd1\x82\xd1\x80" ) );
    aFilter->setMenuText( trUtf8( "\xd0\xa4\xd0\xb8\xd0\xbb\xd1\x8c\xd1\x82\xd1\x80" ) );
    aDisplayTasks->setText( trUtf8( "\xd0\x97\xd0\xb0\xd0\xb4\xd0\xb0\xd1\x87\xd0\xb8" ) );
    aDisplayTasks->setMenuText( trUtf8( "\xd0\x97\xd0\xb0\xd0\xb4\xd0\xb0\xd1\x87\xd0\xb8" ) );
    aDisplayGantt->setText( trUtf8( "\xd0\x93\xd0\xb0\xd0\xbd\xd1\x82" ) );
    aDisplayGantt->setMenuText( trUtf8( "\xd0\x93\xd0\xb0\xd0\xbd\xd1\x82" ) );
    aHelpAbout->setText( trUtf8( "\xd0\x9e\x20\xd0\xbf\xd1\x80\xd0\xbe\xd0\xb3\xd1\x80\xd0\xb0\xd0\xbc\xd0\xbc\xd0\xb5\x2e\x2e\x2e" ) );
    aHelpAbout->setMenuText( trUtf8( "\xd0\x9e\x20\xd0\xbf\xd1\x80\xd0\xbe\xd0\xb3\xd1\x80\xd0\xb0\xd0\xbc\xd0\xbc\xd0\xb5\x2e\x2e\x2e" ) );
    toolBar->setLabel( tr( "Tools" ) );
    if (MenuBar->findItem(1))
        MenuBar->findItem(1)->setText( trUtf8( "\xd0\xa4\xd0\xb0\xd0\xb9\xd0\xbb" ) );
    if (MenuBar->findItem(2))
        MenuBar->findItem(2)->setText( trUtf8( "\xd0\x92\xd0\xb8\xd0\xb4" ) );
    if (MenuBar->findItem(3))
        MenuBar->findItem(3)->setText( trUtf8( "\xd0\xa1\xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2\xd0\xba\xd0\xb0" ) );
}

