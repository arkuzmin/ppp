#include "TraceWindow.h"

#include "TraceFile.h"

CTraceWindow::CTraceWindow(CTraceFile* pT)
{
	mp_Trace = pT;
}

CTraceWindow::~CTraceWindow(void)
{
}
