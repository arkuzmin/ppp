#ifndef _LOG_H_
#define _LOG_H_

#include <qmap.h>

class QFile;
class QString;

class CLog
{
public:
	static bool	Create(int lid, const QString& name);
	static bool	Write(int lid, const QString& str);

protected:
	typedef QMap<int, QFile*>	TLogMap;
	typedef TLogMap::iterator	TLogIter;

	static TLogMap	mm_Logs;
};

enum ELogs
{
	L_GUI,
	L_Reader
};

#endif	//_LOG_H_
