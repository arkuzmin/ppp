#ifndef _TRACEMANAGER_H_
#define _TRACEMANAGER_H_

#include <qobject.h>
#include <qevent.h>
#include <qthread.h>
#include <qvaluevector.h>
#include <qwaitcondition.h>
#include <qmainwindow.h>
#include <qdatetime.h>

#include "TraceFile.h"

typedef QValueVector<int>	TIntVec;

class CTraceManager;

class IFilterWindow;
class IFilterWindowOwner;

class IFilterable
{
public:
	virtual const CTraceFilter*	GetFilter() const = 0;
	virtual	bool	GetFilterTime(double& start, double& end) = 0;
	virtual int		CountLegalProc() = 0;
	virtual bool	IsProcLegal(int p) = 0;
	virtual	bool	ChangeFilter(double start, double end, const TIntVec proc, IFilterWindow* pFW = NULL) = 0;
	virtual	bool	ChangeTime(double start, double end, IFilterWindow* pFW = NULL) = 0;

	virtual void	LockFilter() = 0;
	virtual void	UnlockFilter() = 0;

	virtual void			SetFilterWindow(IFilterWindow*) = 0;
	virtual IFilterWindow*	GetFilterWindow() = 0;
	virtual void			ShowFilterWindow() = 0;
	virtual void			SetFWOwner(IFilterWindowOwner*) = 0;

};	//class IFilterable
//========================================================================

class IFilterWindow
{
public:
	virtual ~IFilterWindow()
		{}

	virtual void	FilterChanged() = 0;

};	//class IFilterWindow
//========================================================================

class IFilterWindowOwner
{
public:
	virtual void	ShowFilter(IFilterable*) = 0;
	virtual void	HideFilter(IFilterable*) = 0;

};	//CFilterWindowPull
//========================================================================

class CTraceVisualizer: public QMainWindow, public IFilterable
{
	Q_OBJECT
public:
	CTraceVisualizer(CTraceManager* pTM, QWidget* parent,
		IFilterWindowOwner* pFWO = NULL,
		const char* name = 0, WFlags f = WDestructiveClose);
	virtual ~CTraceVisualizer();

	//GUI thread
		virtual	void	OnInitDraw() = 0;
		virtual	void	OnDrawRecord() = 0;
		virtual	void	OnFinalDraw() = 0;
		virtual	void	Redraw();
	//end GUI thread
	
	//reader thread
		virtual	bool	OnNewTraceRead() = 0;
		virtual	bool	OnEventRead(const CTraceEvent* pTE);
		virtual	bool	OnEndTraceRead() = 0;
	//end reader thread

	//thread safe
		virtual const CTraceFilter*	GetFilter() const;
		virtual	bool	GetFilterTime(double& start, double& end);
		virtual int		CountLegalProc();
		virtual bool	IsProcLegal(int p);
		virtual	bool	ChangeFilter(double start, double end, const TIntVec proc, IFilterWindow* pFW = NULL);
		virtual	bool	ChangeTime(double start, double end, IFilterWindow* pFW = NULL);
		virtual	bool	ChangeTimeForce(double start, double end, IFilterWindow* pFW = NULL);	//new
		virtual void	LockFilter();
		virtual void	UnlockFilter();
		virtual void			SetFilterWindow(IFilterWindow*);
		virtual IFilterWindow*	GetFilterWindow();
		virtual void			ShowFilterWindow();
		virtual void			SetFWOwner(IFilterWindowOwner*);
	//end thread safe

	void	Lock();
	void	Unlock();

protected:
	CTraceManager*	mp_TrManager;

	QMutex	mtx_type_filter;
		CTraceFilter*	mp_TypeFilter;

	QMutex	mtx_read_filter;
		CTraceFilter*	mp_ReadFilter;

	QMutex	mtx_Data;

	IFilterWindow*		mp_FilterWindow;
	IFilterWindowOwner*	mp_FWOwner;
};
//========================================================================

class CDrawEventCatcher: public QObject
{
	Q_OBJECT

public:
	enum EEvent
	{
		E_InitDraw	= QEvent::User + 1,
		E_DrawRecord,
		E_FinalDraw
	};

	class CInitDrawEvent: public QCustomEvent
	{
	public:
		CInitDrawEvent()
			:QCustomEvent(CDrawEventCatcher::E_InitDraw)
		{
		}
	};

	class CDrawRecordEvent: public QCustomEvent
	{
	public:
		CDrawRecordEvent()
			:QCustomEvent(CDrawEventCatcher::E_DrawRecord)
		{
		}
	};

	class CFinalRecordEvent: public QCustomEvent
	{
	public:
		CFinalRecordEvent()
			:QCustomEvent(CDrawEventCatcher::E_FinalDraw)
		{
		}
	};

	CDrawEventCatcher(CTraceManager* pTM);

protected:
	virtual void	customEvent(QCustomEvent* e);

private:
	CTraceManager*	mp_TrManager;
};
//========================================================================

class CReaderThread: public QThread
{
public:
	enum EMessage
	{
		M_quit,
		M_stop
	};

	CReaderThread(CTraceManager* pTM, QWaitCondition* pW, QMutex* pM, 
		CDrawEventCatcher* pEC);
	
	void	PostMessage(int msg);

protected:
	CTraceManager*	mp_TrManager;
	QWaitCondition*	mp_read_wait;
	QMutex*			mp_reading;

	CDrawEventCatcher*	mp_GUI_eventer;

	QMutex	mtx_msg;
		TIntVec	mv_Messages;
	//end mtx_msg
	
	virtual void run();

	bool	ReadBlock();
	bool	ParseMessages();

	bool	mb_quitting;
	bool	mb_stopping;
};
//========================================================================

class CTraceManager: public IFilterable
{
private:
	CTraceManager(const CTraceManager&);
	CTraceManager& operator =(const CTraceManager&);

public:
	CTraceManager();
	virtual ~CTraceManager();

	//GIU thread
		bool	Attach(CTraceVisualizer* pTV);
		bool	Detach(CTraceVisualizer* pTV);

		bool	StartReadTrace(const CTraceFilter* tf = NULL);	//if NULL - read with Manager's filter
		bool	StartReadTrace(const CTraceVisualizer* tv);
		bool	StopReadTrace();	//asynch
		void	WaitEndRead();

		void	InitDrawVisualizers();
		void	DrawVisualizers();
		void	RedrawVisualizers(const CTraceFilter* tf = NULL);	//if NULL - redraw all vissers
		void	FinalDrawVisualizers();

		void	FinishedDraw(const CTraceVisualizer* pV);

		bool	IsReading();

		QColor	GetTotalTimeColor() const;
		QColor	GetUserTimeColor() const;
		QColor	GetMPITimeColor() const;
		QColor	GetMPIEventColor(int e);
		QString	GetMPIEventName(int e);
		QColor	GetTaskEventColor(int e);
		QString	GetTaskEventName(int e);

		virtual	bool	ChangeFilter(double start, double end, const TIntVec proc, IFilterWindow* pFW = NULL);
		virtual	bool	ChangeTime(double start, double end, IFilterWindow* pFW = NULL);
		virtual void			SetFilterWindow(IFilterWindow*);
		virtual IFilterWindow*	GetFilterWindow();
		virtual void			ShowFilterWindow();
		virtual void			SetFWOwner(IFilterWindowOwner*);
	//end GUI thread

	//thread safe
		bool	InitRead(const CTraceFilter* tf);
		bool	InitRead(const CTraceVisualizer* tv);
		bool	ReadRecord();
		bool	EndRead();

		bool	OpenTrace(const QString& name);
		bool	CloseTrace();

		QString	GetTraceName();
		bool	IsTraceOpened();

		virtual const CTraceFilter*	GetFilter() const;
		virtual	bool	GetFilterTime(double& start, double& end);
		virtual int		CountLegalProc();
		virtual bool	IsProcLegal(int p);

		void	MakeCommunicationFilter(CTraceFilter& tf);
		void	MakeMPIRoutineFilter(CTraceFilter& tf);
		void	MakeTasksFilter(CTraceFilter& tf);

		int		GetProcessorsCount();
		QString	GetProcessorName(int i);
		double	GetStartTime();
		double	GetEndTime();
		void	GetDisplayTime(double& start, double& end);
		void	LockFilter();
		void	UnlockFilter();
	//end thread safe

	void	LockVisualizers();
	void	UnlockVisualizers();

	//debug
	//QTime	m_time_start;
	//QTime	m_time_end;

private:
	struct SVisualizer
	{
		SVisualizer()
		{
			pVis	= NULL;
			reading	= false;
			drawing	= false;
		}

		SVisualizer(CTraceVisualizer* pV)
		{
			pVis	= pV;
			reading	= false;
			drawing	= false;
		}

		CTraceVisualizer*	pVis;
		bool				reading;	//participate in reading session
		bool				drawing;	//currently drawing (didn't responded to message)
	};

	typedef QValueVector<SVisualizer>	TTVVec;
	typedef TTVVec::iterator			TTVIter;

	CReaderThread*	mp_Reader;
	QWaitCondition	m_read_wait;
	QMutex			m_reading;	//use only after reader start

	CDrawEventCatcher	m_event_catcher;

	QMutex	mtx_trace;
		CTraceFile		m_Trace;
		CTraceFilter	m_ReadFilter;
		CTraceIter		m_Iter;
	//end mtx_trace

	QMutex	mtx_filter;
		CTraceFilter	m_Filter;
	//end mtx_filter

	//reader thread
		CTraceEvent*	mp_Event;
	//end reader thread

	QMutex	mtx_visser;
		TTVVec	mv_Visualizers;
		//CTimeFrame	m_TimeFrame;
	//end mtx_visser

	IFilterWindow*		mp_FilterWindow;
	IFilterWindowOwner*	mp_FWOwner;

	//GIU thread
		bool	StartReadTraceBegin();
		bool	StartReadTraceEnd();
	//end GIU thread

	//debug
	//int m_events_read;
};                                  
//========================================================================

#endif	//_TRACEMANAGER_H_
