#ifndef _TRACEFILE_H_
#define _TRACEFILE_H_

#include "Common.h"
#include <qfile.h>
#include <qtextstream.h>
#include <qmap.h>

#include "TraceEvent.h"
#include "Condition.h"
//========================================================================



class CTraceFile;

class CTraceFilter
{
public:
	CTraceFilter();
	CTraceFilter(const CTraceFilter& tf);
	CTraceFilter& operator = (const CTraceFilter& tf);
	~CTraceFilter();

	void	CopyFrom(const CTraceFilter&, bool clear = true);

	void	ClearConditions();

	inline void			SetRecordCond(const TIntCond& pC)
		{delete mpc_record; mpc_record = pC.GetCopy();}
	inline TIntCond*	GetRecordCond() const
		{return mpc_record;}
	inline void			RemoveRecordCond()
		{delete mpc_record; mpc_record = NULL;}
	inline void			SetEventCond(const TIntCond& pC)
		{delete mpc_event; mpc_event = pC.GetCopy();}
	inline TIntCond*	GetEventCond() const
		{return mpc_event;}
	inline void			RemoveEventCond()
		{delete mpc_event; mpc_event = NULL;}

	inline bool		TimeFiltered() const
		{return mb_time;}
	bool			SetTime(double start, double end);
	inline double	GetTimeMin() const
		{return m_time_min;}
	inline double	GetTimeMax() const
		{return m_time_max;}
	inline void		ClearTime()
		{mb_time = false;}

	void		AddProc(int p);
	void		RemoveProc(int p);
	int			CountProc() const;
	void		ClearProc();

	bool	Satisfy(const CTraceRecord& r) const;
	bool	MeetRecord(int r) const;
	bool	MeetEvent(int e) const;
	bool	MeetTime(double t) const;
	bool	MeetProc(int proc) const;
	bool	MeetPrss(int prss) const;

protected:
	TIntCond*		mpc_record;
	TIntCond*		mpc_event;
	bool			mb_time;
	double			m_time_min;
	double			m_time_max;
	TIntVec			mv_proc;
	TIntCond*		mpc_prss;

};	//class CTraceFilter
//========================================================================

class CTraceState
{
public:
	CTraceState();
	CTraceState(const CTraceState&);
	CTraceState& operator = (const CTraceState&);
	~CTraceState();

	void	CopyFrom(const CTraceState& ts, bool clear = true);

	void			AddActiveEvent(CTraceEvent* pTE);
	void			ClearEvents();
	CTaskEvent*		FetchActiveTaskEvent(int event, int prc, double cur_time = 0.0);
	CMessageEvent*	FetchActiveMessageEvent(int sender, int receiver, int type);
	int				CountActiveEvents();

	void	GetReceivers(const CTraceRecord& r, TIntVec& recv);
	void	GetSenders(const CTraceRecord& r, TIntVec& send);

protected:
	TEventList	m_Events;

};	//class CTraceState
//========================================================================

class CEventPull
{
	CEventPull(const CEventPull&);
	CEventPull& operator = (const CEventPull&);

public:
	CEventPull();
	~CEventPull();

	void			AddEvent(CTraceEvent* pTE);
	CTraceEvent*	FetchEvent();
	void			ClearEvents();
	inline bool		IsEmpty() const
		{return m_Events.empty();}

protected:
	TEventList	m_Events;

};	//class CEventPull
//========================================================================

class CTraceIter
{
	friend class CTraceFile;

public:
	CTraceIter(CTraceFilter* pF = NULL)
		{m_pos = 0; m_time = 0; mp_filter = pF;}

	inline CTraceFilter*	GetFilter()
		{return mp_filter;}
	inline CTraceFilter*	SetFilter(CTraceFilter* fl)
		{CTraceFilter* pF = mp_filter; mp_filter = fl; return pF;}
	inline CTraceState&		GetTraceState()
		{return m_state;}
	inline void				SetTraceState(const CTraceState& ts)
		{m_state = ts;}
	inline CEventPull&		GetEventPull()
		{return m_ev_pull;}

	inline QIODevice::Offset	GetPos() const
		{return m_pos;}
	inline double				GetTime() const
		{return m_time;}

private:
	QIODevice::Offset	m_pos;
	double				m_time;
	CTraceFilter*		mp_filter;
	CTraceState			m_state;
	CEventPull			m_ev_pull;

	inline void	SetPos(QIODevice::Offset p)
		{m_pos = p;}
	inline void	SetTime(double t)
		{m_time = t;}

};	//class CTraceIter
//========================================================================

class CTraceFile
{
public:
	CTraceFile(void);
	~CTraceFile(void);

	bool	Open(QString name);
	bool	Close();
	void	InitDataFormats();
	bool	InitTrace();
	bool	IsOpen();

	bool	ReadRecord(CTraceRecord* pTR, CTraceIter& ti);

	bool	GetTraceEvent(CTraceEvent** ppTE, CTraceIter& ti);	//creates CTraceEvent

	bool	ToTraceStart(CTraceIter& ti);
	bool	ToIterStart(CTraceIter& ti);

	bool	IsCommunicationRecord(int r);

	static bool	MessageSend(const CTraceRecord& m_Record);
	static bool	MessageRecv(const CTraceRecord& m_Record);
	static bool	MessageSend(int event);
	static bool	MessageRecv(int event);

	static QString	GetMPIEventName(int e);
	static QString	GetTaskEventName(int e);

	void	MakeCommunicationFilter(CTraceFilter& tf);
	void	MakeMPIRoutineFilter(CTraceFilter& tf);
	void	MakeTasksFilter(CTraceFilter& tf);

	QString	DataFormat(const QString& s);

	inline QString	GetTraceName() const
		{return m_trace.name();}
	inline	double	GetStartTime() const
		{return m_start_time;}
	inline	double	GetEndTime() const
		{return m_end_time;}
	inline int		GetMaxUserTask() const
		{return m_max_user_task;}
	inline	int		GetProcessorsCount() const
		{return	mv_processors.count();}
	inline	QString	GetProcessorName(int i) const
		{return	QString::number(mv_processors[i]);}

protected:
	enum EFields
	{
		f_record,
		f_event,
		f_time,
		f_processor,
		f_process,
		f_data_count,
		f_data_type,
		f_data
	};

	struct SIndex
	{
		SIndex(double t = 0.0, QIODevice::Offset off = 0, const CTraceState& ts = CTraceState())
		{
			time		= t;
			file_pos	= off;
			state		= ts;
		}

		double				time;
		QIODevice::Offset	file_pos;
		CTraceState			state;
	};
	typedef QValueVector<SIndex>	TIndexVec;

	QFile		m_trace;

	TIndexVec	m_Index;

	double	m_start_time;
	double	m_end_time;
	int		m_max_user_task;
	TIntVec	mv_processors;

	CTraceRecord	m_Record;

	typedef QMap<int, QString>	TDFMap;	//data format map
	typedef TDFMap::iterator	TDFIter;

	TDFMap	m_dformat;

	TIntCond*	mpc_Communication;

	void	InitConditions();
	void	ClearConditions();

	QIODevice::Offset	LocatePosition(double time);

	bool	ReadRecordFields(CTraceRecord* pTR, CTraceIter& ti);

	bool	FilterTaskEvent(CTaskEvent* ev, const CTraceFilter* flt);
	bool	FilterMessageEvent(CMessageEvent* ev, const CTraceFilter* flt);

	int	GetProcessorID(int name) const;

};	//class CTraceFile
//========================================================================

#endif	//_TRACEFILE_H_
