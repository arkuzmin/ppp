/****************************************************************************
** Form implementation generated from reading ui file 'flabels.ui'
**
** Created: Ср 30. июн 15:02:35 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "flabels.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a FLabels as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
FLabels::FLabels( QWidget* parent, const char* name, WFlags fl )
    : QMainWindow( parent, name, fl )
{
    (void)statusBar();
    if ( !name )
	setName( "FLabels" );
    setCentralWidget( new QWidget( this, "qt_central_widget" ) );

    l_processor = new QLabel( centralWidget(), "l_processor" );
    l_processor->setGeometry( QRect( 20, 50, 90, 20 ) );

    l_Gantt = new QLabel( centralWidget(), "l_Gantt" );
    l_Gantt->setGeometry( QRect( 20, 80, 49, 20 ) );

    l_Tasks = new QLabel( centralWidget(), "l_Tasks" );
    l_Tasks->setGeometry( QRect( 20, 110, 49, 20 ) );

    l_time_s = new QLabel( centralWidget(), "l_time_s" );
    l_time_s->setGeometry( QRect( 20, 20, 60, 20 ) );

    l_calls = new QLabel( centralWidget(), "l_calls" );
    l_calls->setGeometry( QRect( 110, 20, 49, 20 ) );

    // toolbars

    languageChange();
    resize( QSize(600, 480).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FLabels::~FLabels()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FLabels::languageChange()
{
    setCaption( tr( "Labels" ) );
    l_processor->setText( trUtf8( "\xd0\x9f\xd1\x80\xd0\xbe\xd1\x86\xd0\xb5\xd1\x81\xd1\x81\xd0\xbe\xd1\x80" ) );
    l_Gantt->setText( trUtf8( "\xd0\x93\xd0\xb0\xd0\xbd\xd1\x82" ) );
    l_Tasks->setText( trUtf8( "\xd0\x97\xd0\xb0\xd0\xb4\xd0\xb0\xd1\x87\xd0\xb8" ) );
    l_time_s->setText( trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f\x2c\x20\xd1\x81" ) );
    l_calls->setText( trUtf8( "\xd0\x92\xd1\x8b\xd0\xb7\xd0\xbe\xd0\xb2\xd1\x8b" ) );
}

