/****************************************************************************
** Form implementation generated from reading ui file 'factivitysummary.ui'
**
** Created: Пн 19. июл 14:37:03 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "factivitysummary.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>

#include "Chart.h"
/*
 *  Constructs a FActivitySummary as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
FActivitySummary::FActivitySummary( QWidget* parent, const char* name, WFlags fl )
    : QMainWindow( parent, name, fl )
{
    (void)statusBar();
    if ( !name )
	setName( "FActivitySummary" );
    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FActivitySummaryLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FActivitySummaryLayout"); 

    textLabel3 = new QLabel( centralWidget(), "textLabel3" );

    FActivitySummaryLayout->addWidget( textLabel3, 0, 1 );

    cb_Show = new QComboBox( FALSE, centralWidget(), "cb_Show" );
    cb_Show->setSizeLimit( 20 );

    FActivitySummaryLayout->addWidget( cb_Show, 1, 1 );

    mg_Time = new QButtonGroup( centralWidget(), "mg_Time" );
    mg_Time->setColumnLayout(0, Qt::Vertical );
    mg_Time->layout()->setSpacing( 6 );
    mg_Time->layout()->setMargin( 11 );
    mg_TimeLayout = new QVBoxLayout( mg_Time->layout() );
    mg_TimeLayout->setAlignment( Qt::AlignTop );

    mr_Total = new QRadioButton( mg_Time, "mr_Total" );
    mg_TimeLayout->addWidget( mr_Total );

    mr_MPI = new QRadioButton( mg_Time, "mr_MPI" );
    mg_TimeLayout->addWidget( mr_MPI );

    FActivitySummaryLayout->addWidget( mg_Time, 2, 1 );
    spacer1 = new QSpacerItem( 20, 110, QSizePolicy::Minimum, QSizePolicy::Expanding );
    FActivitySummaryLayout->addItem( spacer1, 4, 1 );

    m_chart = new Chart::CBarChart( centralWidget(), "m_chart" );
    m_chart->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, m_chart->sizePolicy().hasHeightForWidth() ) );

    FActivitySummaryLayout->addMultiCellWidget( m_chart, 0, 6, 0, 0 );

    mg_Show = new QButtonGroup( centralWidget(), "mg_Show" );
    mg_Show->setColumnLayout(0, Qt::Vertical );
    mg_Show->layout()->setSpacing( 6 );
    mg_Show->layout()->setMargin( 11 );
    mg_ShowLayout = new QVBoxLayout( mg_Show->layout() );
    mg_ShowLayout->setAlignment( Qt::AlignTop );

    mr_TotalTime = new QRadioButton( mg_Show, "mr_TotalTime" );
    mg_ShowLayout->addWidget( mr_TotalTime );

    mr_CallCount = new QRadioButton( mg_Show, "mr_CallCount" );
    mg_ShowLayout->addWidget( mr_CallCount );

    mr_MeanCall = new QRadioButton( mg_Show, "mr_MeanCall" );
    mg_ShowLayout->addWidget( mr_MeanCall );

    FActivitySummaryLayout->addWidget( mg_Show, 3, 1 );

    // toolbars

    languageChange();
    resize( QSize(578, 449).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FActivitySummary::~FActivitySummary()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FActivitySummary::languageChange()
{
    setCaption( trUtf8( "\xd0\x97\xd0\xb0\xd0\xb3\xd1\x80\xd1\x83\xd0\xb7\xd0\xba\xd0\xb0" ) );
    textLabel3->setText( trUtf8( "\xd0\x9f\xd1\x80\xd0\xbe\xd1\x86\xd0\xb5\xd1\x81\xd1\x81\xd0\xbe\xd1\x80\x3a" ) );
    cb_Show->setCurrentItem( 0 );
    mg_Time->setTitle( trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f" ) );
    mr_Total->setText( trUtf8( "\xd0\x9e\xd0\xb1\xd1\x89\xd0\xb5\xd0\xb5" ) );
    mr_MPI->setText( tr( "MPI" ) );
    mg_Show->setTitle( trUtf8( "\xd0\x9f\xd0\xbe\xd0\xba\xd0\xb0\xd0\xb7\xd0\xb0\xd1\x82\xd1\x8c" ) );
    mr_TotalTime->setText( trUtf8( "\xd0\x9e\xd0\xb1\xd1\x89\xd0\xb5\xd0\xb5\x20\xd0\xb2\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f" ) );
    mr_CallCount->setText( trUtf8( "\xd0\x9a\xd0\xbe\xd0\xbb\xd0\xb8\xd1\x87\xd0\xb5\xd1\x81\xd1\x82\xd0\xb2\xd0\xbe\x20\xd0\xb2\xd1\x8b\xd0\xb7\xd0\xbe\xd0\xb2\xd0\xbe\xd0\xb2" ) );
    mr_MeanCall->setText( trUtf8( "\xd0\xa1\xd1\x80\xd0\xb5\xd0\xb4\xd0\xbd\xd0\xb5\xd0\xb5\x20\xd0\xb2\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f\x20\xd0\xb2\xd1\x8b\xd0\xb7\xd0\xbe\xd0\xb2\xd0\xb0" ) );
}

