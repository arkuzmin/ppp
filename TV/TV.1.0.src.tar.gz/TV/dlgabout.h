/****************************************************************************
** Form interface generated from reading ui file 'dlgabout.ui'
**
** Created: Пн 19. июл 07:56:01 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef DLGABOUT_H
#define DLGABOUT_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QPushButton;

class DlgAbout : public QDialog
{
    Q_OBJECT

public:
    DlgAbout( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~DlgAbout();

    QLabel* textLabel1;
    QPushButton* btnOK;

protected:
    QGridLayout* DlgAboutLayout;

protected slots:
    virtual void languageChange();

};

#endif // DLGABOUT_H
