/****************************************************************************
** Form interface generated from reading ui file 'factivitysummary.ui'
**
** Created: Пн 19. июл 14:36:59 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FACTIVITYSUMMARY_H
#define FACTIVITYSUMMARY_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qmainwindow.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
namespace Chart {
class CBarChart;
}
class QLabel;
class QComboBox;
class QButtonGroup;
class QRadioButton;

class FActivitySummary : public QMainWindow
{
    Q_OBJECT

public:
    FActivitySummary( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~FActivitySummary();

    QLabel* textLabel3;
    QComboBox* cb_Show;
    QButtonGroup* mg_Time;
    QRadioButton* mr_Total;
    QRadioButton* mr_MPI;
    Chart::CBarChart* m_chart;
    QButtonGroup* mg_Show;
    QRadioButton* mr_TotalTime;
    QRadioButton* mr_CallCount;
    QRadioButton* mr_MeanCall;

protected:
    QGridLayout* FActivitySummaryLayout;
    QSpacerItem* spacer1;
    QVBoxLayout* mg_TimeLayout;
    QVBoxLayout* mg_ShowLayout;

protected slots:
    virtual void languageChange();

private:
    QPixmap image0;

};

#endif // FACTIVITYSUMMARY_H
