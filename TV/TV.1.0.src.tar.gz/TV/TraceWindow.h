#ifndef _TRACEWINDOW_H_
#define _TRACEWINDOW_H_

#include "Common.h"

class CTraceFile;

class CTraceWindow
{
public:
	CTraceWindow(CTraceFile* pT = NULL);
	virtual ~CTraceWindow(void);

	virtual void	InitTrace() = 0;

protected:
	CTraceFile*	mp_Trace;
};

#endif	//_TRACEWINDOW_H_
