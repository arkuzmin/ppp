#include "TraceManager.h"

#include "TraceFile.h"

#include <qapplication.h>
#include <qtextstream.h>

#include "Log.h"

const int c_read_block_size		= 500;
const int c_read_block_time		= 1000;	//msecs
const int c_max_message_queue	= 10;


//class CTraceVisualizer

CTraceVisualizer::CTraceVisualizer(CTraceManager* pTM, QWidget* parent,
		IFilterWindowOwner* pFWO /* = NULL */,
		const char* name /* = 0 */, WFlags f /* = WType_TopLevel */)
		:QMainWindow(parent, name, f),
		mtx_type_filter(true),
		mtx_read_filter(true)
{
	mp_TrManager = pTM;
	mp_TrManager->Attach(this);

	mp_TypeFilter	= NULL;
	mp_ReadFilter	= NULL;

	mp_FilterWindow	= NULL;
	mp_FWOwner		= pFWO;
}

CTraceVisualizer::~CTraceVisualizer()
{
	mp_TrManager->Detach(this);

	if (mp_FilterWindow)
	{
		delete mp_FilterWindow;
		mp_FilterWindow = NULL;
	}

	if (mp_TypeFilter)
		delete mp_TypeFilter;
	if (mp_ReadFilter)
		delete mp_ReadFilter;
}
//========================================================================

void	CTraceVisualizer::Redraw()
{
	OnDrawRecord();
}
//========================================================================

bool	CTraceVisualizer::OnEventRead(const CTraceEvent* pTE)
{
	CLog::Write(L_Reader, "CTraceVisualizer::OnEventRead(): start\n");

	QMutexLocker ml(&mtx_type_filter);

	bool res = true;

	if (mp_TypeFilter)
		if (!pTE->Fit(*mp_TypeFilter))
			res = false;

	CLog::Write(L_Reader, "CTraceVisualizer::OnEventRead(): return\n");

	return res;
}
//========================================================================

const CTraceFilter*	CTraceVisualizer::GetFilter() const
{
	//we'r const
	//QMutexLocker ml(&mtx_read_filter);

	if (mp_ReadFilter)
		return mp_ReadFilter;
	else
		return mp_TrManager->GetFilter();
}
//========================================================================

bool	CTraceVisualizer::GetFilterTime(double& start, double& end)
{
	bool res = false;

	LockFilter();

	const CTraceFilter* pTF = GetFilter();
	if (pTF->TimeFiltered())
	{
		start	= pTF->GetTimeMin();
		end		= pTF->GetTimeMax();
		res = true;
	}
	else
		res = false;

	UnlockFilter();

	return res;
}
//========================================================================

int		CTraceVisualizer::CountLegalProc()
{
	int p;
	LockFilter();

		p = GetFilter()->CountProc();
		if (p == 0)	//proc not filtered
			p = mp_TrManager->GetProcessorsCount();

	UnlockFilter();
	return p;
}
//========================================================================

bool	CTraceVisualizer::IsProcLegal(int p)
{
	bool l;
	LockFilter();
		l = GetFilter()->MeetProc(p);
	UnlockFilter();
	return l;
}
//========================================================================

bool	CTraceVisualizer::ChangeFilter(double start, double end, const TIntVec proc, IFilterWindow* /* pFW = NULL */)
{
	CLog::Write(L_GUI, "CTraceVisualizer::ChangeFilter(): start\n");

	QMutexLocker ml(&mtx_read_filter);

	if (mp_ReadFilter)
	{
		CLog::Write(L_GUI, "CTraceVisualizer::ChangeFilter(): mp_ReadFilter\n");

		if (mp_TrManager->IsReading())
			return false;

		double s = mp_ReadFilter->GetTimeMin();
		double e = mp_ReadFilter->GetTimeMax();

		mp_ReadFilter->SetTime(start, end);

		mp_ReadFilter->ClearProc();
		for (size_t i = 0; i < proc.size(); i++)
			mp_ReadFilter->AddProc(proc[i]);

		if (s != start || e != end)	//time changed
			mp_TrManager->StartReadTrace(this);	//reread
		else
			Redraw();	//redraw

		CLog::Write(L_GUI, "CTraceVisualizer::ChangeFilter(): return true\n");

		return true;
	}
	else
	{
		return false;
	}
}
//========================================================================

bool	CTraceVisualizer::ChangeTime(double start, double end, IFilterWindow* pFW /* = NULL */)
{
	QMutexLocker ml(&mtx_read_filter);

	if (mp_ReadFilter)
	{
		if (mp_TrManager->IsReading())
			return false;

		double s = mp_ReadFilter->GetTimeMin();
		double e = mp_ReadFilter->GetTimeMax();

		mp_ReadFilter->SetTime(start, end);

		if (mp_FilterWindow && mp_FilterWindow != pFW)
			mp_FilterWindow->FilterChanged();

		if (s != start || e != end)	//time changed
			mp_TrManager->StartReadTrace(this);	//reread
		else
			OnDrawRecord();	//redraw

		return true;
	}
	else
	{
		return false;
	}
}
//========================================================================

bool	CTraceVisualizer::ChangeTimeForce(double start, double end, IFilterWindow* pFW /* = NULL */)
{
	QMutexLocker ml(&mtx_read_filter);

	if (mp_ReadFilter)
		return ChangeTime(start, end, pFW);
	else
		return mp_TrManager->ChangeTime(start, end, pFW);
}
//========================================================================

void	CTraceVisualizer::LockFilter()
{
	mtx_read_filter.lock();
}

void	CTraceVisualizer::UnlockFilter()
{
	mtx_read_filter.unlock();
}
//========================================================================

void	CTraceVisualizer::SetFilterWindow(IFilterWindow* pFW)
{
	if (mp_ReadFilter)
		mp_FilterWindow = pFW;
	else
		mp_TrManager->SetFilterWindow(pFW);
}

IFilterWindow*	CTraceVisualizer::GetFilterWindow()
{
	if (mp_ReadFilter)
		return mp_FilterWindow;
	else
		return mp_TrManager->GetFilterWindow();
}
//========================================================================

void	CTraceVisualizer::ShowFilterWindow()
{
	if (mp_FWOwner)
	{
		if (mp_ReadFilter)
			mp_FWOwner->ShowFilter(this);
		else
			mp_FWOwner->ShowFilter(mp_TrManager);
	}
}
//========================================================================

void	CTraceVisualizer::SetFWOwner(IFilterWindowOwner* pFWO)
{
	mp_FWOwner = pFWO;
}
//========================================================================

void	CTraceVisualizer::Lock()
{
	mtx_Data.lock();
}

void	CTraceVisualizer::Unlock()
{
	mtx_Data.unlock();
}
//========================================================================

//class CTraceVisualizer
//************************************************************************
//************************************************************************



//class CDrawEventCatcher

CDrawEventCatcher::CDrawEventCatcher(CTraceManager* pTM)
{
	mp_TrManager = pTM;
}
//========================================================================

void	CDrawEventCatcher::customEvent(QCustomEvent* e)
{
	int t = e->type();
	switch (t)
	{
	case E_InitDraw:
		mp_TrManager->InitDrawVisualizers();
		break;
	case E_DrawRecord:
		mp_TrManager->DrawVisualizers();
		break;
	case E_FinalDraw:
		mp_TrManager->FinalDrawVisualizers();
		break;
		break;
	}
}
//========================================================================

//class CDrawEventCatcher
//************************************************************************
//************************************************************************

	
	
//class CReaderThread

CReaderThread::CReaderThread(CTraceManager* pTM, QWaitCondition* pW, QMutex* pM, 
		CDrawEventCatcher* pEC)
{
	mp_TrManager	= pTM;
	mp_read_wait	= pW;
	mp_reading		= pM;

	mp_GUI_eventer = pEC;

	mv_Messages.reserve(c_max_message_queue);

	mb_quitting	= false;
	mb_stopping	= false;
}
//========================================================================

void	CReaderThread::PostMessage(int msg)
{
	mtx_msg.lock();
	mv_Messages.push_back(msg);
	mtx_msg.unlock();
}
//========================================================================

void CReaderThread::run()
{
//	CLog::Create(L_Reader, "LogReader");

	mp_reading->lock();

	for (;;)
	{
		mb_quitting = false;
		mb_stopping = false;
		
		mp_read_wait->wait(mp_reading);

		ParseMessages();

		if (mb_quitting)
			break;
		if (mb_stopping)
			continue;

		//init visualizers GUI
		QApplication::postEvent(mp_GUI_eventer, new CDrawEventCatcher::CInitDrawEvent);

		CLog::Write(L_Reader, "CReaderThread::run(): before while (ReadBlock())\n");

		while (ReadBlock())
		{
			QApplication::postEvent(mp_GUI_eventer, new CDrawEventCatcher::CDrawRecordEvent);

			ParseMessages();

			if (mb_stopping || mb_quitting)
				break;
		}

		CLog::Write(L_Reader, "CReaderThread::run(): after while (ReadBlock())\n");

		mp_TrManager->EndRead();

		QApplication::postEvent(mp_GUI_eventer, new CDrawEventCatcher::CFinalRecordEvent);

		if (mb_quitting)
			break;
	}

	mp_reading->unlock();
}
//========================================================================

bool	CReaderThread::ReadBlock()
{
	bool res;

	CLog::Write(L_Reader, "CReaderThread::ReadBlock(): start\n");

//	mp_TrManager->LockVisualizers();

	QTime t_start = QTime::currentTime();

	if (mp_TrManager->ReadRecord())
	{
		int i = 0;
		while (t_start.msecsTo(QTime::currentTime()) < c_read_block_time/* ||
			i < c_read_block_size*/)
		{
			if (!mp_TrManager->ReadRecord())
				break;

			i++;
		}

		res = true;	//read at least one event
	}
	else
	{
		res = false;	//read nothing
	}

//	mp_TrManager->UnlockVisualizers();

	CLog::Write(L_Reader, "CReaderThread::ReadBlock(): return\n");

	return res;
}
//========================================================================

bool	CReaderThread::ParseMessages()
{
	mtx_msg.lock();

	for (size_t i = 0; i < mv_Messages.size(); i++)
	{
		switch (mv_Messages[i])
		{
		case M_quit:
			mb_quitting = true;
			break;
		case M_stop:
			mb_stopping = true;
			break;
		}
	}
	mv_Messages.resize(0);	//all messages parsed

	mtx_msg.unlock();

	return true;
}
//========================================================================

//class CReaderThread
//************************************************************************
//************************************************************************



//class CTraceManager

CTraceManager::CTraceManager()
	:m_reading(false),
	m_event_catcher(this),
	mtx_trace(true),
	mtx_filter(true),
#ifdef WIN32
	mtx_visser(false)
#else
	mtx_visser(true)
#endif

{
	mp_Reader	= new CReaderThread(this, &m_read_wait, &m_reading, &m_event_catcher);
	mp_Reader->start();

	mp_Event = NULL;

	mp_FilterWindow	= NULL;
	mp_FWOwner		= NULL;
}

CTraceManager::~CTraceManager()
{
	mp_Reader->PostMessage(CReaderThread::M_quit);
	m_read_wait.wakeAll();
	mp_Reader->wait();

	delete mp_Reader;
}
//========================================================================

bool	CTraceManager::Attach(CTraceVisualizer* pTV)
{
	mtx_visser.lock();

	mv_Visualizers.push_back(SVisualizer(pTV));
	
	mtx_visser.unlock();

	return true;
}
//========================================================================

bool	CTraceManager::Detach(CTraceVisualizer* pTV)
{
	mtx_visser.lock();
	
	TTVIter it;
	for (it = mv_Visualizers.begin(); it != mv_Visualizers.end(); ++it)
	{
		if (it->pVis == pTV)
			break;
	}
	if (it != mv_Visualizers.end())
	{
		mv_Visualizers.erase(it);
	}

	mtx_visser.unlock();

	return true;
}
//========================================================================

bool	CTraceManager::StartReadTrace(const CTraceFilter* tf /* = NULL */)
{
	CLog::Write(L_GUI, "CTraceManager::StartReadTrace(): start\n");

	if (!StartReadTraceBegin())
		return false;

	CLog::Write(L_GUI, "CTraceManager::StartReadTrace(): StartReadTraceBegin() OK\n");

	if (!tf)
		tf = &m_Filter;

	InitRead(tf);

	CLog::Write(L_GUI, "CTraceManager::StartReadTrace(): InitRead() OK\n");

	bool res = StartReadTraceEnd();

	CLog::Write(L_GUI, "CTraceManager::StartReadTrace(): return\n");

	return res;
}
//========================================================================

bool	CTraceManager::StartReadTrace(const CTraceVisualizer* tv)
{
	if (!tv)
		return false;

	if (!StartReadTraceBegin())
		return false;

	InitRead(tv);

	return StartReadTraceEnd();
}
//========================================================================

bool	CTraceManager::StopReadTrace()
{
	if (!IsReading())
		return false;

	mp_Reader->PostMessage(CReaderThread::M_stop);

	return true;
}
//========================================================================

void	CTraceManager::WaitEndRead()
{
	while (IsReading())
	{
		//wait
	}
}
//========================================================================

void	CTraceManager::InitDrawVisualizers()
{
	CLog::Write(L_GUI, "CTraceManager::InitDrawVisualizers(): start\n");

	mtx_visser.lock();
	CLog::Write(L_GUI, "CTraceManager::InitDrawVisualizers(): mtx_visser.lock()\n");

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
	{
		if (mv_Visualizers[i].reading)
			mv_Visualizers[i].pVis->OnInitDraw();
	}

	mtx_visser.unlock();

	CLog::Write(L_GUI, "CTraceManager::InitDrawVisualizers(): return\n");
}
//========================================================================

void	CTraceManager::DrawVisualizers()
{
	mtx_visser.lock();

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
	{
		if (mv_Visualizers[i].reading)
			if (!mv_Visualizers[i].drawing)
			{
				mv_Visualizers[i].drawing = true;
				mv_Visualizers[i].pVis->OnDrawRecord();
				mv_Visualizers[i].drawing = false;
			}
	}

	mtx_visser.unlock();
}
//========================================================================

void	CTraceManager::RedrawVisualizers(const CTraceFilter* tf /* = NULL */)
{
	mtx_visser.lock();

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
	{
		if (mv_Visualizers[i].pVis->GetFilter() == tf || tf == NULL)
			mv_Visualizers[i].pVis->Redraw();
	}

	mtx_visser.unlock();
}
//========================================================================

void	CTraceManager::FinalDrawVisualizers()
{
	mtx_visser.lock();

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
	{
		if (mv_Visualizers[i].reading)
			mv_Visualizers[i].pVis->OnFinalDraw();
	}

	mtx_visser.unlock();
}
//========================================================================

void	CTraceManager::FinishedDraw(const CTraceVisualizer* pV)
{
	mtx_visser.lock();

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
		if (mv_Visualizers[i].pVis == pV)
		{
			mv_Visualizers[i].drawing = false;
			break;
		}

	mtx_visser.unlock();
}
//========================================================================

bool	CTraceManager::IsReading()
{
	return m_reading.locked();
}
//========================================================================

QColor	CTraceManager::GetTotalTimeColor() const
{
	return QColor(90, 90, 220);
}
//========================================================================

QColor	CTraceManager::GetUserTimeColor() const
{
	return QColor(90, 220, 90);
}
//========================================================================

QColor	CTraceManager::GetMPITimeColor() const
{
	return QColor(220, 90, 90);
}
//========================================================================

QColor	CTraceManager::GetMPIEventColor(int e)
{
	switch (e)
	{
	case -21:	return QColor(240, 70, 70);	//"MPI_Send";
	case -22:	return QColor(230, 70, 70);	//"MPI_Bsend";
	case -23:	return QColor(220, 70, 70);	//"MPI_Ssend";
	case -24:	return QColor(210, 70, 70);	//"MPI_Rsend";
	case -27:	return QColor(200, 70, 70);	//"MPI_Isend";
	case -28:	return QColor(190, 70, 70);	//"MPI_Test OK";
	case -30:	return QColor(180, 70, 70);	//"MPI_Wait (nb)";
	case -31:	return QColor(170, 70, 70);	//"MPI_Wait (b)";
	case -33:	return QColor(160, 70, 70);	//"MPI_Ibsend";
	case -34:	return QColor(150, 70, 70);	//"MPI_Test OK";
	case -36:	return QColor(140, 70, 70);	//"MPI_Wait (nb)";
	case -37:	return QColor(130, 70, 70);	//"MPI_Wait (b)";
	case -39:	return QColor(120, 70, 70);	//"MPI_Issend";
	case -40:	return QColor(110, 70, 70);	//"MPI_Test OK";
	case -42:	return QColor(100, 70, 70);	//"MPI_Wait (nb)";
	case -43:	return QColor( 90, 70, 70);	//"MPI_Wait (b)";
	case -45:	return QColor( 80, 70, 70);	//"MPI_Irsend";
	case -46:	return QColor( 70, 70, 70);	//"MPI_Test OK";
	case -48:	return QColor( 60, 70, 70);	//"MPI_Wait (nb)";
	case -49:	return QColor( 50, 70, 70);	//"MPI_Wait (b)";
	case -51:	return QColor(70, 240, 70);	//"MPI_Recv (nb)";
	case -52:	return QColor(150, 220, 150);	//"MPI_Recv (b)";
	case -57:	return QColor(70, 200, 70);	//"MPI_Irecv";
	case -58:	return QColor(70, 180, 70);	//"MPI_Test OK";
	case -60:	return QColor(70, 160, 70);	//"MPI_Wait (nb)";
	case -61:	return QColor(20, 140, 20);	//"MPI_Wait (b)";
	case -402:	return QColor(70, 70, 260);	//"MPI_Barrier";
	case -756:	return QColor(70, 70, 240);	//"MPI_Pack";
	case -773:	return QColor(70, 70, 230);	//"MPI_Unpack";
	case -780:	return QColor(70, 70, 220);	//"MPI_Allgather";
	case -782:	return QColor(70, 70, 210);	//"MPI_Allreduce";
	case -783:	return QColor(70, 70, 200);	//"MPI_Alltoall";
	case -785:	return QColor(70, 70, 190);	//"MPI_Bcast";
	case -786:	return QColor(70, 70, 180);	//"MPI_Gather";
	case -790:	return QColor(70, 70, 170);	//"MPI_Reduce";
	case -791:	return QColor(70, 70, 160);	//"MPI_Reducescatter";
	case -792:	return QColor(70, 70, 150);	//"MPI_Scan";
	case -793:	return QColor(70, 70, 140);	//"MPI_Scatter";
//	case -21:	return QColor(, , );	//"MPI_Send";
	}								  
									  
	return Qt::gray;				  
}
//========================================================================

QString	CTraceManager::GetMPIEventName(int e)
{
	return CTraceFile::GetMPIEventName(e);
}
//========================================================================

QColor	CTraceManager::GetTaskEventColor(int e)
{
	QColor c;

	mtx_trace.lock();
		c.setHsv((double)e / (double)m_Trace.GetMaxUserTask() * 400,
			200, 200);
	mtx_trace.unlock();

	return c;
}
//========================================================================

QString	CTraceManager::GetTaskEventName(int e)
{
	return CTraceFile::GetTaskEventName(e);
}
//========================================================================

bool	CTraceManager::ChangeFilter(double start, double end, const TIntVec proc, IFilterWindow* pFW /* = NULL */)
{
	if (IsReading())
		return false;

	QMutexLocker ml(&mtx_filter);

	double s = m_Filter.GetTimeMin();
	double e = m_Filter.GetTimeMax();

	bool time_changed = false;
	if ((s != start || e != end) && m_Filter.SetTime(start, end))
		time_changed = true;

	m_Filter.ClearProc();
	for (size_t i = 0; i < proc.size(); i++)
		m_Filter.AddProc(proc[i]);

	if (mp_FilterWindow)
		if (mp_FilterWindow != pFW)
			mp_FilterWindow->FilterChanged();

	if (time_changed)
		StartReadTrace();
	else
		RedrawVisualizers();

	return true;
}
//========================================================================

bool	CTraceManager::ChangeTime(double start, double end, IFilterWindow* pFW /* = NULL */)
{
	CLog::Write(L_GUI, "CTraceManager::ChangeTime(): start\n");

	if (IsReading())
		return false;

	QMutexLocker ml(&mtx_filter);

	double s = m_Filter.GetTimeMin();
	double e = m_Filter.GetTimeMax();

	bool time_changed = false;
	if ((s != start || e != end) && m_Filter.SetTime(start, end))
		time_changed = true;

	if (mp_FilterWindow)
		if (mp_FilterWindow != pFW)
			mp_FilterWindow->FilterChanged();

	if (time_changed)
	{
		StartReadTrace();
	}
	else
		DrawVisualizers();

	CLog::Write(L_GUI, "CTraceManager::ChangeTime(): return\n");

	return true;
}
//========================================================================

void	CTraceManager::SetFilterWindow(IFilterWindow* pFW)
{
	mp_FilterWindow = pFW;
}

IFilterWindow*	CTraceManager::GetFilterWindow()
{
	return mp_FilterWindow;
}

void	CTraceManager::ShowFilterWindow()
{
	if (mp_FWOwner)
		mp_FWOwner->ShowFilter(this);
}

void	CTraceManager::SetFWOwner(IFilterWindowOwner* pFWO)
{
	mp_FWOwner = pFWO;
}
//========================================================================

bool	CTraceManager::InitRead(const CTraceFilter* tf)
{
	CLog::Write(L_GUI, "CTraceManager::InitRead(): start\n");

	m_ReadFilter = *tf;

	mtx_trace.lock();
		m_Iter.SetFilter(&m_ReadFilter);

		m_Trace.ToIterStart(m_Iter);
	mtx_trace.unlock();

	mtx_visser.lock();

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
	{
		if (mv_Visualizers[i].pVis->GetFilter() == tf)	//have same filter
		{
			mv_Visualizers[i].reading = mv_Visualizers[i].pVis->OnNewTraceRead();
			if (mv_Visualizers[i].reading)
			{
				mv_Visualizers[i].drawing = false;
			}
		}
	}

	mtx_visser.unlock();

	CLog::Write(L_GUI, "CTraceManager::InitRead(): return\n");

	return true;
}
//========================================================================

bool	CTraceManager::InitRead(const CTraceVisualizer* tv)
{
	m_ReadFilter = *tv->GetFilter();

	mtx_trace.lock();
		m_Iter.SetFilter(&m_ReadFilter);

		m_Trace.ToIterStart(m_Iter);
	mtx_trace.unlock();

	mtx_visser.lock();

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
	{
		if (mv_Visualizers[i].pVis == tv)	//reader
		{
			mv_Visualizers[i].reading = mv_Visualizers[i].pVis->OnNewTraceRead();
			if (mv_Visualizers[i].reading)
			{
				mv_Visualizers[i].drawing = false;
			}
		}
		else
		{
			mv_Visualizers[i].reading = false;
		}
	}

	mtx_visser.unlock();

	return true;
}
//========================================================================

bool	CTraceManager::ReadRecord()
{
//	CLog::Write(L_Reader, "CTraceManager::ReadRecord(): start\n");

	bool res;
	mtx_trace.lock();
//		CLog::Write(L_Reader, "CTraceManager::ReadRecord(): mtx_trace.lock();\n");

		res = m_Trace.GetTraceEvent(&mp_Event, m_Iter);
	mtx_trace.unlock();

	if (res)
	{
		mtx_visser.lock();
//		CLog::Write(L_Reader, "CTraceManager::ReadRecord(): mtx_visser.lock();\n");

		for (size_t i = 0; i < mv_Visualizers.size(); i++)
		{
			if (mv_Visualizers[i].reading)
				mv_Visualizers[i].pVis->OnEventRead(mp_Event);
		}

		mtx_visser.unlock();
	}

	delete mp_Event;
	mp_Event = NULL;

//	CLog::Write(L_Reader, "CTraceManager::ReadRecord(): return\n");

	return res;
}
//========================================================================

bool	CTraceManager::EndRead()
{
	mtx_visser.lock();

	for (size_t i = 0; i < mv_Visualizers.size(); i++)
	{
		if (mv_Visualizers[i].reading)
			mv_Visualizers[i].pVis->OnEndTraceRead();
	}

	mtx_visser.unlock();

	return true;
}
//========================================================================

bool	CTraceManager::OpenTrace(const QString& name)
{
	bool res;
	mtx_trace.lock();
		res = m_Trace.Open(name);

		if (res)
		{
			mtx_filter.lock();
				m_Filter.ClearConditions();
			mtx_filter.unlock();
		}

	mtx_trace.unlock();

	return res;
}
//========================================================================

bool	CTraceManager::CloseTrace()
{
	bool res;
	mtx_trace.lock();
		res = m_Trace.Close();
	mtx_trace.unlock();
	return res;
}
//========================================================================

QString	CTraceManager::GetTraceName()
{
	QMutexLocker ml(&mtx_trace);

	return m_Trace.GetTraceName();
}
//========================================================================

bool	CTraceManager::IsTraceOpened()
{
	QMutexLocker ml(&mtx_trace);

	return m_Trace.IsOpen();
}
//========================================================================

const CTraceFilter*	CTraceManager::GetFilter() const
{
	return &m_Filter;
}
//========================================================================

bool	CTraceManager::GetFilterTime(double& start, double& end)
{
	QMutexLocker ml(&mtx_filter);

	if (m_Filter.TimeFiltered())
	{
		start	= m_Filter.GetTimeMin();
		end		= m_Filter.GetTimeMax();

		return true;
	}
	else
	{
		return false;
	}
}
//========================================================================

int		CTraceManager::CountLegalProc()
{
	QMutexLocker ml(&mtx_filter);

	int p = m_Filter.CountProc();
	if (p != 0)	//have proc filter
		return p;
	else
		return GetProcessorsCount();
}
//========================================================================

bool	CTraceManager::IsProcLegal(int p)
{
	QMutexLocker ml(&mtx_filter);

	return m_Filter.MeetProc(p);
}
//========================================================================

void	CTraceManager::MakeCommunicationFilter(CTraceFilter& tf)
{
	mtx_trace.lock();
		m_Trace.MakeCommunicationFilter(tf);
	mtx_trace.unlock();
}
//========================================================================

void	CTraceManager::MakeMPIRoutineFilter(CTraceFilter& tf)
{
	mtx_trace.lock();
		m_Trace.MakeMPIRoutineFilter(tf);
	mtx_trace.unlock();
}
//========================================================================

void	CTraceManager::MakeTasksFilter(CTraceFilter& tf)
{
	mtx_trace.lock();
		m_Trace.MakeTasksFilter(tf);
	mtx_trace.unlock();
}
//========================================================================

int	CTraceManager::GetProcessorsCount()
{
	int p;
	mtx_trace.lock();
		p = m_Trace.GetProcessorsCount();
	mtx_trace.unlock();
	return p;
}
//========================================================================

QString	CTraceManager::GetProcessorName(int i)
{
	QString s;
	mtx_trace.lock();
		s = m_Trace.GetProcessorName(i);
	mtx_trace.unlock();
	return s;
}
//========================================================================

double	CTraceManager::GetStartTime()
{
	double t;
	mtx_trace.lock();
		t = m_Trace.GetStartTime();
	mtx_trace.unlock();
	return t;
}
//========================================================================

double	CTraceManager::GetEndTime()
{
	double t;
	mtx_trace.lock();
		t = m_Trace.GetEndTime();
	mtx_trace.unlock();
	return t;
}
//========================================================================

void	CTraceManager::GetDisplayTime(double& start, double& end)
{
	if (!GetFilterTime(start, end))
	{
		QMutexLocker ml(&mtx_trace);

		start	= m_Trace.GetStartTime();
		end		= m_Trace.GetEndTime();
	}
}
//========================================================================

void	CTraceManager::LockFilter()
{
	mtx_filter.lock();
}

void	CTraceManager::UnlockFilter()
{
	mtx_filter.unlock();
}
//========================================================================

void	CTraceManager::LockVisualizers()
{
	mtx_visser.lock();
}

void	CTraceManager::UnlockVisualizers()
{
	mtx_visser.unlock();
}
//========================================================================

bool	CTraceManager::StartReadTraceBegin()
{
	if (IsReading())
		return false;

	return true;
}

bool	CTraceManager::StartReadTraceEnd()
{
	//run reading thread
	m_read_wait.wakeAll();

	InitDrawVisualizers();

	return true;
}
//========================================================================

//class CTraceManager
