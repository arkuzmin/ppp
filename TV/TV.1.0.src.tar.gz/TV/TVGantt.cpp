#include "TVGantt.h"

#include "Log.h"

CTVGantt::CTVGantt(CTraceManager* pTM, QWidget* parent,
		IFilterWindowOwner* pFWO /* = NULL */)
	:CTraceVisualizer(pTM, parent, pFWO, "CTVGantt")
{
	mp_TypeFilter =	new	CTraceFilter;
	pTM->MakeMPIRoutineFilter(*mp_TypeFilter);

	setCaption(trUtf8( "\xd0\x93\xd0\xb0\xd0\xbd\xd1\x82" ));

    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FGanttLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FGanttLayout"); 

    mb_Filter = new QPushButton( centralWidget(), "mb_Filter" );

    FGanttLayout->addWidget( mb_Filter, 2, 1 );
    spacer3 = new QSpacerItem( 31, 240, QSizePolicy::Minimum, QSizePolicy::Expanding );
    FGanttLayout->addItem( spacer3, 3, 1 );

    m_gantt = new Chart::CGanttChart( centralWidget(), "m_gantt" );
    m_gantt->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, m_gantt->sizePolicy().hasHeightForWidth() ) );

    FGanttLayout->addMultiCellWidget( m_gantt, 0, 3, 0, 0 );

    mg_Time = new QButtonGroup( centralWidget(), "mg_Time" );
    mg_Time->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)5, 0, 0, mg_Time->sizePolicy().hasHeightForWidth() ) );
    mg_Time->setColumnLayout(0, Qt::Vertical );
    mg_Time->layout()->setSpacing( 6 );
    mg_Time->layout()->setMargin( 11 );
    mg_TimeLayout = new QGridLayout( mg_Time->layout() );
    mg_TimeLayout->setAlignment( Qt::AlignTop );

    mr_Global = new QRadioButton( mg_Time, "mr_Global" );

    mg_TimeLayout->addMultiCellWidget( mr_Global, 0, 0, 0, 1 );

    mr_Local = new QRadioButton( mg_Time, "mr_Local" );

    mg_TimeLayout->addMultiCellWidget( mr_Local, 1, 1, 0, 1 );

    mb_MakeGlobal = new QPushButton( mg_Time, "mb_MakeGlobal" );

    mg_TimeLayout->addWidget( mb_MakeGlobal, 2, 1 );
    spacer2 = new QSpacerItem( 16, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    mg_TimeLayout->addItem( spacer2, 2, 0 );

    FGanttLayout->addWidget( mg_Time, 0, 1 );

    // toolbars

    languageChange();
	resize(500, 300);
    clearWState( WState_Polished );

	m_gantt->AbscissName(trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f\x2c\x20\xd1\x81" ));
	m_gantt->OrdinatesName(trUtf8( "\xd0\x9f\xd1\x80\xd0\xbe\xd1\x86\xd0\xb5\xd1\x81\xd1\x81\xd0\xbe\xd1\x80" ));

	mr_Global->setChecked(true);
	ToGlobalTime(true);

	connect(mg_Time, SIGNAL(clicked(int)), SLOT(OnFilterChanged(int)));
	connect(mb_MakeGlobal, SIGNAL(clicked()), SLOT(SetGlobalTime()));
	connect(mb_Filter, SIGNAL(clicked()), SLOT(OnShowFilter()));
	connect(m_gantt, SIGNAL(TimeFrameSelected(double, double)), SLOT(SetTime(double, double)));
}

CTVGantt::~CTVGantt()
{
}
//========================================================================

void	CTVGantt::OnInitDraw()
{
	DrawGantt();
}
//========================================================================

void	CTVGantt::OnDrawRecord()
{
	DrawGantt();
}
//========================================================================

void	CTVGantt::OnFinalDraw()
{
	DrawGantt();
}
//========================================================================

void	CTVGantt::DrawGantt()
{
	CLog::Write(L_GUI, "CTVGantt::DrawGantt(): start()\n");

	int proc = mp_TrManager->GetProcessorsCount();

	CLog::Write(L_GUI, "CTVGantt::DrawGantt(): mp_TrManager->GetProcessorsCount() OK\n");

	for (int i = 0; i < proc; i++)
	{
		QString s;
		if (IsProcLegal(i))
		{
			CLog::Write(L_GUI, s.sprintf("CTVGantt::DrawGantt(): proc[%d] is legal\n", i));
			m_gantt->ShowProc(i, false);
		}
		else
		{
			CLog::Write(L_GUI, s.sprintf("CTVGantt::DrawGantt(): proc[%d] is not legal\n", i));
			m_gantt->HideProc(i, false);
		}
	}

	CLog::Write(L_GUI, "CTVGantt::DrawGantt(): ShowProc() OK\n");

	m_gantt->update();

	CLog::Write(L_GUI, "CTVGantt::DrawGantt(): return()\n");
}
//========================================================================

bool	CTVGantt::OnNewTraceRead()
{
	int proc = mp_TrManager->GetProcessorsCount();

	m_gantt->SetProcCount(proc);

	for (int i = 0; i < proc; i++)
		m_gantt->SetProcName(i, mp_TrManager->GetProcessorName(i), false);

	double s, e;

	mtx_read_filter.lock();
		if (mp_ReadFilter)
		{
			if (mp_ReadFilter->TimeFiltered())
			{
				s = mp_ReadFilter->GetTimeMin();
				e = mp_ReadFilter->GetTimeMax();
			}
			else
			{
				s = mp_TrManager->GetStartTime();
				e = mp_TrManager->GetEndTime();
			}
		}
		else
		{
			mp_TrManager->GetDisplayTime(s, e);
		}
	mtx_read_filter.unlock();

	m_gantt->SetMinAbscissRange(s, e);

	return true;
}
//========================================================================

bool	CTVGantt::OnEventRead(const CTraceEvent* pTE)
{
//	CLog::Write(L_Reader, "CTVGantt::OnEventRead(): start\n");
			
	if (!CTraceVisualizer::OnEventRead(pTE))
	{
//		CLog::Write(L_Reader, "CTVGantt::OnEventRead(): return false\n");

		return false;
	}

//	CLog::Write(L_Reader, "CTVGantt::OnEventRead(): CTraceVisualizer::OnEventRead()\n");

	if (pTE->GetType() == CTraceEvent::E_task)
	{
		const CTaskEvent* pTS = static_cast<const CTaskEvent*>(pTE);

		int e = pTS->GetEvent();
		m_gantt->AddTaskType(e, mp_TrManager->GetMPIEventColor(e), mp_TrManager->GetMPIEventName(e));
		m_gantt->AddTask(pTS->GetProcessor(), pTS->GetTimeStart(), pTS->GetTimeEnd(), pTS->GetEvent());

//		CLog::Write(L_Reader, "CTVGantt::OnEventRead(): CTraceEvent::E_task OK\n");
	}

	if (pTE->GetType() == CTraceEvent::E_message)
	{
		const CMessageEvent* pTM = static_cast<const CMessageEvent*>(pTE);

		m_gantt->AddLink(pTM->GetPrcSend(), pTM->GetPrcRecv(), pTM->GetTimeSend(), pTM->GetTimeRecv());

//		CLog::Write(L_Reader, "CTVGantt::OnEventRead(): CTraceEvent::E_message OK\n");
	}

	return true;
}
//========================================================================

bool	CTVGantt::OnEndTraceRead()
{
	return true;
}
//========================================================================

void	CTVGantt::languageChange()
{
    setCaption( trUtf8( "\xd0\x93\xd0\xb0\xd0\xbd\xd1\x82\xd1\x82" ) );
    mb_Filter->setText( trUtf8( "\xd0\xa4\xd0\xb8\xd0\xbb\xd1\x8c\xd1\x82\xd1\x80" ) );
    mg_Time->setTitle( trUtf8( "\xd0\x92\xd1\x80\xd0\xb5\xd0\xbc\xd1\x8f" ) );
    mr_Global->setText( trUtf8( "\xd0\xb3\xd0\xbb\xd0\xbe\xd0\xb1\xd0\xb0\xd0\xbb\xd1\x8c\xd0\xbd\xd0\xbe\xd0\xb5" ) );
    mr_Local->setText( trUtf8( "\xd0\xbb\xd0\xbe\xd0\xba\xd0\xb0\xd0\xbb\xd1\x8c\xd0\xbd\xd0\xbe\xd0\xb5" ) );
    mb_MakeGlobal->setText( trUtf8( "\xd1\x81\xd0\xb4\xd0\xb5\xd0\xbb\xd0\xb0\xd1\x82\xd1\x8c\xd\xa\xd0\xb3\xd0\xbb\xd0\xbe\xd0\xb1\xd0\xb0\xd0\xbb\xd1\x8c\xd0\xbd\xd1\x8b\xd0\xbc" ) );
}
//========================================================================

void	CTVGantt::OnFilterChanged(int /* id */)
{
	if (mr_Global->isChecked())
		ToGlobalTime();

	if (mr_Local->isChecked())
		ToLocalTime();
}
//========================================================================

void	CTVGantt::SetGlobalTime()
{
	if (!mp_ReadFilter)
		return;

	double s = mp_ReadFilter->GetTimeMin();
	double e = mp_ReadFilter->GetTimeMax();

	PrepareGlobal();

	mp_TrManager->ChangeTime(s, e);
}
//========================================================================

void	CTVGantt::OnShowFilter()
{
	ShowFilterWindow();
}
//========================================================================

void	CTVGantt::SetTime(double start, double end)
{
	CLog::Write(L_GUI, "CTVGantt::SetTime(): start\n");

//	m_gantt->SetMinAbscissRange(start, end);

	ChangeTimeForce(start, end);

//	CQuickBox::Msg("CTVGantt::SetTime(): end");
	CLog::Write(L_GUI, "CTVGantt::SetTime(): return\n");
}
//========================================================================

void	CTVGantt::ToLocalTime(bool force /* = false */)
{
	if (mp_ReadFilter && !force)	//already have local filter
		return;

	mp_ReadFilter = new CTraceFilter(*mp_TrManager->GetFilter());

	mp_TrManager->StartReadTrace(this);

	mb_MakeGlobal->setEnabled(true);
}
//========================================================================

void	CTVGantt::ToGlobalTime(bool force /* = false */)
{
	if (!mp_ReadFilter && !force)	//already have global filter
		return;

	PrepareGlobal();

	mp_TrManager->StartReadTrace(this);
}
//========================================================================

void	CTVGantt::PrepareGlobal()
{
	if (mp_FilterWindow)
		if (mp_FWOwner)
			mp_FWOwner->HideFilter(this);

	delete mp_ReadFilter;
	mp_ReadFilter = NULL;

	mr_Global->setChecked(true);
	mb_MakeGlobal->setEnabled(false);
}
//========================================================================
