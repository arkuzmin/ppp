#ifndef _CONDITION_H_
#define _CONDITION_H_

#include <qvaluevector.h>

template <typename T>
class CCondition
{
public:
	virtual ~CCondition()
		{}

	virtual CCondition<T>*	GetCopy() const = 0;

	virtual bool Satisfy(const T& v) const = 0;
};
//========================================================================

template <typename T>
class CCondEqual: public CCondition<T>
{
public:
	CCondEqual(T v)
	{
		m_val = v;
	}

	virtual ~CCondEqual()
		{}

	virtual CCondition<T>*	GetCopy() const
	{
		return new CCondEqual<T>(*this);
	}

	virtual bool Satisfy(const T& v) const
	{
		return m_val == v;
	}

private:
	T m_val;
};
//========================================================================

template <typename T>
class CCondBetween: public CCondition<T>
{
public:
	CCondBetween(T min, T max)
	{
		m_min = min;
		m_max = max;
	}

	virtual ~CCondBetween()
		{}

	virtual CCondition<T>*	GetCopy() const
	{
		return new CCondBetween<T>(*this);
	}

	virtual bool Satisfy(const T& v) const
	{
		return v >= m_min && v <= m_max;
	}

private:
	T m_min;
	T m_max;
};
//========================================================================

template <typename T>
class CCondAnd: public CCondition<T>
{
public:
	virtual ~CCondAnd()
	{
		ClearConditions();
	}

	void	ClearConditions()
	{
		for (size_t i = 0; i < mv_Cond.size(); i++)
			delete mv_Cond[i];
		mv_Cond.clear();
	}

	void	AddCondition(CCondition<T>* pC)
	{
		mv_Cond.push_back(pC->GetCopy());
	}

	virtual CCondition<T>*	GetCopy() const
	{
		CCondAnd<T>* pC = new CCondAnd<T>;

		for (size_t i = 0; i < mv_Cond.size(); i++)
			pC->AddCondition(mv_Cond[i]->GetCopy());

		return pC;
	}

	virtual bool Satisfy(const T& v) const
	{
		for (size_t i = 0; i < mv_Cond.size(); i++)
			if (!mv_Cond[i]->Satisfy(v))
				return false;
		return true;
	}

protected:
	typedef QValueVector<CCondition<T>*>	TCondVec;

	TCondVec mv_Cond;
};
//========================================================================

template <typename T>
class CCondOr: public CCondition<T>
{
public:
	virtual ~CCondOr()
	{
		ClearConditions();
	}

	void	ClearConditions()
	{
		for (size_t i = 0; i < mv_Cond.size(); i++)
			delete mv_Cond[i];
		mv_Cond.clear();
	}

	void	AddCondition(CCondition<T>* pC)
	{
		mv_Cond.push_back(pC->GetCopy());
	}

	virtual CCondition<T>*	GetCopy() const
	{
		CCondOr<T>* pC = new CCondOr<T>;

		for (size_t i = 0; i < mv_Cond.size(); i++)
			pC->AddCondition(mv_Cond[i]->GetCopy());

		return pC;
	}

	virtual bool Satisfy(const T& v) const
	{
		for (size_t i = 0; i < mv_Cond.size(); i++)
			if (mv_Cond[i]->Satisfy(v))
				return true;
		return false;
	}

protected:
	typedef QValueVector<CCondition<T>*>	TCondVec;

	TCondVec mv_Cond;
};
//========================================================================

typedef CCondition<int>		TIntCond;
typedef CCondition<double>	TDoubleCond;

typedef QValueVector<TIntCond*>		TICondVec;
typedef QValueVector<TDoubleCond*>	TDCondVec;
//========================================================================


#endif	//_CONDITION_H_
