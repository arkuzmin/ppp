/****************************************************************************
** Form interface generated from reading ui file 'fgantt.ui'
**
** Created: Пн 19. июл 14:37:00 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FGANTT_H
#define FGANTT_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qmainwindow.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
namespace Chart {
class CGanttChart;
}
class QPushButton;
class QButtonGroup;
class QRadioButton;

class FGantt : public QMainWindow
{
    Q_OBJECT

public:
    FGantt( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~FGantt();

    QPushButton* mb_Filter;
    Chart::CGanttChart* m_gantt;
    QButtonGroup* mg_Time;
    QRadioButton* mr_Global;
    QRadioButton* mr_Local;
    QPushButton* mb_MakeGlobal;

protected:
    QGridLayout* FGanttLayout;
    QSpacerItem* spacer3;
    QGridLayout* mg_TimeLayout;
    QSpacerItem* spacer2;

protected slots:
    virtual void languageChange();

private:
    QPixmap image0;

};

#endif // FGANTT_H
