/****************************************************************************
** Form implementation generated from reading ui file 'fcommunicationmatrix.ui'
**
** Created: Пн 19. июл 14:37:00 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "fcommunicationmatrix.h"

#include <qvariant.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qaction.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qtoolbar.h>
#include <qimage.h>
#include <qpixmap.h>

#include "Chart.h"
/*
 *  Constructs a FCommunicationMatrix as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 */
FCommunicationMatrix::FCommunicationMatrix( QWidget* parent, const char* name, WFlags fl )
    : QMainWindow( parent, name, fl )
{
    (void)statusBar();
    if ( !name )
	setName( "FCommunicationMatrix" );
    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FCommunicationMatrixLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FCommunicationMatrixLayout"); 

    mg_state = new QButtonGroup( centralWidget(), "mg_state" );
    mg_state->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, mg_state->sizePolicy().hasHeightForWidth() ) );
    mg_state->setColumnLayout(0, Qt::Vertical );
    mg_state->layout()->setSpacing( 6 );
    mg_state->layout()->setMargin( 11 );
    mg_stateLayout = new QVBoxLayout( mg_state->layout() );
    mg_stateLayout->setAlignment( Qt::AlignTop );

    mr_volume = new QRadioButton( mg_state, "mr_volume" );
    mg_stateLayout->addWidget( mr_volume );

    mr_count = new QRadioButton( mg_state, "mr_count" );
    mg_stateLayout->addWidget( mr_count );

    mr_mean = new QRadioButton( mg_state, "mr_mean" );
    mg_stateLayout->addWidget( mr_mean );

    FCommunicationMatrixLayout->addWidget( mg_state, 0, 1 );

    textLabel2 = new QLabel( centralWidget(), "textLabel2" );

    FCommunicationMatrixLayout->addWidget( textLabel2, 1, 1 );

    textLabel1 = new QLabel( centralWidget(), "textLabel1" );

    FCommunicationMatrixLayout->addWidget( textLabel1, 2, 1 );

    m_martix = new Chart::CMatrix( centralWidget(), "m_martix" );
    m_martix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, m_martix->sizePolicy().hasHeightForWidth() ) );

    FCommunicationMatrixLayout->addMultiCellWidget( m_martix, 0, 2, 0, 0 );

    // toolbars

    languageChange();
    resize( QSize(641, 365).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( mg_state, SIGNAL( toggled(bool) ), this, SLOT( StateChanged(bool) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FCommunicationMatrix::~FCommunicationMatrix()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void FCommunicationMatrix::languageChange()
{
    setCaption( trUtf8( "\xd0\x9c\xd0\xb0\xd1\x82\xd1\x80\xd0\xb8\xd1\x86\xd0\xb0\x20\xd0\xb2\xd0\xb7\xd0\xb0\xd0\xb8\xd0\xbc\xd0\xbe\xd0\xb4\xd0\xb5\xd0\xb9\xd1\x81\xd1\x82\xd0\xb2\xd0\xb8\xd0\xb9" ) );
    mg_state->setTitle( trUtf8( "\xd0\x9f\xd0\xbe\xd0\xba\xd0\xb0\xd0\xb7\xd0\xb0\xd1\x82\xd1\x8c" ) );
    mr_volume->setText( trUtf8( "\xd0\x9e\xd0\xb1\xd1\x8a\xd1\x91\xd0\xbc\x20\xd0\xb4\xd0\xb0\xd0\xbd\xd0\xbd\xd1\x8b\xd1\x85" ) );
    mr_count->setText( trUtf8( "\xd0\x9a\xd0\xbe\xd0\xbb\xd0\xb8\xd1\x87\xd0\xb5\xd1\x81\xd1\x82\xd0\xb2\xd0\xbe\x20\xd1\x81\xd0\xbe\xd0\xbe\xd0\xb1\xd1\x89\xd0\xb5\xd0\xbd\xd0\xb8\xd0\xb9" ) );
    mr_mean->setText( trUtf8( "\xd0\xa1\xd1\x80\xd0\xb5\xd0\xb4\xd0\xbd\xd1\x8f\xd1\x8f\x20\xd0\xb4\xd0\xbb\xd0\xb8\xd0\xbd\xd0\xb0\x20\xd1\x81\xd0\xbe\xd0\xbe\xd0\xb1\xd1\x89\xd0\xb5\xd0\xbd\xd0\xb8\xd1\x8f" ) );
    textLabel2->setText( trUtf8( "\xd0\x9f\xd0\xbe\xd0\xbb\xd1\x83\xd1\x87\xd0\xb0\xd1\x82\xd0\xb5\xd0\xbb\xd1\x8c" ) );
    textLabel1->setText( trUtf8( "\xd0\x9e\xd1\x82\xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2\xd0\xb8\xd1\x82\xd0\xb5\xd0\xbb\xd1\x8c" ) );
}

void FCommunicationMatrix::StateChanged(bool)
{
    qWarning( "FCommunicationMatrix::StateChanged(bool): Not implemented yet" );
}

