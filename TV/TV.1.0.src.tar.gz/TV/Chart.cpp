#include "Chart.h"

#include "Log.h"

namespace Chart
{

CAxis::CAxis(EDirection dir /* = D_horizontal */, ETextPos tpos /* = TP_down */)
{
	m_Direction	= dir;
	m_TextPos	= tpos;

	m_range_min	= 0.0;
	m_range_max	= 0.0;

	mb_force_points = false;

	m_scale_hgh			= 5;
	m_label_frame		= 5;
	m_cross_point_space	= 3;
	m_cross_label_space	= 1;
}

CAxis::~CAxis()
{
}
//========================================================================

void	CAxis::Draw(QPainter& pnt)
{
	pnt.save();
	QRect viewport_orig = pnt.viewport();
	pnt.setViewport(mr_Boundary);
	QRect window_orig = pnt.window();
	pnt.setWindow(0, 0, mr_Boundary.width(), mr_Boundary.height());

	int width = GetLogicalWidth();
	int height = GetLogicalHeight();

	if (m_Direction == D_horizontal)
	{
		//coord system is OK
	}

	if (m_Direction == D_vertical)
	{
		pnt.translate(0.0, mr_Boundary.height());
		pnt.rotate(-90.0);
	}

	int axis_hgh = -1;
	if (m_TextPos == TP_up)
		axis_hgh = 0;
	if (m_TextPos == TP_down)
		axis_hgh = height;

	//draw axis
	{
		pnt.drawLine(0, axis_hgh, width, axis_hgh);
	}

	//draw scale
	int max_label = 0;
	if (height >= m_scale_hgh)
	{
		int l_up = -1, l_dn = -1;
		if (m_TextPos == TP_up)
			{l_up = 0; l_dn = m_scale_hgh;}
		if (m_TextPos == TP_down)
			{l_up = height - m_scale_hgh; l_dn = height;}

		//int last_point = -m_cross_point_space - 1;
		//int last_label = -m_cross_label_space - 1;
		int last_point = -50;
		int last_label = -50;
		for (size_t i = 0; i < mv_Labels.size(); i++)
		{

			if (!InRange(mv_Labels[i].start) && !InRange(mv_Labels[i].end))
				continue;

			//label edges
			double left		= ToRange(mv_Labels[i].start);
			double right	= ToRange(mv_Labels[i].end);

			//label
			bool draw_label = false;
			{
				pnt.save();
				pnt.rotate(90);

				QRect lr = pnt.fontMetrics().boundingRect(mv_Labels[i].text);

				if (lr.width() > max_label)
					max_label = lr.width();

				if (FitLabel(lr.width()))
				{
					QRect ldraw;
					int x = -(ToScreen(right) + ToScreen(left)) / 2;
					ldraw.setTop(x - lr.height() / 2);
					ldraw.setBottom(x + lr.height() / 2);

					if (last_label + m_cross_label_space < -ldraw.bottom())
					{
						if (m_TextPos == TP_up)
						{
							ldraw.setLeft(GetLabelStart());
							ldraw.setRight(GetLabelStart() + lr.width());
						}

						if (m_TextPos == TP_down)
						{
							ldraw.setLeft(height - GetLabelStart() - lr.width());
							ldraw.setRight(height - GetLabelStart());
						}

						pnt.drawText(ldraw, Qt::AlignVCenter, mv_Labels[i].text);

						last_label = -ldraw.top();
						draw_label = true;
					}
				}
				else	//label don't fit
				{
					draw_label = true;
				}

				pnt.restore();
			}//label

			if (!mb_force_points)
				if (!draw_label)
					continue;

			//points
			if (InRange(left))
			{
				int x = ToScreen(left);
				if (last_point + m_cross_point_space < x)
				{
					pnt.drawLine(x, l_up, x, l_dn);
					last_point = x;
				}
			}

			//right point
			if (InRange(right))
			{
				int x = ToScreen(right);
				if (last_point + m_cross_point_space < x)
				{
					pnt.drawLine(x, l_up, x, l_dn);
					last_point = x;
				}
			}
		}
	}//scale

	//axis name
	QRect nr = pnt.fontMetrics().boundingRect(ms_Name);
	if (FitName(max_label, nr.width(), nr.height()))
	{
		int hs = GetNameHeightSpaced(max_label, nr.height());

		if (hs)
		{
			QRect ndraw;
			ndraw.setLeft(0);
			ndraw.setRight(width);
			ndraw.setTop(0);
			ndraw.setBottom(hs);

			if (m_TextPos == TP_up)
				ndraw.moveTop(GetNameStart(max_label));
			if (m_TextPos == TP_down)
				ndraw.moveBottom(height - GetNameStart(max_label));

			pnt.drawText(ndraw, Qt::AlignVCenter | Qt::AlignHCenter, ms_Name);
		}
	}

	pnt.setWindow(window_orig);
	pnt.setViewport(viewport_orig);
	pnt.restore();
}
//========================================================================

void	CAxis::Direction(EDirection d)
{
	m_Direction = d;
}
//========================================================================

void	CAxis::TextPosition(ETextPos tp)
{
	m_TextPos = tp;
}
//========================================================================

void	CAxis::Name(const QString& n)
{
	ms_Name = n;
}
//========================================================================

void	CAxis::ClearName()
{
	ms_Name.truncate(0);
}
//========================================================================

void	CAxis::SetRange(double s, double e)
{
	bool grow = m_range_min < m_range_max ? true : false;

	m_range_min	= s;
	m_range_max	= e;

	if (m_range_min < m_range_max && !grow ||
		m_range_min >= m_range_max && grow)
	{
		SortLabels();
	}
}
//========================================================================

bool	CAxis::InRange(double d)
{
	return (d >= m_range_min && d <= m_range_max) ||
		(d >= m_range_max && d <= m_range_min);
}
//========================================================================

void	CAxis::SetRect(const QRect& r)
{
	mr_Boundary = r;
}
//========================================================================

int		CAxis::GetPreferredHeight(QPainter& pnt)
{
	int hgh = 0;

	hgh = GetLabelStart();

	int max_label = 0;
	for (size_t i = 0; i < mv_Labels.size(); i++)
	{
		int a = pnt.fontMetrics().boundingRect(mv_Labels[i].text).width();
		if (a > max_label)
			max_label = a;
	}
	if (max_label)
		hgh += max_label + m_label_frame;

	int name_hgh = 0;
	if (!ms_Name.isEmpty() && !ms_Name.isNull())
	{
		name_hgh = pnt.fontMetrics().boundingRect(ms_Name).height();
	}
	if (name_hgh)
		hgh += GetPreferredNameHeight(name_hgh);

	return hgh;
}
//========================================================================

void	CAxis::GetWidthBearings(QPainter& pnt, int& start, int& end)
{
	QString s = "WWW";	//some large letters

	int h = pnt.fontMetrics().boundingRect(s).height();
	h = (h + 1) / 2;
	start = h;
	end = h;
}
//========================================================================

void	CAxis::AddLabel(double start, double end, QString l)
{
	//sort for correct labelling

	if (m_range_min < m_range_max)	//sort ascending
	{
		TLabelIter it;
		for (it = mv_Labels.begin(); it != mv_Labels.end(); ++it)
		{
			if (start < it->start)
			{
				mv_Labels.insert(it, SLabel(start, end, l));
				break;
			}
		}
		if (it == mv_Labels.end())
			mv_Labels.push_back(SLabel(start, end, l));
	}
	else	//sort descending
	{
		TLabelIter it;
		for (it = mv_Labels.begin(); it != mv_Labels.end(); ++it)
		{
			if (start > it->start)
			{
				mv_Labels.insert(it, SLabel(start, end, l));
				break;
			}
		}
		if (it == mv_Labels.end())
			mv_Labels.push_back(SLabel(start, end, l));
	}
}
//========================================================================
	
void	CAxis::AddLabel(double point, int prec)
{
	QString f, s;
	f.sprintf("%%.%df", prec);
	s.sprintf(f, point);
	AddLabel(point, point, s);
}
//========================================================================

void	CAxis::SetLabel(double start, double end, QString l)
{
	//look for label, if exists - replace it
	size_t i;
	for (i = 0; i < mv_Labels.size(); i++)
		if (mv_Labels[i].start == start && mv_Labels[i].end == end)
		{
			mv_Labels[i].text = l;
			break;
		}

	if (i == mv_Labels.size())	//label not found - add new
		AddLabel(start, end, l);
}
//========================================================================

void	CAxis::ClearLabels()
{
	mv_Labels.clear();

}
//========================================================================

int		CAxis::ToScreen(double d)
{
	if (m_range_max != m_range_min)
	{
		return (int)(GetLogicalWidth() * (d - m_range_min) / (m_range_max - m_range_min));
	}
	else
		return 0;
}
//========================================================================

double	CAxis::ToData(int s)
{
	int w = GetLogicalWidth();
	if (w != 0)
	{
		return (double)s / (double)w * (m_range_max - m_range_min) + m_range_min;
	}
	else
		return 0.0;
}
//========================================================================

int	CAxis::GetLogicalHeight() const
{
	if (m_Direction == D_horizontal)
		return mr_Boundary.height();
	if (m_Direction == D_vertical)
		return mr_Boundary.width();

	return 0;
}
//========================================================================

int	CAxis::GetLogicalWidth() const
{
	if (m_Direction == D_horizontal)
		return mr_Boundary.width();
	if (m_Direction == D_vertical)
		return mr_Boundary.height();

	return 0;
}
//========================================================================

double	CAxis::ToRange(double d)
{
	if (m_range_min < m_range_max)
	{
		if (d >= m_range_min && d <= m_range_max)
			return d;
		else if (d < m_range_min)
			return m_range_min;
		else
			return m_range_max;
	}
	else
	{
		if (d <= m_range_min && d >= m_range_max)
			return d;
		else if (d < m_range_max)
			return m_range_max;
		else
			return m_range_min;
	}

}
//========================================================================

void	CAxis::SortLabels()
{
	if (m_range_min < m_range_max)	//ascending
	{
		for (size_t i = 1; i < mv_Labels.size(); i++)
		{
			for (size_t j = 0; j < i; j++)
			{
				if (mv_Labels[j].start > mv_Labels[i].start)
				{
					SLabel l = mv_Labels[i];

					for (size_t k = i; k > j; k--)
						mv_Labels[k] = mv_Labels[k-1];

					mv_Labels[j] = l;

					break;
				}
			}
		}
	}
	else	//descending
	{
		for (size_t i = 1; i < mv_Labels.size(); i++)
		{
			for (size_t j = 0; j < i; j++)
			{
				if (mv_Labels[j].start < mv_Labels[i].start)
				{
					SLabel l = mv_Labels[i];

					for (size_t k = i; k > j; k--)
						mv_Labels[k] = mv_Labels[k-1];

					mv_Labels[j] = l;

					break;
				}
			}
		}
	}
}
//========================================================================

int	CAxis::GetNameHeightSpaced(int max_label, int nh) const
{
	int free = GetLogicalHeight() - GetNameStart(max_label);
	int pref = GetPreferredNameHeight(nh);
	if (pref <= free)	//free to have preferred
	{
		return pref;
	}
	else	//preferred not fit
	{
		if (nh < free)	//all we have
			return free;
	}

	return 0;
}
//========================================================================

bool	CAxis::FitLabel(int l_width) const
{
	if (GetLabelStart() + l_width > GetLogicalHeight())
		return false;
	else
		return true;
}
//========================================================================

bool	CAxis::FitName(int max_label, int w, int h) const
{
	if (GetNameStart(max_label) + h > GetLogicalHeight())
	{
		return false;	//too tall
	}
	else
	{
		if (w > GetLogicalWidth())
			return false;	//too fat
	}

	return true;
}
//========================================================================

//class CAxis
//************************************************************************
//************************************************************************



//class CColorLegend
CColorLegend::CColorLegend()
{
	m_color_size		= 10;
	m_color_name_space	= 5;
	m_line_space		= 5;
}

CColorLegend::~CColorLegend()
{
}
//========================================================================

void	CColorLegend::AddItem(const QColor& color, const QString& name)
{
	mv_Items.push_back(SItem(color, name));
}
//========================================================================

void	CColorLegend::ClearItems()
{
	mv_Items.clear();
}
//========================================================================

QRect	CColorLegend::GetPreferredSize(QPainter& pnt)
{
	QRect res;
	res.rTop()	= 0;
	res.rLeft()	= 0;
	res.rBottom()	= 0;
	res.rRight()	= 0;

	for (size_t i = 0; i < mv_Items.size(); i++)
	{
		QRect r = pnt.fontMetrics().boundingRect(mv_Items[i].name);
		if (r.width() > res.rRight())
			res.rRight() = r.width();

		int h = r.height();
		res.rBottom() += max(h, m_color_size);

		if (i < mv_Items.size() - 1)	//not last
			res.rBottom() += m_line_space;
	}

	res.rRight() += m_color_size;
	res.rRight() += m_color_name_space;

	return res;
}
//========================================================================

void	CColorLegend::Draw(QPainter& pnt, const QRect& r)
{
	if (r.width() < m_color_size)
		return;

	QRect orig_viewport = pnt.viewport();
	QRect orig_window = pnt.window();
	QRect vp = r;
	vp.moveBy(orig_viewport.left(), orig_viewport.top());
	pnt.setViewport(vp);
	pnt.setWindow(0, 0, vp.width(), vp.height());

	QBrush orig_brush = pnt.brush();

	QRect cr(0, 0, m_color_size, m_color_size);
	QRect nr;
	int h = 0;
	size_t i = 0;
	while (h + m_color_size <= r.height() && i < mv_Items.size())
	{
		pnt.setBrush(mv_Items[i].color);

		cr.moveTop(h);
		pnt.drawRect(cr);

		nr = pnt.fontMetrics().boundingRect(mv_Items[i].name);
		nr.moveLeft(m_color_size + m_color_name_space);
		nr.moveTop(h + m_color_size/2 - nr.height()/2);
		nr.rRight() = r.width();

		pnt.drawText(nr, Qt::AlignLeft, mv_Items[i].name);

		h += m_color_size;
		h += m_line_space;

		i++;
	}

	pnt.setBrush(orig_brush);

	pnt.setViewport(orig_viewport);
	pnt.setWindow(orig_window);
}
//========================================================================

//class CColorLegend
//************************************************************************
//************************************************************************



//class CColorGradient
CColorGradient::CColorGradient()
	:m_value_axis(CAxis::D_vertical, CAxis::TP_down)
{
	m_range_min = 0;
	m_range_max = 0;

	m_value_axis.ForcePoints(true);

	m_line_hgh = 2;
}

CColorGradient::~CColorGradient()
{
}
//========================================================================

void	CColorGradient::SetRange(double min, double max)
{
	m_range_min = min;
	m_range_max = max;

	m_value_axis.SetRange(min, max);
	m_value_axis.ClearLabels();

	m_value_axis.AddLabel(min, 0);
	m_value_axis.AddLabel(max, 0);
	m_value_axis.AddLabel((min + max) / 2.0, 0);
}
//========================================================================

void	CColorGradient::SetColorRange(const QColor& cmin, const QColor& cmax)
{
	m_color_min = cmin;
	m_color_max = cmax;
}
//========================================================================

void	CColorGradient::Draw(QPainter& pnt, QRect r)
{
	int sb, eb;
	m_value_axis.GetWidthBearings(pnt, sb, eb);
	r.setTop(r.top() + eb);
	r.setBottom(r.bottom() - sb);

	QRect viewport_orig = pnt.viewport();
	r.moveBy(viewport_orig.left(), viewport_orig.top());
	pnt.setViewport(r);
	QRect window_orig = pnt.window();
	pnt.setWindow(0, 0, r.width(), r.height());

	int pw = m_value_axis.GetPreferredHeight(pnt);
	int ax_width = min(pw, r.width() / 2);

	//draw axis
	{
		QRect ar = r;
		ar.setRight(ar.left() + ax_width);

		m_value_axis.SetRect(ar);
		m_value_axis.Draw(pnt);
	}

	//draw colors
	{
		QPen orig_pen = pnt.pen();
		QBrush orig_brush = pnt.brush();
		pnt.setPen(Qt::NoPen);

		QRect cr(ax_width + 1, r.height() - m_line_hgh, r.width() - ax_width, m_line_hgh);

		for (int i = m_line_hgh / 2; i < r.height(); i += m_line_hgh)
		{
			pnt.setBrush(GetColor(m_value_axis.ToData(i)));

			pnt.drawRect(cr);

			cr.moveBy(0, -m_line_hgh);
		}

		pnt.setPen(orig_pen);
		pnt.setBrush(orig_brush);
	}

	pnt.setWindow(window_orig);
	pnt.setViewport(viewport_orig);
}
//========================================================================

int	CColorGradient::GetPreferredWidth(QPainter& pnt, int color_width)
{
	return m_value_axis.GetPreferredHeight(pnt) + color_width;
}
//========================================================================

QColor	CPlainGradient::GetColor(double v) const
{
	if (v >= m_range_min && v <= m_range_max ||
		v >= m_range_max && v <= m_range_min)
	{
		double f;
		if (m_range_max == m_range_min)
			f = 0.5;
		else
			f = (v - m_range_min) / (m_range_max - m_range_min);

		return QColor(
			(int)((m_color_max.red() - m_color_min.red()) * f) + m_color_min.red(),
			(int)((m_color_max.green() - m_color_min.green()) * f) + m_color_min.green(),
			(int)((m_color_max.blue() - m_color_min.blue()) * f) + m_color_min.blue());
	}
	else
	{
		return m_color_NA;
	}
}
//========================================================================

//class CColorGradient
//************************************************************************
//************************************************************************



//class CChartBase
CChartBase::CChartBase(QWidget* parent /* = 0 */, const char* name /* = 0 */, WFlags f /* = 0 */)
	:QWidget(parent, name, f),
	m_absciss_axis(CAxis::D_horizontal),
	m_ordinates_axis(CAxis::D_vertical)
{
	m_absciss_pos	= AP_down;
	m_ordinates_pos	= AP_left;
}

CChartBase::~CChartBase()
{
}
//========================================================================

void	CChartBase::SetAbscissPos(EAxisPosition ap, bool upd /* = true */)
{
	m_absciss_pos = ap;

	if (upd)
		update();
}

void	CChartBase::SetOrdinatesPos(EAxisPosition ap, bool upd /* = true */)
{
	m_ordinates_pos = ap;

	if (upd)
		update();
}
//========================================================================

void	CChartBase::AbscissName(const QString& n, bool upd /* = true */)
{
	m_absciss_axis.Name(n);

	if (upd)
		update();
}

void	CChartBase::OrdinatesName(const QString& n, bool upd /* = true */)
{
	m_ordinates_axis.Name(n);

	if (upd)
		update();
}
//========================================================================

bool	CChartBase::InChartWorkspace(QPoint p)
{
	return p.x() >= m_absciss_axis.GetRect().left() &&
		p.x() <= m_absciss_axis.GetRect().right() &&
		p.y() <= m_ordinates_axis.GetRect().bottom() &&
		p.y() >= m_ordinates_axis.GetRect().top();
}
//========================================================================

void	CChartBase::Draw(QPainter& p)
{
	int ah = m_absciss_axis.GetPreferredHeight(p);
	int oh = m_ordinates_axis.GetPreferredHeight(p);

	int asb, aeb;
	int osb, oeb;
	m_absciss_axis.GetWidthBearings(p, asb, aeb);
	m_ordinates_axis.GetWidthBearings(p, osb, oeb);
	int ab = max(asb, aeb);
	int ob = max(osb, oeb);

	QRect r = p.viewport();
	r.normalize();
	int w = r.right() - r.left();
	int h = r.bottom() - r.top();

	int max;
	max = h / 2;
	ah = min(ah, max);
	max = w / 2;
	oh = min(oh, max);

	QRect a_r;
	QRect o_r;

	if (m_absciss_pos == AP_down)
	{
		m_absciss_axis.TextPosition(CAxis::TP_up);

		a_r.setTop(h - ah);
		a_r.setBottom(h);

		o_r.setTop(ob);
		o_r.setBottom(h - ah);
	}
	if (m_absciss_pos == AP_top)
	{
		m_absciss_axis.TextPosition(CAxis::TP_down);

		a_r.setTop(0);
		a_r.setBottom(ah);

		o_r.setTop(ah);
		o_r.setBottom(h - ob);
	}

	if (m_ordinates_pos == AP_left)
	{
		m_ordinates_axis.TextPosition(CAxis::TP_down);

		a_r.setLeft(oh);
		a_r.setRight(w - ab);

		o_r.setLeft(0);
		o_r.setRight(oh);
	}
	if (m_ordinates_pos == AP_right)
	{
		m_ordinates_axis.TextPosition(CAxis::TP_up);

		a_r.setLeft(ab);
		a_r.setRight(w - oh);

		o_r.setLeft(w - oh);
		o_r.setRight(w);
	}

	m_absciss_axis.SetRect(a_r);
	m_ordinates_axis.SetRect(o_r);

	m_absciss_axis.Draw(p);
	m_ordinates_axis.Draw(p);
}
//========================================================================

void CChartBase::paintEvent(QPaintEvent*)
{
	QPainter p(this);

	Draw(p);
}
//========================================================================

//class CChartBase
//************************************************************************
//************************************************************************



//class CMatrix

CMatrix::CMatrix(QWidget* parent /* = 0 */, const char* name /* = 0 */, WFlags f /* = 0 */)
	:CChartBase(parent, name, f)
{
	m_absciss_pos = AP_top;

	m_absciss_axis.ForcePoints(true);
	m_ordinates_axis.ForcePoints(true);

	m_legend.SetNAColor(Qt::white);
	m_legend.SetColorRange(Qt::blue, Qt::red);

	m_size_y = 0;
	m_size_x = 0;

	mb_minmax_defined = false;

	m_min_grid_draw = 10;
	m_legend_space = 10;
	m_legend_color_width = 30;

	mc_grid = Qt::black;
}
//========================================================================

CMatrix::~CMatrix()
{
}
//========================================================================

bool	CMatrix::SetSize(int y, int x, bool set_names /* = true */)
{
	if (y >= 0 && x >= 0)
	{

		m_size_y = y;
		m_size_x = x;

		m_absciss_axis.SetRange(0, x);
		m_ordinates_axis.SetRange(y, 0);

		m_absciss_axis.ClearLabels();
		m_ordinates_axis.ClearLabels();

		if (set_names)
		{
			for (int i = 0; i < x; i++)
				m_absciss_axis.AddLabel(i, i+1, QString::number(i));

			for (int i = y; i > 0; i--)
				m_ordinates_axis.AddLabel(i, i-1, QString::number(i-1));
		}

		m_data.clear();

		m_data.resize(y);
		for (size_t i = 0; i < m_data.size(); i++)
		{
			m_data[i].resize(x);

			for (size_t j = 0; j < m_data[i].size(); j++)
				m_data[i][j] = 0;
		}

		mb_minmax_defined = false;

		return true;
	}
	else
	{
		return false;
	}
}
//========================================================================

void	CMatrix::SetItem(int y, int x, int v)
{
	m_data[y][x] = v;

	if (!mb_minmax_defined)
	{
		m_min_value = v;
		m_max_value = v;

		m_legend.SetRange(m_min_value, m_max_value);

		mb_minmax_defined = true;
	}
	else
	{
		if (v < m_min_value)
		{
			m_min_value = v;

			m_legend.SetRange(m_min_value, m_max_value);
		}

		if (v > m_max_value)

		{
			m_max_value = v;

			m_legend.SetRange(m_min_value, m_max_value);
		}
	}
}
//========================================================================

void	CMatrix::InitItems(int n /* = 0 */)
{
	for (size_t i = 0; i < m_data.size(); i++)
		for (size_t j = 0; j < m_data[i].size(); j++)
			m_data[i][j] = n;

	mb_minmax_defined = false;
}
//========================================================================

void	CMatrix::SetColName(int n, const QString& name, bool upd /* = true */)
{
	if (n >= 0 && n < m_size_x)
		m_absciss_axis.SetLabel(n, n+1, name);

	if (upd)
		update();
}
//========================================================================

void	CMatrix::SetRowName(int n, const QString& name, bool upd /* = true */)
{
	if (n >= 0 && n < m_size_y)
		m_ordinates_axis.SetLabel(n, n+1, name);

	if (upd)
		update();
}
//========================================================================

void	CMatrix::ClearColNames(bool upd /* = true */)
{
	m_absciss_axis.ClearLabels();

	if (upd)
		update();
}
//========================================================================

void	CMatrix::ClearRowNames(bool upd /* = true */)
{
	m_ordinates_axis.ClearLabels();

	if (upd)
		update();
}
//========================================================================

void	CMatrix::Draw(QPainter& pnt)
{
	QRect viewport_orig = pnt.viewport();
	QRect window_orig = pnt.window();

	int lw = m_legend.GetPreferredWidth(pnt, m_legend_color_width);

	bool	b_legend = false;
	QRect mr = pnt.viewport();
	if (mr.width() >= lw * 2 + m_legend_space)	//draw legend
	{
		mr.setRight(mr.right() - lw - m_legend_space);

		b_legend = true;
	}
	else	//just matrix
	{
		b_legend = false;
	}

	//draw matrix
	{
		pnt.setViewport(mr);
		pnt.setWindow(mr);

		CChartBase::Draw(pnt);

		QRect a_r = m_absciss_axis.GetRect();
		QRect o_r = m_ordinates_axis.GetRect();

		QPen	orig_pen = pnt.pen();
		QBrush	orig_brush = pnt.brush();

		pnt.setPen(Qt::NoPen);

		QRect r;

		//if draw grid
		if (m_size_x > 0 && m_size_y > 0)
		{
			r.setTop(o_r.bottom() - m_ordinates_axis.ToScreen(0));
			r.setBottom(o_r.bottom() - m_ordinates_axis.ToScreen(1));
			r.setLeft(a_r.left() + m_absciss_axis.ToScreen(0));
			r.setRight(a_r.left() + m_absciss_axis.ToScreen(1));
			r = r.normalize();

			if (r.width() >= m_min_grid_draw && r.height() >= m_min_grid_draw)
				pnt.setPen(mc_grid);
		}

		for (size_t i = 0; i < m_data.size(); i++)
		{
			r.setTop(o_r.bottom() - m_ordinates_axis.ToScreen(i+1));
			r.setBottom(o_r.bottom() - m_ordinates_axis.ToScreen(i));
			r = r.normalize();

			for (size_t j = 0; j < m_data[i].size(); j++)
			{
				r.setLeft(a_r.left() + m_absciss_axis.ToScreen(j));
				r.setRight(a_r.left() + m_absciss_axis.ToScreen(j+1));

				pnt.setBrush(m_legend.GetColor(m_data[i][j]));
				pnt.drawRect(r);
			}
		}

		pnt.setBrush(orig_brush);
		pnt.setPen(orig_pen);

		pnt.setWindow(window_orig);
		pnt.setViewport(viewport_orig);
	}

	//draw legend
	if (b_legend)
	{
		QRect lr = pnt.viewport();

		lr.setLeft(lr.right() - lw);

		m_legend.Draw(pnt, lr);
	}
}
//========================================================================

void	CMatrix::CalcMinMax()
{
/*	if (m_data.size() == 0)
	{
		mb_minmax_defined = false;
		return;
	}

	if (m_data[0].size() == 0)
	{
		mb_minmax_defined = false;
		return;
	}

	m_min_value = m_data[0][0];
	m_max_value = m_data[0][0];
	for (size_t i = 0; i < m_data.size(); i++)
		for (size_t j = 0; j < m_data[i].size(); j++)
		{
			if (m_data[i][j] < m_min_value)
				m_max_value = m_data[i][j];

			if (m_data[i][j] > m_max_value)
				m_max_value = m_data[i][j];
		}

	m_legend.SetRange(m_min_value, m_max_value);
*/
}
//========================================================================

void	CMatrix::mousePressEvent(QMouseEvent* e)
{
	double y = m_ordinates_axis.ToData(m_ordinates_axis.GetRect().bottom() - e->y());
	double x = m_absciss_axis.ToData(e->x() - m_absciss_axis.GetRect().left());

	if (y >= 0.0 && x >= 0.0)
	{
		int iy = (int)y;
		int ix = (int)x;

		if (iy < m_size_y && ix < m_size_x)
		{
			QString s;
			s.sprintf("[%d - %d] = %d",	iy, ix, m_data[iy][ix]);
			CQuickBox::Msg(s);
		}
	}

}
//========================================================================

//class CMatrix
//************************************************************************
//************************************************************************



//class CBarChart
CBarChart::CBarChart(QWidget* parent /* = 0 */, const char* name /* = 0 */, WFlags f /* = 0 */)
	:CChartBase(parent, name, f)
{
	m_absciss_axis.ForcePoints(true);

	m_max_value = 0.0;
	m_min_value = 0.0;

	m_ordinate_labels_count = 15;
}

CBarChart::~CBarChart()
{
}
//========================================================================

void	CBarChart::SetItemCount(int n, bool upd /* = true */)
{
	m_data.resize(0);
	m_data.resize(n);

	m_max_value = 0.0;
	m_min_value = 0.0;

	m_absciss_axis.SetRange(0, n);
	m_absciss_axis.ClearLabels();

	if (upd)
		update();
}
//========================================================================

void	CBarChart::SetItemName(int n, const QString& name, bool upd /* = true */)
{
	if (n < 0 || n > (int)m_data.size())
		return;

	m_absciss_axis.SetLabel(n, n+1, name);

	if (upd)
		update();
}
//========================================================================

void	CBarChart::SetItemValue(int n, double v, bool upd /* = true */)
{
	if (n < 0 || n > (int)m_data.size())
		return;

	m_data[n].val = v;

	if (v < m_min_value)
	{
		m_min_value = v;
		InitOrdinates();
	}

	if (v > m_max_value)
	{
		m_max_value = v;
		InitOrdinates();
	}

	if (upd)
		update();
}
//========================================================================

void	CBarChart::SetItemColor(int n, const QColor& c, bool upd /* = true */)
{
	if (n < 0 || n > (int)m_data.size())
		return;

	m_data[n].col = c;

	if (upd)
		update();
}
//========================================================================

void	CBarChart::AddItemValue(int n, double v, bool upd /* = true */)
{
	if (n < 0 || n > (int)m_data.size())
		return;

	SetItemValue(n, m_data[n].val + v, upd);
}
//========================================================================

void	CBarChart::Draw(QPainter& pnt)
{
	CChartBase::Draw(pnt);

	QRect a_r = m_absciss_axis.GetRect();
	QRect o_r = m_ordinates_axis.GetRect();

	QPen	orig_pen = pnt.pen();
	QBrush	orig_brush = pnt.brush();

	//pnt.setPen(Qt::NoPen);

	QRect r;

	//if draw grid
	//if (m_size_x > 0 && m_size_y > 0)
	//{
	//	r.setTop(o_r.bottom() - m_ordinates_axis.ToScreen(0));
	//	r.setBottom(o_r.bottom() - m_ordinates_axis.ToScreen(1));
	//	r.setLeft(a_r.left() + m_absciss_axis.ToScreen(0));
	//	r.setRight(a_r.left() + m_absciss_axis.ToScreen(1));
	//	r = r.normalize();

	//	if (r.width() >= m_min_grid_draw && r.height() >= m_min_grid_draw)
	//		pnt.setPen(mc_grid);
	//}

	for (size_t i = 0; i < m_data.size(); i++)
	{
		r.setTop(o_r.bottom() - m_ordinates_axis.ToScreen(m_data[i].val));
		r.setBottom(o_r.bottom() - m_ordinates_axis.ToScreen(0.0));
		r = r.normalize();

		r.setLeft(a_r.left() + m_absciss_axis.ToScreen(i));
		r.setRight(a_r.left() + m_absciss_axis.ToScreen(i+1));

		pnt.setBrush(m_data[i].col);
		pnt.drawRect(r);
	}

	pnt.setBrush(orig_brush);
	pnt.setPen(orig_pen);
}
//========================================================================

void	CBarChart::InitOrdinates()
{
	m_ordinates_axis.ClearLabels();
	m_ordinates_axis.SetRange(m_min_value, m_max_value);

	double dl = (m_max_value - m_min_value) / m_ordinate_labels_count;
	
	m_ordinates_axis.AddLabel(0.0, 0.0, QString::number(0.0));

	double cl;
	cl = 0.0;
	while (cl < m_max_value)
	{
		m_ordinates_axis.AddLabel(cl, 4);
		cl += dl;
	}

	cl = 0.0;
	while (cl > m_min_value)
	{
		m_ordinates_axis.AddLabel(cl, 4);
		cl -= dl;
	}
}
//========================================================================

void	CBarChart::mousePressEvent(QMouseEvent* e)
{
/*	double y = m_ordinates_axis.ToData(m_ordinates_axis.GetRect().bottom() - e->y());
	double x = m_absciss_axis.ToData(e->x() - m_absciss_axis.GetRect().left());

	if (y >= 0.0 && x >= 0.0)
	{
		int iy = (int)y;
		int ix = (int)x;

		if (iy < m_size_y && ix < m_size_x)
		{
			QString s;
			s.sprintf("[%d - %d] = %d",	iy, ix, m_data[iy][ix]);
			CQuickBox::Msg(s);
		}
	}
*/
}
//========================================================================

//class CBarChart
//************************************************************************
//************************************************************************



//class CGanttChart
CGanttChart::CGanttChart(QWidget* parent /* = 0 */, const char* name /* = 0 */, WFlags f /* = 0 */)
	:CChartBase(parent, name, f),
	m_mutex(true)	//recursive
{
	mb_time_defined = false;
	m_time_start	= 0.0;
	m_time_end		= 0.0;

	mb_mouse_pressed = false;
	m_mouse_press_time		= 0.0;
	m_mouse_release_time	= 0.0;

	m_legend_space = 10;
	m_time_labels_count	= 10;

	m_task_hgh_fract	= 0.7;

	m_pen_proc_line.setColor(Qt::gray);
	m_pen_proc_line.setWidth(1);

	m_pen_link.setColor(QColor(0, 0, 70));
	m_link_min_width	= 1;
	m_link_fract		= 0.015;

	m_min_draw_border	= 6;

	mn_mouse_tolerance	= 3;

	m_pen_time_line.setColor(Qt::black);
	m_pen_time_line.setWidth(1);
	m_pen_time_line.setStyle(Qt::DashLine);
}

CGanttChart::~CGanttChart()
{
	ClearLinks();
	ClearTasks();
	ClearTaskTypes();
}
//========================================================================

void	CGanttChart::Lock()
{
	m_mutex.lock();
}

void	CGanttChart::Unlock()
{
	m_mutex.unlock();
}
//========================================================================

void	CGanttChart::SetProcCount(int n, bool clear_all /* = true */)
{
	QMutexLocker ml(&m_mutex);

	ClearTasks();

	if (clear_all)
	{
		ClearTaskTypes();
		ClearLinks();
	}

	mv_Proc.resize(n);

	m_ordinates_axis.SetRange(0, n);
	for (int i = 0; i < n; i++)
		m_ordinates_axis.AddLabel(i, i+1, QString::number(i));
}
//========================================================================

void	CGanttChart::SetProcName(int p, const QString& name, bool upd /* = true */)
{
	QMutexLocker ml(&m_mutex);

	if (p < 0 || p >= (int)mv_Proc.size())
		return;

	mv_Proc[p].name = name;

	if (upd)
		update();
}
//========================================================================

void	CGanttChart::ShowProc(int p, bool upd /* = true */)
{
	QMutexLocker ml(&m_mutex);

	if (p < 0 || p >= (int)mv_Proc.size())
		return;

	mv_Proc[p].show = true;

	if (upd)
		update();
}
//========================================================================

void	CGanttChart::HideProc(int p, bool upd /* = true */)
{
	QMutexLocker ml(&m_mutex);

	if (p < 0 || p >= (int)mv_Proc.size())
		return;

	mv_Proc[p].show = false;

	if (upd)
		update();
}
//========================================================================

void	CGanttChart::AddTaskType(int type, const QColor& c, const QString& name)
{
	QMutexLocker ml(&m_mutex);

	STaskType* pTT = GetTaskType(type);
	if (!pTT)
	{
		mv_TType.push_back(new STaskType(type, c, name));

		m_legend.AddItem(c, name);
	}
}
//========================================================================

void	CGanttChart::ClearTaskTypes()
{
	QMutexLocker ml(&m_mutex);

	for (size_t i = 0; i < mv_TType.size(); i++)
		delete mv_TType[i];

	mv_TType.clear();

	m_legend.ClearItems();
}
//========================================================================

void	CGanttChart::AddTask(int proc, double start, double end, int type)
{
	QMutexLocker ml(&m_mutex);

	if (proc < 0 || proc >= (int)mv_Proc.size())
		return;

	STaskType* pT = GetTaskType(type);

	mv_Proc[proc].tasks.push_back(STask(start, end, pT));

	CorrectTime(start, false, false);
	CorrectTime(end, true, true);
}
//========================================================================

void	CGanttChart::ClearTasks()
{
	QMutexLocker ml(&m_mutex);

	mv_Proc.clear();

	mb_time_defined = false;
}
//========================================================================

void	CGanttChart::AddLink(int from, int to, double start, double end)
{
	QMutexLocker ml(&m_mutex);

	if (from < 0 || from >= (int)mv_Proc.size() ||
		to < 0 || to >= (int)mv_Proc.size())
	{
		return;
	}

	mv_Links.push_back(SLink(from, to, start, end));
}
//========================================================================

void	CGanttChart::ClearLinks()
{
	QMutexLocker ml(&m_mutex);

	mv_Links.clear();
}
//========================================================================

void	CGanttChart::ClearTime()
{
	QMutexLocker ml(&m_mutex);

	m_time_start	= 0.0;
	m_time_end		= 0.0;
}
//========================================================================

void	CGanttChart::SetMinAbscissRange(double s, double e)
{
	QMutexLocker ml(&m_mutex);

	CorrectTime(s, false);
	CorrectTime(e, true, true);
}
//========================================================================

void	CGanttChart::Draw(QPainter& pnt)
{
	CLog::Write(L_GUI, "CGanttChart::Draw(): start\n");

	QMutexLocker ml(&m_mutex);
	CLog::Write(L_GUI, "CGanttChart::Draw(): m_mutex.lock()\n");

	QRect lr = m_legend.GetPreferredSize(pnt);
	bool draw_legend = false;
	if (pnt.viewport().width() > lr.width() * 2 + m_legend_space)
	{
		draw_legend = true;
		lr.setBottom(pnt.viewport().height());
	}

	QRect gr = pnt.viewport();
	if (draw_legend)
	{
		gr.rRight() -= m_legend_space + lr.width();
	}

	//draw gantt
	{
		QRect orig_viewport = pnt.viewport();
		QRect orig_window = pnt.window();
		pnt.setViewport(gr);
		pnt.setWindow(gr);

		//count showed proc
		int showed_proc = 0;
		for (size_t i = 0; i < mv_Proc.size(); i++)
			if (mv_Proc[i].show)
				showed_proc++;

		//set proc names
		m_ordinates_axis.SetRange(0, showed_proc);
		m_ordinates_axis.ClearLabels();
		int p = 0;
		for (size_t i = 0; i < mv_Proc.size(); i++)
		{
			if (mv_Proc[i].show)
			{
				m_ordinates_axis.SetLabel(p, p+1, mv_Proc[i].name);
				p++;
			}
		}

		CChartBase::Draw(pnt);

		QBrush orig_brush = pnt.brush();
		QPen orig_pen = pnt.pen();

		int task_hgh = (m_ordinates_axis.GetRect().bottom() - m_ordinates_axis.GetRect().top()) /
			showed_proc;

		//tasks
		QRect tr;
		int proc_line = 0;
		for (size_t i = 0; i < mv_Proc.size(); i++)
		{
			if (!mv_Proc[i].show)
				continue;

			mv_Proc[i].chart_line = proc_line;

			int h = (int)((m_ordinates_axis.ToScreen(proc_line) -
				m_ordinates_axis.ToScreen(proc_line+1)) * m_task_hgh_fract);

			int m = (m_ordinates_axis.ToScreen(proc_line) +
				m_ordinates_axis.ToScreen(proc_line+1)) / 2;
			m = m_ordinates_axis.GetRect().bottom() - m;

			tr.rTop() = m - h / 2;
			tr.rBottom() = m + h / 2;
			tr = tr.normalize();

			pnt.setPen(m_pen_proc_line);

			pnt.drawLine(m_absciss_axis.GetRect().left() + m_absciss_axis.ToScreen(m_time_start), m,
				m_absciss_axis.GetRect().left() + m_absciss_axis.ToScreen(m_time_end), m);

			if (task_hgh < m_min_draw_border)
				pnt.setPen(Qt::NoPen);
			else
				pnt.setPen(orig_pen);

			for (size_t j = 0; j < mv_Proc[i].tasks.size(); j++)
			{
				tr.rLeft() = m_absciss_axis.GetRect().left() +
					m_absciss_axis.ToScreen(mv_Proc[i].tasks[j].t_start);
				tr.rRight() = m_absciss_axis.GetRect().left() +
					m_absciss_axis.ToScreen(mv_Proc[i].tasks[j].t_end);

				STaskType* pTT = mv_Proc[i].tasks[j].type;
				if (pTT)
					pnt.setBrush(pTT->color);
				else
					pnt.setBrush(Qt::NoBrush);

				pnt.drawRect(tr);
			}

			proc_line++;
		}

		m_pen_link.setWidth(GetLinkWidth(task_hgh));
		pnt.setPen(m_pen_link);

		//links
		for (size_t i = 0; i < mv_Links.size(); i++)
		{
			if (mv_Proc[mv_Links[i].from].show &&
				mv_Proc[mv_Links[i].to].show)
			{
				int from_line = mv_Proc[mv_Links[i].from].chart_line;
				int to_line = mv_Proc[mv_Links[i].to].chart_line;
				pnt.drawLine(m_absciss_axis.GetRect().left() + m_absciss_axis.ToScreen(mv_Links[i].start),
					m_ordinates_axis.GetRect().bottom() - m_ordinates_axis.ToScreen(from_line + 0.5),
					m_absciss_axis.GetRect().left() + m_absciss_axis.ToScreen(mv_Links[i].end),
					m_ordinates_axis.GetRect().bottom() - m_ordinates_axis.ToScreen(to_line + 0.5));
			}
		}

		pnt.setPen(orig_pen);
		pnt.setBrush(orig_brush);

		pnt.setViewport(orig_viewport);
		pnt.setWindow(orig_window);
	}

	if (draw_legend)
	{
		lr.moveLeft(pnt.viewport().width() - lr.width());
		lr.moveTop(0);

		m_legend.Draw(pnt, lr);
	}
}
//========================================================================

void	CGanttChart::CorrectTime(double t, bool redraw_labels /* = true */, bool force_labels /* = false */)
{
	QMutexLocker ml(&m_mutex);

	if (!mb_time_defined)
	{
		m_time_start	= t;
		m_time_end		= t;

		mb_time_defined = true;
	}

	bool new_time = false;
	if (t < m_time_start)
	{
		m_time_start = t;
		new_time = true;
	}

	if (t > m_time_end)
	{
		m_time_end = t;
		new_time = true;
	}

	if (force_labels || new_time && redraw_labels)
	{
		m_absciss_axis.SetRange(m_time_start, m_time_end);

		m_absciss_axis.ClearLabels();

		double step = (m_time_end - m_time_start) / m_time_labels_count;
		for (double d = m_time_start; d < m_time_end; d += step)
			m_absciss_axis.AddLabel(d, 4);
	}
}
//========================================================================

CGanttChart::STaskType*	CGanttChart::GetTaskType(int type)
{
	for (size_t i = 0; i < mv_TType.size(); i++)
		if (mv_TType[i]->type == type)
			return mv_TType[i];

	return NULL;
}
//========================================================================

int		CGanttChart::FitMouseTolerance(int x)
{
	int left = m_absciss_axis.GetRect().left();
	if (x < left)
		if (x >= left - mn_mouse_tolerance)
			return left;

	int right = m_absciss_axis.GetRect().right();
	if (x > right)
		if (x <= right + mn_mouse_tolerance)
			return right;

	return x;
}
//========================================================================

void	CGanttChart::mousePressEvent(QMouseEvent* e)
{
	repaint();

	if (!InChartWorkspace(e->pos()))
		return;

	QPainter p(this);

	QPen orig_pen = p.pen();

	p.setPen(m_pen_time_line);

	p.drawLine(e->x(), m_ordinates_axis.GetRect().bottom(),
		e->x(), m_ordinates_axis.GetRect().top());

	p.setPen(orig_pen);

	mb_mouse_pressed = true;

	m_mouse_press_time		= m_absciss_axis.ToData(e->x() - m_absciss_axis.GetRect().left());
	m_mouse_release_time	= m_mouse_press_time;
	m_mouse_press_pos		= e->x();
	m_mouse_release_pos		= m_mouse_press_pos;
}
//========================================================================

void	CGanttChart::mouseMoveEvent(QMouseEvent* e)
{
	if (!mb_mouse_pressed)
		return;

	repaint();

	int	x_pos = e->x();
	x_pos = FitMouseTolerance(x_pos);

	if (!InChartWorkspace(x_pos, e->y()))
		return;

	QPainter p(this);

	QPen orig_pen = p.pen();

	p.setPen(m_pen_time_line);

	QRect ar = m_absciss_axis.GetRect();
	p.drawLine(
		ar.left() + m_absciss_axis.ToScreen(m_mouse_press_time),
		m_ordinates_axis.GetRect().bottom(),
		ar.left() + m_absciss_axis.ToScreen(m_mouse_release_time),
		m_ordinates_axis.GetRect().top());

	p.drawLine(x_pos, m_ordinates_axis.GetRect().bottom(),
		x_pos, m_ordinates_axis.GetRect().top());

	p.setPen(orig_pen);
}
//========================================================================

void	CGanttChart::mouseReleaseEvent(QMouseEvent* e)
{
	repaint();

	mb_mouse_pressed = false;

	int	x_pos = e->x();
	x_pos = FitMouseTolerance(x_pos);

	if (!InChartWorkspace(x_pos, e->y()))
		return;

	if (abs(m_mouse_press_pos - x_pos) < mn_mouse_tolerance)
		return;

	m_mouse_release_time	= m_absciss_axis.ToData(x_pos - m_absciss_axis.GetRect().left());

	emit TimeFrameSelected(
		min(m_mouse_press_time, m_mouse_release_time),
		max(m_mouse_press_time, m_mouse_release_time));
}
//========================================================================

//class CGanttChart
//************************************************************************
//************************************************************************

};	//namespace Chart
