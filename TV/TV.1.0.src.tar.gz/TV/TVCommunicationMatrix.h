#ifndef _TV_COMMUNICATION_MATRIX_H_
#define _TV_COMMUNICATION_MATRIX_H_

#include "TraceManager.h"

#include "Common.h"
#include "Chart.h"
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qlabel.h>
#include <qlayout.h>

class CTVCommunicationMatrix :
	public CTraceVisualizer
{
	Q_OBJECT
public:
	CTVCommunicationMatrix(CTraceManager* pTM, QWidget* parent);
	virtual ~CTVCommunicationMatrix(void);

    QButtonGroup* mg_state;
    QRadioButton* mr_volume;
    QRadioButton* mr_count;
    QRadioButton* mr_mean;
    Chart::CMatrix* m_martix;

	//GUI thread
		virtual	void	OnInitDraw();
		virtual	void	OnDrawRecord();
		virtual	void	OnFinalDraw();
	//end GUI thread
	
	//reader thread
		virtual	bool	OnNewTraceRead();
		virtual	bool	OnEventRead(const CTraceEvent* pTE);
		virtual	bool	OnEndTraceRead();
	//end reader thread

	//thread safe
		void	ZeroCommunications();
	//end thread safe

public slots:
	void	StateChanged(int);

protected:
    QGridLayout* FCommunicationMatrixLayout;
    QVBoxLayout* mg_stateLayout;

protected slots:
    virtual void languageChange();

private:
	//mutexed
		TInt2DVec m_matr_volume;
		TInt2DVec m_matr_count;
	//end mutexed

	void	DrawMatrix(bool upd = true);
};

#endif	//_TV_COMMUNICATION_MATRIX_H_
