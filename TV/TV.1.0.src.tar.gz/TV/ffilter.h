/****************************************************************************
** Form interface generated from reading ui file 'ffilter.ui'
**
** Created: Пн 28. июн 15:33:55 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FFILTER_H
#define FFILTER_H

#include <qvariant.h>
#include <qmainwindow.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
class QGroupBox;
class QLabel;
class QListBox;
class QListBoxItem;
class QPushButton;
class QLineEdit;

class FFilter : public QMainWindow
{
    Q_OBJECT

public:
    FFilter( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~FFilter();

    QGroupBox* groupBox2;
    QLabel* textLabel1;
    QListBox* mlb_ProcTotal;
    QPushButton* mbtn_ShowProc;
    QPushButton* mbtn_HideProc;
    QListBox* mlb_ProcShow;
    QLabel* textLabel2;
    QGroupBox* groupBox1;
    QLabel* textLabel5;
    QLabel* textLabel6;
    QLineEdit* m_TimeTotFrom;
    QLineEdit* m_TimeCurFrom;
    QLineEdit* m_TimeTotTo;
    QLineEdit* m_TimeCurTo;
    QPushButton* mbtn_TimeLeft;
    QPushButton* mbtn_ZoomOut;
    QPushButton* mbtn_ZoomIn;
    QPushButton* mbtn_TimeRight;
    QPushButton* mbtn_Apply;

public slots:
    virtual void ApplyFilter();
    virtual void OnShowProc();
    virtual void OnHideProc();

protected:
    QGridLayout* FFilterLayout;
    QGridLayout* groupBox2Layout;
    QVBoxLayout* layout4;
    QSpacerItem* spacer4;
    QSpacerItem* spacer5;
    QGridLayout* groupBox1Layout;
    QSpacerItem* spacer5_2;
    QSpacerItem* spacer14;
    QHBoxLayout* layout7;

protected slots:
    virtual void languageChange();

};

#endif // FFILTER_H
