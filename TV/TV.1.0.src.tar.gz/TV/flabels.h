/****************************************************************************
** Form interface generated from reading ui file 'flabels.ui'
**
** Created: Ср 30. июн 15:02:34 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.2   edited Nov 24 13:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef FLABELS_H
#define FLABELS_H

#include <qvariant.h>
#include <qmainwindow.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
class QLabel;

class FLabels : public QMainWindow
{
    Q_OBJECT

public:
    FLabels( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~FLabels();

    QLabel* l_processor;
    QLabel* l_Gantt;
    QLabel* l_Tasks;
    QLabel* l_time_s;
    QLabel* l_calls;

protected:

protected slots:
    virtual void languageChange();

};

#endif // FLABELS_H
