#include "TVCommunicationMatrix.h"

CTVCommunicationMatrix::CTVCommunicationMatrix(CTraceManager* pTM, QWidget* parent)
	:CTraceVisualizer(pTM, parent, NULL, "CTVCommunicationMatrix")
{
	mp_TypeFilter =	new	CTraceFilter;
	pTM->MakeCommunicationFilter(*mp_TypeFilter);

    setCentralWidget( new QWidget( this, "qt_central_widget" ) );
    FCommunicationMatrixLayout = new QGridLayout( centralWidget(), 1, 1, 11, 6, "FCommunicationMatrixLayout"); 

	mg_state = new QButtonGroup( centralWidget(), "mg_state" );
	mg_state->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5,	(QSizePolicy::SizeType)0, 0, 0,	mg_state->sizePolicy().hasHeightForWidth() ) );
	mg_state->setColumnLayout(0, Qt::Vertical );
	mg_state->layout()->setSpacing(	6 );
	mg_state->layout()->setMargin( 11 );
	mg_stateLayout = new QVBoxLayout( mg_state->layout() );
	mg_stateLayout->setAlignment( Qt::AlignTop );

    mr_volume = new QRadioButton( mg_state, "mr_volume" );
    mg_stateLayout->addWidget( mr_volume );

    mr_count = new QRadioButton( mg_state, "mr_count" );
    mg_stateLayout->addWidget( mr_count );

    mr_mean = new QRadioButton( mg_state, "mr_mean" );
    mg_stateLayout->addWidget( mr_mean );

    FCommunicationMatrixLayout->addWidget( mg_state, 0, 1 );

    m_martix = new Chart::CMatrix( centralWidget(), "m_martix" );
    m_martix->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, m_martix->sizePolicy().hasHeightForWidth() ) );

    FCommunicationMatrixLayout->addMultiCellWidget( m_martix, 0, 2, 0, 0 );

    languageChange();

	clearWState( WState_Polished );

	resize(500, 300);
	setMinimumSize(size());

	mr_volume->setChecked(true);

	connect(mg_state, SIGNAL(clicked(int)), SLOT(StateChanged(int)));
}

CTVCommunicationMatrix::~CTVCommunicationMatrix(void)
{
}
//========================================================================

void	CTVCommunicationMatrix::OnInitDraw()
{
}
//========================================================================

void	CTVCommunicationMatrix::OnDrawRecord()
{
	DrawMatrix();
}
//========================================================================

void	CTVCommunicationMatrix::OnFinalDraw()
{
	//QString s;
	//s.sprintf("Open - %d ms",
	//	mp_TrManager->m_time_start.msecsTo(mp_TrManager->m_time_end));
	//CQuickBox::Msg(s);
}
//========================================================================

bool	CTVCommunicationMatrix::OnNewTraceRead()
{
	int proc = mp_TrManager->GetProcessorsCount();

	mtx_Data.lock();
		m_matr_volume.resize(proc);
		for (size_t i = 0; i < m_matr_volume.size(); i++)
			m_matr_volume[i].resize(proc);

		m_matr_count.resize(proc);
		for (size_t i = 0; i < m_matr_count.size(); i++)
			m_matr_count[i].resize(proc);
	mtx_Data.unlock();

	ZeroCommunications();

	return true;
}
//========================================================================

bool	CTVCommunicationMatrix::OnEventRead(const CTraceEvent* pTE)
{
	if (!CTraceVisualizer::OnEventRead(pTE))
		return false;

	if (pTE->GetType() != CTraceEvent::E_message)
		return false;
	const CMessageEvent* pME = static_cast<const CMessageEvent*>(pTE);

	mtx_Data.lock();
		m_matr_volume[pME->GetPrcSend()][pME->GetPrcRecv()] += pME->GetLength();

		m_matr_count[pME->GetPrcSend()][pME->GetPrcRecv()] += 1;
	mtx_Data.unlock();

	return true;
}
//========================================================================

bool	CTVCommunicationMatrix::OnEndTraceRead()
{
	return true;
}
//========================================================================

void	CTVCommunicationMatrix::ZeroCommunications()
{
	mtx_Data.lock();
		for (size_t i = 0; i < m_matr_volume.size(); i++)
			for (size_t j = 0; j < m_matr_volume[i].size(); j++)
				m_matr_volume[i][j] = 0;

		for (size_t i = 0; i < m_matr_count.size(); i++)
			for (size_t j = 0; j < m_matr_count[i].size(); j++)
				m_matr_count[i][j] = 0;
	mtx_Data.unlock();
}
//========================================================================

void CTVCommunicationMatrix::languageChange()
{
	m_martix->OrdinatesName(trUtf8( "\xd0\x9e\xd1\x82\xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2\xd0\xb8\xd1\x82\xd0\xb5\xd0\xbb\xd1\x8c" ));
	m_martix->AbscissName(trUtf8( "\xd0\x9f\xd0\xbe\xd0\xbb\xd1\x83\xd1\x87\xd0\xb0\xd1\x82\xd0\xb5\xd0\xbb\xd1\x8c" ));
    setCaption( trUtf8( "\xd0\x9c\xd0\xb0\xd1\x82\xd1\x80\xd0\xb8\xd1\x86\xd0\xb0\x20\xd0\xb2\xd0\xb7\xd0\xb0\xd0\xb8\xd0\xbc\xd0\xbe\xd0\xb4\xd0\xb5\xd0\xb9\xd1\x81\xd1\x82\xd0\xb2\xd0\xb8\xd0\xb9" ) );
    mg_state->setTitle( trUtf8( "\xd0\x9f\xd0\xbe\xd0\xba\xd0\xb0\xd0\xb7\xd0\xb0\xd1\x82\xd1\x8c" ) );
    mr_volume->setText( trUtf8( "\xd0\x9e\xd0\xb1\xd1\x8a\xd1\x91\xd0\xbc\x20\xd0\xb4\xd0\xb0\xd0\xbd\xd0\xbd\xd1\x8b\xd1\x85" ) );
    mr_count->setText( trUtf8( "\xd0\x9a\xd0\xbe\xd0\xbb\xd0\xb8\xd1\x87\xd0\xb5\xd1\x81\xd1\x82\xd0\xb2\xd0\xbe\x20\xd1\x81\xd0\xbe\xd0\xbe\xd0\xb1\xd1\x89\xd0\xb5\xd0\xbd\xd0\xb8\xd0\xb9" ) );
    mr_mean->setText( trUtf8( "\xd0\xa1\xd1\x80\xd0\xb5\xd0\xb4\xd0\xbd\xd1\x8f\xd1\x8f\x20\xd0\xb4\xd0\xbb\xd0\xb8\xd0\xbd\xd0\xb0\x20\xd1\x81\xd0\xbe\xd0\xbe\xd0\xb1\xd1\x89\xd0\xb5\xd0\xbd\xd0\xb8\xd1\x8f" ) );
}
//========================================================================

void	CTVCommunicationMatrix::StateChanged(int)
{
	DrawMatrix();
}
//========================================================================

void	CTVCommunicationMatrix::DrawMatrix(bool upd /* = true */)
{
	int proc = mp_TrManager->CountLegalProc();

	m_martix->SetSize(proc, proc, false);

	int i = 0;
	int legal = 0;
	do
	{
		if (mp_TrManager->IsProcLegal(i))
		{
			m_martix->SetColName(legal, mp_TrManager->GetProcessorName(i), false);
			m_martix->SetRowName(legal, mp_TrManager->GetProcessorName(i), false);

			legal++;
		}

		i++;
	}
	while (legal < proc);

	m_martix->InitItems();

	int matr_i = 0;
	for (size_t i = 0; i < m_matr_volume.size(); i++)
	{
		if (!mp_TrManager->IsProcLegal(i))
			continue;

		int matr_j = 0;
		for (size_t j = 0; j < m_matr_volume[i].size(); j++)
		{
			if (!mp_TrManager->IsProcLegal(j))
				continue;

			mtx_Data.lock();
			
			if (mr_volume->isChecked())
				if (m_matr_volume[i][j] != 0)
					m_martix->SetItem(matr_i, matr_j, m_matr_volume[i][j]);

			if (mr_count->isChecked())
				if (m_matr_count[i][j] != 0)
					m_martix->SetItem(matr_i, matr_j, m_matr_count[i][j]);

			if (mr_mean->isChecked())
				if (m_matr_count[i][j] != 0 && m_matr_volume[i][j] != 0)
				{
					m_martix->SetItem(matr_i, matr_j,
						(int)((double)m_matr_volume[i][j] / (double)m_matr_count[i][j]));
				}

			mtx_Data.unlock();

			matr_j++;
		}

		matr_i++;
	}

	if (upd)
		m_martix->update();
}
//========================================================================
