#ifndef _TV_GANTT_H_
#define _TV_GANTT_H_

#include "TraceManager.h"
#include "Chart.h"

#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qlayout.h>

class CTVGantt: public CTraceVisualizer
{
	Q_OBJECT
public:
	CTVGantt(CTraceManager* pTM, QWidget* parent,
		IFilterWindowOwner* pFWO = NULL);
	virtual ~CTVGantt();

	//GUI thread
		virtual	void	OnInitDraw();
		virtual	void	OnDrawRecord();
		virtual	void	OnFinalDraw();

		void	DrawGantt();
	//end GUI thread
	
	//reader thread
		virtual	bool	OnNewTraceRead();
		virtual	bool	OnEventRead(const CTraceEvent* pTE);
		virtual	bool	OnEndTraceRead();
	//end reader thread

    QPushButton* mb_Filter;
    QButtonGroup* mg_Time;
    QRadioButton* mr_Global;
    QRadioButton* mr_Local;
    QPushButton* mb_MakeGlobal;

protected slots:
    virtual void languageChange();

	void	OnFilterChanged(int);
	void	SetGlobalTime();
	void	OnShowFilter();
	void	SetTime(double start, double end);

protected:
	Chart::CGanttChart*	m_gantt;

	QGridLayout* FGanttLayout;
    QSpacerItem* spacer3;
    QGridLayout* mg_TimeLayout;
    QSpacerItem* spacer2;

	void	ToLocalTime(bool force = false);
	void	ToGlobalTime(bool force = false);
	void	PrepareGlobal();

};	//class CTVGantt

#endif	//_TV_GANTT_H_
